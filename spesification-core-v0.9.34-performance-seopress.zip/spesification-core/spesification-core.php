<?php
/**
 * Plugin Name: Specification Core
 * Description: Modular phone database system for native Phone CPT, attribute groups, editor tools, frontend bridge, database-first SEO schema bridge, currency bridge, tools, and settings.
 * Version: 0.9.34
 * Author: Spesification.com
 * Author URI: https://spesification.com
 * Text Domain: spesification-core
 * Domain Path: /languages
 * Requires at least: 5.5
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI: false
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SP_CORE_VERSION', '0.9.34');
define('SP_CORE_FILE', __FILE__);
define('SP_CORE_DIR', plugin_dir_path(__FILE__));
define('SP_CORE_URL', plugin_dir_url(__FILE__));

require_once SP_CORE_DIR . 'includes/helpers.php';
require_once SP_CORE_DIR . 'includes/class-sp-core.php';

add_action('plugins_loaded', static function () {
    Specification_Core::instance();
});

register_activation_hook(__FILE__, static function () {
    Specification_Core::instance()->register_post_type();
    Specification_Core::instance()->register_taxonomies();
    if (!is_array(get_option('sp_core_enabled_modules', null))) {
        update_option('sp_core_enabled_modules', ['attributes', 'phone_meta', 'frontend', 'compare', 'seo', 'currency'], false);
    }
    flush_rewrite_rules(false);
});

register_deactivation_hook(__FILE__, static function () {
    flush_rewrite_rules(false);
});
