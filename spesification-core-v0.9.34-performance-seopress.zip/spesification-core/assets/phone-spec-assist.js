(function () {
  'use strict';

  var config = window.spCorePhoneSpecAssist || {};
  var fields = config.fields || {};
  var labels = config.labels || {};
  var activeList = null;
  var booted = false;
  var statesByFieldName = {};
  var quickPasteBooted = false;
  var quickPastePanelBooted = false;

  var quickSections = Array.isArray(config.groups) && config.groups.length ? config.groups : [
    { label: 'Network', key: 'network' },
    { label: 'Design', key: 'design' },
    { label: 'Display', key: 'display' },
    { label: 'Platform', key: 'platform' },
    { label: 'Storage', key: 'storage' },
    { label: 'Front Camera', key: 'front_camera' },
    { label: 'Rear Camera', key: 'rear_camera' },
    { label: 'Connectivity', key: 'connectivity' },
    { label: 'Audio', key: 'audio' },
    { label: 'Battery', key: 'battery' },
    { label: 'Sensor', key: 'sensor' },
    { label: 'Scores', key: 'scores' }
  ];

  function normalize(value) {
    return String(value || '').toLowerCase().trim();
  }

  function clean(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function unique(values) {
    var seen = {};
    var output = [];

    values.forEach(function (value) {
      value = clean(value);
      if (!value) return;

      var key = normalize(value);
      if (seen[key]) return;

      seen[key] = true;
      output.push(value);
    });

    return output;
  }

  function getFieldName(wrapper) {
    return wrapper ? wrapper.getAttribute('data-name') || '' : '';
  }

  function normalizeOneFullValue(raw) {
    raw = String(raw || '').trim();
    if (!raw) return '';

    // One complete GSMArena-style row. Commas are part of the value.
    // Older newline output is normalized into one readable value only.
    return unique(raw.split(/\r?\n/)).join(', ');
  }

  function closeActiveList() {
    document.querySelectorAll('.sp-core-valuebox-arrow.is-open').forEach(function (button) {
      button.classList.remove('is-open');
    });

    if (activeList && activeList.parentNode) {
      activeList.parentNode.removeChild(activeList);
    }
    activeList = null;
  }

  function isSuggestionListOpenFor(state) {
    return !!(activeList && activeList.parentNode === state.shell);
  }

  function syncTextarea(textarea, value) {
    textarea.value = normalizeOneFullValue(value);
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function getSuggestions(fieldName, query, currentValue) {
    var payload = fields[fieldName] || {};
    var values = Array.isArray(payload.values) ? payload.values : [];
    var q = normalize(query);
    var current = normalize(currentValue);
    var starts = [];
    var contains = [];
    var neutral = [];

    values.forEach(function (value) {
      var text = clean(value);
      var low = normalize(text);
      if (!low || low === current) return;

      if (!q) {
        neutral.push(text);
      } else if (low.indexOf(q) === 0) {
        starts.push(text);
      } else if (low.indexOf(q) !== -1) {
        contains.push(text);
      }
    });

    return unique(starts.concat(contains, neutral)).slice(0, 14);
  }

  function setValue(state, value) {
    syncTextarea(state.textarea, value);
    state.input.value = '';
    renderValue(state);
  }

  function clearValue(state) {
    syncTextarea(state.textarea, '');
    state.input.value = '';
    renderValue(state);
    closeActiveList();
    state.input.focus();
  }

  function renderValue(state) {
    var current = normalizeOneFullValue(state.textarea.value);
    state.valueWrap.innerHTML = '';

    if (!current) {
      var empty = document.createElement('div');
      empty.className = 'sp-core-valuebox-empty';
      empty.textContent = labels.emptyValue || 'No value selected yet.';
      state.valueWrap.appendChild(empty);
      return;
    }

    var chip = document.createElement('div');
    chip.className = 'sp-core-valuebox-chip';

    var text = document.createElement('span');
    text.className = 'sp-core-valuebox-chip-text';
    text.textContent = current;
    chip.appendChild(text);

    var remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'sp-core-valuebox-remove';
    remove.setAttribute('aria-label', labels.remove || 'Remove value');
    remove.textContent = '×';
    remove.addEventListener('click', function () {
      clearValue(state);
    });
    chip.appendChild(remove);

    state.valueWrap.appendChild(chip);
  }

  function renderSuggestions(state) {
    closeActiveList();

    var suggestions = getSuggestions(state.fieldName, state.input.value, state.textarea.value);
    var list = document.createElement('div');
    list.className = 'sp-core-spec-suggest-list';

    var head = document.createElement('div');
    head.className = 'sp-core-spec-suggest-head';
    head.textContent = (state.payload.label || state.fieldName) + ' · ' + (labels.hint || 'Saved values');
    list.appendChild(head);

    if (!suggestions.length) {
      var empty = document.createElement('div');
      empty.className = 'sp-core-spec-suggest-empty';
      empty.textContent = labels.empty || 'No saved value found. Type/paste one full value and press Enter.';
      list.appendChild(empty);
    } else {
      suggestions.forEach(function (value) {
        var button = document.createElement('button');
        button.type = 'button';
        button.className = 'sp-core-spec-suggest-item';
        button.textContent = value;
        button.addEventListener('mousedown', function (event) {
          event.preventDefault();
          setValue(state, value);
          closeActiveList();
          state.input.focus();
        });
        list.appendChild(button);
      });
    }

    state.shell.appendChild(list);
    activeList = list;
    if (state.arrow) {
      state.arrow.classList.add('is-open');
    }
  }

  function buildEditor(wrapper, textarea, payload) {
    var state = {
      wrapper: wrapper,
      textarea: textarea,
      payload: payload,
      fieldName: getFieldName(wrapper),
      shell: null,
      valueWrap: null,
      input: null,
      arrow: null,
      suppressNextFocus: false
    };

    syncTextarea(textarea, textarea.value);

    var shell = document.createElement('div');
    shell.className = 'sp-core-valuebox-shell';

    var searchRow = document.createElement('div');
    searchRow.className = 'sp-core-valuebox-search-row';

    var input = document.createElement('textarea');
    input.className = 'sp-core-valuebox-input';
    input.rows = 1;
    input.setAttribute('placeholder', labels.search || 'Add existing');
    searchRow.appendChild(input);

    var arrow = document.createElement('button');
    arrow.type = 'button';
    arrow.className = 'sp-core-valuebox-arrow';
    arrow.setAttribute('aria-label', labels.hint || 'Saved values');
    arrow.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5.5 7.5 10 12l4.5-4.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    arrow.addEventListener('mousedown', function (event) {
      event.preventDefault();
      if (isSuggestionListOpenFor(state)) {
        state.suppressNextFocus = true;
        closeActiveList();
        input.blur();
        return;
      }
      input.focus();
      renderSuggestions(state);
    });
    searchRow.appendChild(arrow);

    shell.appendChild(searchRow);

    var valueWrap = document.createElement('div');
    valueWrap.className = 'sp-core-valuebox-value-wrap';
    shell.appendChild(valueWrap);

    var hint = document.createElement('div');
    hint.className = 'sp-core-valuebox-hint';
    hint.textContent = labels.oneChipHint || 'Search or paste a full value. Commas stay inside the value.';
    shell.appendChild(hint);

    var acfInput = textarea.closest('.acf-input') || textarea.parentNode;
    if (acfInput) {
      acfInput.appendChild(shell);
    }

    state.shell = shell;
    state.valueWrap = valueWrap;
    state.input = input;
    state.arrow = arrow;
    statesByFieldName[state.fieldName] = state;

    renderValue(state);

    input.addEventListener('focus', function () {
      if (state.suppressNextFocus) {
        state.suppressNextFocus = false;
        return;
      }
      renderSuggestions(state);
    });

    input.addEventListener('input', function () {
      renderSuggestions(state);
    });

    input.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        closeActiveList();
        return;
      }

      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        var value = normalizeOneFullValue(input.value);
        if (!value) return;
        setValue(state, value);
        closeActiveList();
      }
    });

    input.addEventListener('paste', function () {
      window.setTimeout(function () {
        renderSuggestions(state);
      }, 0);
    });

    wrapper.classList.add('sp-core-valuebox-enabled');
  }

  function enhanceField(wrapper) {
    var fieldName = getFieldName(wrapper);
    var payload = fields[fieldName];

    if (!payload && wrapper && wrapper.classList && wrapper.classList.contains('sp-core-accordion-child')) {
      var labelNode = wrapper.querySelector('.acf-label label');
      payload = {
        label: clean(labelNode ? labelNode.textContent : fieldName.replace(/_/g, ' ')),
        values: []
      };
      fields[fieldName] = payload;
    }

    if (!payload) return;

    var textarea = wrapper.querySelector('textarea');
    if (!textarea || textarea.dataset.spCoreSpecAssist === '1') return;

    textarea.dataset.spCoreSpecAssist = '1';
    buildEditor(wrapper, textarea, payload);
  }

  function getAccordionKeyByLabel(label) {
    var target = normalize(label);
    var key = '';
    quickSections.some(function (section) {
      if (normalize(section.label) === target || normalize(section.key) === target) {
        key = section.key;
        return true;
      }
      return false;
    });
    return key || target.replace(/\s+/g, '_');
  }

  function setAccordionOpenByKey(key, isOpen) {
    key = String(key || '').replace(/[^a-z0-9_\-]/gi, '');
    if (!key) return false;

    var heading = document.querySelector('#acf-group_sp_core_phone_specs .sp-core-accordion-heading-' + key);
    var children = document.querySelectorAll('#acf-group_sp_core_phone_specs .sp-core-accordion-child-' + key);
    if (!heading || !children.length) return false;

    heading.classList.toggle('is-sp-core-accordion-open', !!isOpen);
    var button = heading.querySelector('.sp-core-accordion-toggle');
    if (button) button.setAttribute('aria-expanded', isOpen ? 'true' : 'false');

    children.forEach(function (child) {
      child.hidden = !isOpen;
      child.classList.toggle('is-sp-core-accordion-hidden', !isOpen);
    });

    return true;
  }

  function openAccordionByLabel(label) {
    return setAccordionOpenByKey(getAccordionKeyByLabel(label), true);
  }

  function getFieldAccordionKey(wrapper) {
    if (!wrapper || !wrapper.classList) return '';
    for (var i = 0; i < wrapper.classList.length; i++) {
      var cls = wrapper.classList[i];
      if (cls.indexOf('sp-core-accordion-child-') === 0) {
        return cls.replace('sp-core-accordion-child-', '');
      }
    }
    return '';
  }

  function initAccordions() {
    var headings = document.querySelectorAll('#acf-group_sp_core_phone_specs .acf-field.sp-core-accordion-heading');
    headings.forEach(function (heading, index) {
      if (heading.dataset.spCoreAccordionReady === '1') return;
      heading.dataset.spCoreAccordionReady = '1';

      var card = heading.querySelector('.sp-core-section-structure-card');
      var key = card ? card.getAttribute('data-sp-core-section') : '';
      var button = heading.querySelector('.sp-core-accordion-toggle');
      if (!key || !button) return;

      // Keep every group collapsed by default for a cleaner mobile workspace.
      setAccordionOpenByKey(key, false);

      button.addEventListener('click', function (event) {
        event.preventDefault();
        var isOpen = heading.classList.contains('is-sp-core-accordion-open');
        setAccordionOpenByKey(key, !isOpen);
      });
    });
  }

  function getSectionLabels() {
    return quickSections.map(function (section) {
      return normalize(section.label);
    });
  }

  function isKnownSectionLabel(label) {
    return getSectionLabels().indexOf(normalize(label)) !== -1;
  }

  function findSectionContent(label) {
    var target = normalize(label);
    var cards = Array.prototype.slice.call(document.querySelectorAll('#acf-group_sp_core_phone_specs .sp-core-section-structure-card'));
    var fallback = null;

    cards.some(function (card) {
      var title = clean((card.querySelector('strong') || {}).textContent || '');
      if (normalize(title) !== target) {
        return false;
      }

      var field = card.closest('.acf-field') || card;
      if (!fallback) {
        fallback = field;
      }

      if (field.offsetParent !== null && !field.classList.contains('acf-hidden')) {
        fallback = field;
        return true;
      }

      return false;
    });

    return fallback;
  }

  function scrollToElementWithOffset(element) {
    if (!element) return false;

    var offset = window.innerWidth <= 782 ? 106 : 86;
    var top = window.pageYOffset + element.getBoundingClientRect().top - offset;

    window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
    return true;
  }

  function updateToolbarActive(label) {
    var toolbar = document.querySelector('.sp-core-phone-toolbar');
    if (!toolbar) return;

    toolbar.querySelectorAll('.sp-core-phone-toolbar-chip').forEach(function (item) {
      item.classList.toggle('is-active', normalize(item.textContent) === normalize(label));
    });
  }

  function scrollToSectionContent(label) {
    if (!isKnownSectionLabel(label)) return false;

    var content = findSectionContent(label);
    if (content) {
      content.classList.add('sp-core-field-pulse');
      window.setTimeout(function () {
        content.classList.remove('sp-core-field-pulse');
      }, 1300);
      return scrollToElementWithOffset(content);
    }

    return false;
  }

  function jumpToSection(label) {
    if (!label) return false;

    closeActiveList();
    updateToolbarActive(label);
    openAccordionByLabel(label);

    window.setTimeout(function () {
      scrollToSectionContent(label);
    }, 80);

    return true;
  }

  function searchAndFocus(query) {
    var q = normalize(query);
    if (!q) return;

    var wrappers = Array.prototype.slice.call(document.querySelectorAll('.acf-field.sp-core-valuebox-enabled'));
    var found = null;

    wrappers.some(function (wrapper) {
      var label = clean((wrapper.querySelector('.acf-label label') || {}).textContent || '');
      var fieldName = getFieldName(wrapper);
      if (normalize(label).indexOf(q) !== -1 || normalize(fieldName).indexOf(q) !== -1) {
        found = wrapper;
        return true;
      }
      return false;
    });

    if (!found) return;

    var accordionKey = getFieldAccordionKey(found);
    if (accordionKey) {
      setAccordionOpenByKey(accordionKey, true);
    }

    found.scrollIntoView({ behavior: 'smooth', block: 'center' });
    found.classList.add('sp-core-field-pulse');
    window.setTimeout(function () {
      found.classList.remove('sp-core-field-pulse');
    }, 1300);

    var input = found.querySelector('.sp-core-valuebox-input');
    if (input) input.focus();
  }



  function groupKeyByLabel(label) {
    var target = normalize(label).replace(/\s+/g, '_');
    var result = '';
    quickSections.some(function (section) {
      if (normalize(section.label) === normalize(label) || normalize(section.key) === target || normalize(section.key) === normalize(label)) {
        result = section.key;
        return true;
      }
      return false;
    });
    return result || target;
  }

  function canonicalQuickGroupKey(label) {
    var normalized = normalizeQuickLabel(label);
    if (!normalized) return '';

    var aliases = {
      'body': 'design',
      'design': 'design',
      'network': 'network',
      'display': 'display',
      'platform': 'platform',
      'memory': 'storage',
      'storage': 'storage',
      'main camera': 'rear_camera',
      'rear camera': 'rear_camera',
      'selfie camera': 'front_camera',
      'front camera': 'front_camera',
      'comms': 'connectivity',
      'connectivity': 'connectivity',
      'sound': 'audio',
      'audio': 'audio',
      'battery': 'battery',
      'features': 'sensor',
      'sensor': 'sensor',
      'sensors': 'sensor',
      'tests': 'scores',
      'scores': 'scores'
    };

    if (aliases[normalized]) return aliases[normalized];

    var result = '';
    quickSections.some(function (section) {
      if (normalizeQuickLabel(section.label) === normalized || normalizeQuickLabel(section.key) === normalized) {
        result = section.key;
        return true;
      }
      return false;
    });

    return result;
  }

  function getGroupLabelByKey(key) {
    key = String(key || '');
    var label = '';
    quickSections.some(function (section) {
      if (section.key === key) {
        label = section.label;
        return true;
      }
      return false;
    });
    return label || key.replace(/_/g, ' ');
  }

  function quickPasteFieldAliases(groupKey) {
    var common = {
      'technology': 'technology',
      'network': 'technology',
      'speed': 'speed',
      'sim': 'sim',
      'sim card': 'sim',
      'price': 'price',
      'dimensions': 'dimensions',
      'dimension': 'dimensions',
      'weight': 'weight',
      'build': 'material',
      'material': 'material',
      'color': 'colors',
      'colors': 'colors',
      'ip rating': 'ip_rating',
      'ip': 'ip_rating',
      'panel type': 'panel_type',
      'display type': 'panel_type',
      'size': 'display_size',
      'resolution': 'resolution',
      'brightness': 'brightness',
      'protection': 'protection',
      'features': 'display_features',
      'refresh rate': 'refresh_rate',
      'os': 'os',
      'operating system': 'os',
      'chipset': 'processor',
      'processor': 'processor',
      'cpu': 'cores',
      'cores': 'cores',
      'clock speed': 'clock_speed',
      'clockspeed': 'clock_speed',
      'gpu': 'gpu',
      'card slot': 'sd_slot',
      'memory card': 'sd_slot',
      'microsd slot': 'sd_slot',
      'micro sd slot': 'sd_slot',
      'sd slot': 'sd_slot',
      'sd card slot': 'sd_slot',
      'sd card': 'sd_slot',
      'microsd card slot': 'sd_slot',
      'internal': 'internal_storage',
      'internal storage': 'internal_storage',
      'ram': 'ram',
      'ram type': 'ram_type',
      'storage': 'storage',
      'wlan': 'wlan',
      'bluetooth': 'bluetooth',
      'positioning': 'gps',
      'gps': 'gps',
      'nfc': 'nfc',
      'infrared': 'infrared',
      'infrared port': 'infrared',
      'radio': 'radio',
      'usb': 'usb',
      'loudspeaker': 'loudspeaker',
      'speaker': 'loudspeaker',
      '3.5mm': 'audio_jack_3_5mm',
      '3.5mm jack': 'audio_jack_3_5mm',
      '3 5mm jack': 'audio_jack_3_5mm',
      'audio jack': 'audio_jack',
      'capacity': 'capacity',
      'battery type': 'battery_type',
      'charging': 'charging',
      'quick charge': 'quick_charge',
      'power delivery': 'power_delivery',
      'wireless charging': 'wireless_charging',
      'reverse': 'reverse_charging',
      'reverse charging': 'reverse_charging',
      'sensors': 'sensors',
      'sensor': 'sensors',
      'fingerprint': 'fingerprint',
      'face id': 'face_id',
      'accelerometer': 'accelerometer',
      'gyro': 'gyroscope',
      'gyroscope': 'gyroscope',
      'proximity': 'proximity',
      'compass': 'compass',
      'barometer': 'barometer'
    };

    var contextual = {
      display: { 'type': 'panel_type', 'features': 'display_features' },
      battery: { 'type': 'capacity' },
      rear_camera: { 'single': 'rear_main', 'dual': 'rear_main', 'triple': 'rear_main', 'main': 'rear_main', 'main camera': 'rear_main', 'rear camera': 'rear_main', 'second': 'rear_second', 'secondary': 'rear_second', 'second rear': 'rear_second', 'secondary rear': 'rear_second', 'third': 'rear_third', 'third rear': 'rear_third', 'quad': 'rear_quad', 'quad rear': 'rear_quad', 'features': 'rear_features', 'features rear': 'rear_features', 'rear features': 'rear_features', 'video': 'rear_video', 'video rear': 'rear_video', 'rear video': 'rear_video' },
      front_camera: { 'single': 'front_main', 'main': 'front_main', 'main front': 'front_main', 'front camera': 'front_main', 'selfie camera': 'front_main', 'second': 'front_second', 'second front': 'front_second', 'secondary': 'front_second', 'secondary front': 'front_second', 'features': 'front_features', 'features front': 'front_features', 'front features': 'front_features', 'video': 'front_video', 'video front': 'front_video', 'front video': 'front_video' },
      connectivity: { 'positioning': 'gps' },
      audio: { '3.5mm jack': 'audio_jack_3_5mm', '3.5mm': 'audio_jack_3_5mm' },
      design: { 'type': 'material', 'build': 'material' }
    };

    return Object.assign({}, common, contextual[groupKey] || {});
  }

  function cleanQuickPasteText(text) {
    return String(text || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1')
      .replace(/<[^>]*>/g, ' ')
      .replace(/\r/g, '\n')
      .replace(/[ \t]+\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function cleanQuickPasteValue(value) {
    return cleanQuickPasteText(value)
      .replace(/\s*·\s*/g, '; ')
      .replace(/^;\s*/, '')
      .replace(/\s*;\s*/g, '; ')
      .replace(/\s+/g, ' ')
      .replace(/;\s*$/g, '')
      .trim();
  }

  function normalizeQuickLabel(label) {
    return normalize(cleanQuickPasteText(label))
      .replace(/[:：]+$/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function isGroupTitleLine(line) {
    return canonicalQuickGroupKey(line) !== '';
  }

  function fieldForQuickLabel(label, groupKey) {
    var normalized = normalizeQuickLabel(label);
    if (!normalized || isGroupTitleLine(normalized)) return '';

    var aliases = quickPasteFieldAliases(groupKey);
    if (aliases[normalized]) return aliases[normalized];

    // GSMArena label variants.
    normalized = normalized.replace(/\s+jack$/g, ' jack');
    if (aliases[normalized]) return aliases[normalized];

    return '';
  }

  function splitInlineQuickPair(line, groupKey) {
    var cleaned = cleanQuickPasteText(line);
    var match = cleaned.match(/^([^:\t]{1,42})[:：]\s*(.+)$/);
    if (match && fieldForQuickLabel(match[1], groupKey)) {
      return { label: match[1], value: match[2] };
    }

    match = cleaned.match(/^([^\t]{1,42})\t+(.+)$/);
    if (match && fieldForQuickLabel(match[1], groupKey)) {
      return { label: match[1], value: match[2] };
    }

    // Desktop copy often becomes "Label    Value".
    match = cleaned.match(/^(.{1,42}?)\s{2,}(.+)$/);
    if (match && fieldForQuickLabel(match[1], groupKey)) {
      return { label: match[1], value: match[2] };
    }

    return null;
  }

  function inferStandaloneQuickPair(line, groupKey) {
    var cleaned = cleanQuickPasteValue(line);
    if (!cleaned) return null;

    if ((groupKey === 'design' || groupKey === 'body') && /^ip\d{1,2}\b/i.test(cleaned)) {
      return { label: 'IP Rating', value: cleaned };
    }

    return null;
  }

  function parseQuickPastePairs(raw, groupKey) {
    var text = cleanQuickPasteText(raw);
    var lines = text.split(/\n+/).map(cleanQuickPasteValue).filter(Boolean);
    var pairs = [];
    var currentLabel = '';
    var currentValues = [];

    function flush() {
      if (!currentLabel) return;
      var value = cleanQuickPasteValue(currentValues.join(', '));
      if (value) pairs.push({ label: currentLabel, value: value });
      currentLabel = '';
      currentValues = [];
    }

    lines.forEach(function (line) {
      if (isGroupTitleLine(line)) {
        return;
      }

      var inlinePair = splitInlineQuickPair(line, groupKey);
      if (inlinePair) {
        flush();
        currentLabel = inlinePair.label;
        currentValues = [inlinePair.value];
        flush();
        return;
      }

      var field = fieldForQuickLabel(line, groupKey);
      if (field && line.length <= 48) {
        flush();
        currentLabel = line;
        currentValues = [];
        return;
      }

      var standalone = inferStandaloneQuickPair(line, groupKey);
      if (standalone) {
        flush();
        pairs.push(standalone);
        return;
      }

      if (currentLabel) {
        currentValues.push(line);
      }
    });

    flush();
    return pairs;
  }

  function applyValueToField(fieldName, value) {
    var state = statesByFieldName[fieldName];
    if (!state) {
      var wrapper = document.querySelector('.acf-field[data-name="' + fieldName + '"]');
      if (wrapper) {
        enhanceField(wrapper);
        state = statesByFieldName[fieldName];
      }
    }

    if (!state || !state.textarea) return false;
    setValue(state, value);
    return true;
  }

  function parseQuickPasteAuto(raw, selectedGroup) {
    selectedGroup = String(selectedGroup || 'auto');

    if (selectedGroup !== 'auto') {
      return parseQuickPastePairs(raw, selectedGroup).map(function (pair) {
        pair.groupKey = selectedGroup;
        return pair;
      });
    }

    var text = cleanQuickPasteText(raw);
    var lines = text.split(/\n+/).map(cleanQuickPasteValue).filter(Boolean);
    var output = [];
    var currentGroup = '';
    var chunk = [];

    function flushChunk() {
      if (!chunk.length) return;

      if (currentGroup) {
        parseQuickPastePairs(chunk.join('\n'), currentGroup).forEach(function (pair) {
          pair.groupKey = currentGroup;
          output.push(pair);
        });
      } else {
        // No explicit section title. Try every known group and keep only labels that map cleanly.
        quickSections.forEach(function (section) {
          parseQuickPastePairs(chunk.join('\n'), section.key).forEach(function (pair) {
            var field = fieldForQuickLabel(pair.label, section.key);
            if (field) {
              pair.groupKey = section.key;
              output.push(pair);
            }
          });
        });
      }

      chunk = [];
    }

    lines.forEach(function (line) {
      var group = canonicalQuickGroupKey(line);
      if (group) {
        flushChunk();
        currentGroup = group;
        return;
      }
      chunk.push(line);
    });

    flushChunk();

    var seen = {};
    return output.filter(function (pair) {
      var key = (pair.groupKey || '') + '::' + normalizeQuickLabel(pair.label) + '::' + normalize(pair.value);
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function splitCpuValue(value) {
    value = cleanQuickPasteValue(value);
    if (!value) return { cores: '', clock: '' };
    var match = value.match(/^([^\(]+)\((.+)\)$/);
    if (match) {
      return {
        cores: cleanQuickPasteValue(match[1]),
        clock: cleanQuickPasteValue(match[2])
      };
    }
    return { cores: value, clock: '' };
  }

  function applyQuickPastePairs(pairs) {
    var filled = 0;
    var skipped = [];
    var opened = {};

    pairs.forEach(function (pair) {
      var groupKey = pair.groupKey || '';
      var normalizedLabel = normalizeQuickLabel(pair.label);

      if (groupKey === 'platform' && normalizedLabel === 'cpu') {
        var cpu = splitCpuValue(pair.value);
        var cpuFilled = 0;
        if (cpu.cores && applyValueToField('cores', cpu.cores)) cpuFilled += 1;
        if (cpu.clock && applyValueToField('clock_speed', cpu.clock)) cpuFilled += 1;
        if (cpuFilled) {
          filled += cpuFilled;
          opened[groupKey] = true;
        } else {
          skipped.push(pair.label);
        }
        return;
      }

      var field = fieldForQuickLabel(pair.label, groupKey);
      if (!field) {
        skipped.push(pair.label);
        return;
      }

      if (applyValueToField(field, pair.value)) {
        filled += 1;
        if (groupKey) {
          opened[groupKey] = true;
        }
      } else {
        skipped.push(pair.label);
      }
    });

    Object.keys(opened).forEach(function (key) {
      setAccordionOpenByKey(key, true);
    });

    return { filled: filled, skipped: unique(skipped) };
  }

  function buildGlobalQuickPastePanel() {
    if (quickPastePanelBooted) return;
    var postbox = document.getElementById('acf-group_sp_core_phone_specs');
    if (!postbox || !postbox.parentNode) return;

    quickPastePanelBooted = true;

    var wrap = document.createElement('div');
    wrap.className = 'sp-core-global-quick-paste';

    var trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'sp-core-global-quick-paste-trigger';
    trigger.innerHTML = '<span><strong>' + (labels.quickPaste || 'Quick Paste GSMArena') + '</strong><small>Single multi-group parser</small></span><svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5.5 7.5 10 12l4.5-4.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    wrap.appendChild(trigger);

    var panel = document.createElement('div');
    panel.className = 'sp-core-global-quick-paste-panel';
    panel.hidden = true;

    var controls = document.createElement('div');
    controls.className = 'sp-core-global-quick-paste-controls';

    var select = document.createElement('select');
    select.className = 'sp-core-global-quick-paste-group';
    var auto = document.createElement('option');
    auto.value = 'auto';
    auto.textContent = 'Auto detect group';
    select.appendChild(auto);
    quickSections.forEach(function (section) {
      var option = document.createElement('option');
      option.value = section.key;
      option.textContent = getGroupLabelByKey(section.key);
      select.appendChild(option);
    });
    controls.appendChild(select);

    var parse = document.createElement('button');
    parse.type = 'button';
    parse.className = 'sp-core-global-quick-paste-parse';
    parse.textContent = labels.parseFill || 'Parse & Fill';
    controls.appendChild(parse);

    var clear = document.createElement('button');
    clear.type = 'button';
    clear.className = 'sp-core-global-quick-paste-clear';
    clear.textContent = 'Clear';
    controls.appendChild(clear);

    panel.appendChild(controls);

    var input = document.createElement('textarea');
    input.className = 'sp-core-global-quick-paste-input';
    input.rows = 8;
    input.placeholder = 'Paste GSMArena text here. Supports mobile copy, markdown links, and multiple groups.';
    panel.appendChild(input);

    var report = document.createElement('div');
    report.className = 'sp-core-global-quick-paste-report';
    report.textContent = 'Paste one section or a full specs block, then Parse & Fill.';
    panel.appendChild(report);

    wrap.appendChild(panel);

    function setOpen(isOpen) {
      panel.hidden = !isOpen;
      trigger.classList.toggle('is-open', isOpen);
      if (isOpen) input.focus();
    }

    trigger.addEventListener('click', function () {
      setOpen(panel.hidden);
    });

    clear.addEventListener('click', function () {
      input.value = '';
      report.textContent = 'Paste one section or a full specs block, then Parse & Fill.';
      report.classList.remove('is-success');
      input.focus();
    });

    parse.addEventListener('click', function () {
      var pairs = parseQuickPasteAuto(input.value, select.value);
      var result = applyQuickPastePairs(pairs);
      var message = result.filled + ' value' + (result.filled === 1 ? '' : 's') + ' filled.';
      if (result.skipped.length) {
        message += ' Skipped: ' + result.skipped.join(', ') + '.';
      }
      if (!pairs.length) {
        message = 'No valid GSMArena pairs found. Use Label: Value or paste a GSMArena section.';
      }
      report.textContent = message;
      report.classList.toggle('is-success', result.filled > 0);
    });

    postbox.parentNode.insertBefore(wrap, postbox);
  }

  function buildQuickPastePanels() {
    var cards = document.querySelectorAll('#acf-group_sp_core_phone_specs .sp-core-section-structure-card');
    cards.forEach(function (card) {
      if (card.dataset.spCoreQuickPaste === '1') return;

      var titleEl = card.querySelector('strong');
      var title = titleEl ? clean(titleEl.textContent) : '';
      var groupKey = groupKeyByLabel(title);
      if (!title || !groupKey) return;

      card.dataset.spCoreQuickPaste = '1';

      var wrap = document.createElement('div');
      wrap.className = 'sp-core-quick-paste';

      var trigger = document.createElement('button');
      trigger.type = 'button';
      trigger.className = 'sp-core-quick-paste-trigger';
      trigger.innerHTML = '<span>' + (labels.quickPaste || 'Quick Paste GSMArena') + '</span><svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5.5 7.5 10 12l4.5-4.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      wrap.appendChild(trigger);

      var panel = document.createElement('div');
      panel.className = 'sp-core-quick-paste-panel';
      panel.hidden = true;

      var input = document.createElement('textarea');
      input.className = 'sp-core-quick-paste-input';
      input.rows = 8;
      input.placeholder = labels.quickPastePlaceholder || 'Paste one GSMArena section here. Markdown links and mobile copy text will be cleaned automatically.';
      panel.appendChild(input);

      var actions = document.createElement('div');
      actions.className = 'sp-core-quick-paste-actions';

      var parse = document.createElement('button');
      parse.type = 'button';
      parse.className = 'sp-core-quick-paste-parse';
      parse.textContent = labels.parseFill || 'Parse & Fill';
      actions.appendChild(parse);

      var close = document.createElement('button');
      close.type = 'button';
      close.className = 'sp-core-quick-paste-close';
      close.textContent = labels.close || 'Close';
      actions.appendChild(close);
      panel.appendChild(actions);

      var report = document.createElement('div');
      report.className = 'sp-core-quick-paste-report';
      report.textContent = labels.quickPasteReady || 'Ready to parse GSMArena section text.';
      panel.appendChild(report);

      wrap.appendChild(panel);
      card.appendChild(wrap);

      function setOpen(isOpen) {
        panel.hidden = !isOpen;
        trigger.classList.toggle('is-open', isOpen);
        if (isOpen) input.focus();
      }

      trigger.addEventListener('click', function () {
        setOpen(panel.hidden);
      });
      close.addEventListener('click', function () {
        setOpen(false);
      });

      parse.addEventListener('click', function () {
        var pairs = parseQuickPastePairs(input.value, groupKey);
        var filled = 0;
        var skipped = [];

        pairs.forEach(function (pair) {
          var field = fieldForQuickLabel(pair.label, groupKey);
          if (!field) {
            skipped.push(pair.label);
            return;
          }
          if (applyValueToField(field, pair.value)) {
            filled += 1;
          } else {
            skipped.push(pair.label);
          }
        });

        var message = filled + ' value' + (filled === 1 ? '' : 's') + ' filled.';
        if (skipped.length) {
          message += ' Skipped: ' + unique(skipped).join(', ') + '.';
        }
        report.textContent = message;
        report.classList.toggle('is-success', filled > 0);
      });
    });
  }
  function textOf(node) {
    return clean((node && node.textContent) || '');
  }

  function metaTextOf(node) {
    if (!node || !node.getAttribute) return '';
    return [
      node.getAttribute('aria-label') || '',
      node.getAttribute('title') || '',
      node.getAttribute('data-tooltip') || '',
      node.getAttribute('data-label') || '',
      textOf(node)
    ].join(' ');
  }

  function isInsideClassicMetaBoxes(node) {
    return !!(node && node.closest && (node.closest('#poststuff') || node.closest('#post-body') || node.closest('.edit-post-meta-boxes-area')));
  }

  function hideNodeSoft(node) {
    if (!node || !node.style || node.dataset.spCoreSeoHidden === '1') return;
    node.dataset.spCoreSeoHidden = '1';
    node.style.setProperty('display', 'none', 'important');
    node.style.setProperty('visibility', 'hidden', 'important');
    node.setAttribute('aria-hidden', 'true');
  }

  function maybeHideSeopressToolbarControl(node) {
    if (!node || !node.matches || isInsideClassicMetaBoxes(node)) return;

    var text = normalize(metaTextOf(node));
    var className = normalize(node.className || '');
    var id = normalize(node.id || '');

    var looksSeopress =
      text === 'seo' ||
      text === 'no score' ||
      text.indexOf('seo score') !== -1 ||
      text.indexOf('seopress') !== -1 ||
      className.indexOf('seopress') !== -1 ||
      id.indexOf('seopress') !== -1;

    if (!looksSeopress) return;

    var headerScope = node.closest('.edit-post-header, .editor-header, .interface-interface-skeleton__header, .edit-post-header-toolbar, .edit-post-header__toolbar, .components-toolbar, .components-toolbar-group, .block-editor, .interface-interface-skeleton');
    if (!headerScope) return;

    var wrapper = node.closest('.components-dropdown, .components-button, .interface-pinned-items button, .edit-post-header-toolbar__left > *, .edit-post-header__toolbar > *, .editor-header__toolbar > *') || node;
    hideNodeSoft(wrapper);
  }

  function maybeCloseOrHideSeopressUniversalPanel(node) {
    if (!node || !node.querySelector || isInsideClassicMetaBoxes(node)) return;

    var text = normalize(textOf(node));
    if (!text) return;

    var hasUniversalSeoTabs =
      text.indexOf('titles & metas') !== -1 &&
      text.indexOf('social') !== -1 &&
      (text.indexOf('schemas') !== -1 || text.indexOf('content analysis') !== -1 || text.indexOf('redirection') !== -1);

    if (!hasUniversalSeoTabs) return;

    var close = node.querySelector('button[aria-label*="Close"], button[aria-label*="close"], button.components-button[aria-label*="Close"], button.components-button[aria-label*="close"]');
    if (close && !close.dataset.spCoreSeoCloseTried) {
      close.dataset.spCoreSeoCloseTried = '1';
      close.click();
      return;
    }

    hideNodeSoft(node);
  }

  function guardSeopressUniversalUI() {
    // Hide the toolbar trigger. This prevents the large mobile Universal SEO panel from covering Phone Specifications.
    document.querySelectorAll('button, a[role="button"], [role="button"]').forEach(maybeHideSeopressToolbarControl);

    // If the panel is already open, close/hide only the Universal/Gutenberg panel outside the classic metabox area.
    document.querySelectorAll('.components-modal__frame, .components-popover, .interface-complementary-area, .interface-interface-skeleton__sidebar, [class*="seopress"], [id*="seopress"], section, aside').forEach(maybeCloseOrHideSeopressUniversalPanel);
  }


  function cleanupPhoneDescriptionEditor() {
    var root = document.getElementById('acf-group_sp_core_phone_description');
    if (!root || root.dataset.spCoreDescriptionCleaned === '1') {
      if (!root) return;
    }

    root.querySelectorAll('.quicktags-toolbar, .wp-editor-tabs, .wp-switch-editor, .mce-statusbar, .wp-editor-container > div[id$="_toolbar"], .wp-editor-container > div[id*="quicktags"]').forEach(function (node) {
      hideNodeSoft(node);
    });

    root.dataset.spCoreDescriptionCleaned = '1';
  }

  function initPhoneReviewEditor() {
    document.querySelectorAll('[data-sp-core-review-editor]').forEach(function (editor) {
      if (editor.dataset.spCoreReviewBound === '1') {
        refreshPhoneReviewEditor(editor);
        return;
      }
      editor.dataset.spCoreReviewBound = '1';

      editor.addEventListener('click', function (event) {
        var toggle = event.target.closest('[data-review-toggle]');
        if (toggle) {
          event.preventDefault();
          var toggleSection = toggle.closest('[data-review-section]');
          if (!toggleSection) return;
          var collapsed = !toggleSection.classList.contains('is-collapsed');
          toggleSection.classList.toggle('is-collapsed', collapsed);
          toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
          return;
        }

        var add = event.target.closest('[data-review-add]');
        if (add) {
          event.preventDefault();
          var section = add.closest('[data-review-section]');
          var list = section ? section.querySelector('[data-review-list]') : null;
          var template = section ? section.querySelector('template[data-review-template]') : null;
          if (!section || !list || !template || !template.content) {
            return;
          }
          var item = template.content.firstElementChild.cloneNode(true);
          list.appendChild(item);
          refreshPhoneReviewSection(section);
          var input = item.querySelector('input[type="text"]');
          if (input) {
            input.focus({ preventScroll: true });
          }
          return;
        }

        var remove = event.target.closest('[data-review-remove]');
        if (remove) {
          event.preventDefault();
          var row = remove.closest('[data-review-item]');
          var section = remove.closest('[data-review-section]');
          if (!row || !section) {
            return;
          }
          var list = section.querySelector('[data-review-list]');
          var rows = list ? list.querySelectorAll('[data-review-item]') : [];
          if (rows.length <= 1) {
            var input = row.querySelector('input[type="text"]');
            if (input) {
              input.value = '';
              input.focus({ preventScroll: true });
            }
          } else {
            row.remove();
          }
          refreshPhoneReviewSection(section);
        }
      });

      editor.addEventListener('input', function (event) {
        if (event.target.matches('[data-review-item] input[type="text"]')) {
          var section = event.target.closest('[data-review-section]');
          if (section) {
            refreshPhoneReviewSection(section);
          }
        }
      });

      refreshPhoneReviewEditor(editor);
    });
  }

  function refreshPhoneReviewEditor(editor) {
    editor.querySelectorAll('[data-review-section]').forEach(refreshPhoneReviewSection);
  }

  function refreshPhoneReviewSection(section) {
    var rows = Array.prototype.slice.call(section.querySelectorAll('[data-review-item]'));
    var filled = 0;
    rows.forEach(function (row, index) {
      var indexNode = row.querySelector('[data-review-index]');
      if (indexNode) {
        indexNode.textContent = String(index + 1).padStart(2, '0');
      }
      var input = row.querySelector('input[type="text"]');
      if (input && input.value.trim() !== '') {
        filled += 1;
      }
    });

    var count = section.querySelector('[data-review-count]');
    if (count) {
      count.textContent = filled + (filled === 1 ? ' item' : ' items');
    }
  }

  function orderPhoneEditorMetaboxes() {
    var ordered = [
      '.sp-core-global-quick-paste',
      '#acf-group_sp_core_phone_description',
      '#acf-group_sp_core_phone_gallery',
      '#sp_core_phone_product_review',
      '#acf-group_sp_core_seopress_seo',
      '#sp_core_seopress_phone_fallback',
      '#acf-group_sp_core_phone_specs'
    ];

    var nodes = ordered.map(function (selector) {
      return document.querySelector(selector);
    }).filter(Boolean);

    if (!nodes.length) return;

    var container = document.querySelector('#normal-sortables') || nodes[0].parentNode;
    if (!container) return;

    nodes.forEach(function (node) {
      if (node.parentNode && node.parentNode !== container) {
        return;
      }
      if (node.parentNode === container) {
        container.appendChild(node);
      }
    });
  }


  function normalizePhoneEditorWidth() {
    var containerSelectors = [
      '.edit-post-layout__metaboxes',
      '.edit-post-meta-boxes-area',
      '.edit-post-meta-boxes-area__container',
      '#poststuff',
      '#post-body',
      '#post-body-content',
      '#postbox-container-1',
      '#postbox-container-2',
      '.postbox-container',
      '#normal-sortables',
      '#advanced-sortables',
      '.meta-box-sortables'
    ];

    document.querySelectorAll(containerSelectors.join(',')).forEach(function (node) {
      if (!node || !node.style) return;
      node.style.setProperty('width', '100%', 'important');
      node.style.setProperty('max-width', 'none', 'important');
      node.style.setProperty('margin-left', '0', 'important');
      node.style.setProperty('margin-right', '0', 'important');
      node.style.setProperty('box-sizing', 'border-box', 'important');
      node.style.setProperty('overflow-x', 'hidden', 'important');

      if (node.matches('#normal-sortables, #advanced-sortables, .edit-post-meta-boxes-area__container')) {
        node.style.setProperty('padding-left', '3px', 'important');
        node.style.setProperty('padding-right', '3px', 'important');
      } else {
        node.style.setProperty('padding-left', '0', 'important');
        node.style.setProperty('padding-right', '0', 'important');
      }
    });

    document.querySelectorAll('#normal-sortables > .postbox, #advanced-sortables > .postbox, .edit-post-meta-boxes-area .postbox, .sp-core-global-quick-paste').forEach(function (node) {
      if (!node || !node.style) return;
      node.style.setProperty('width', '100%', 'important');
      node.style.setProperty('max-width', '100%', 'important');
      node.style.setProperty('margin-left', '0', 'important');
      node.style.setProperty('margin-right', '0', 'important');
      node.style.setProperty('box-sizing', 'border-box', 'important');
    });
  }

  function getSeopressMetaboxRoot() {
    return document.querySelector('#acf-group_sp_core_seopress_seo') || document.querySelector('#sp_core_seopress_phone_fallback');
  }

  function seoFieldByName(root, name) {
    if (!root) return null;
    return root.querySelector('.acf-field[data-name="' + name + '"]');
  }

  function seoInputFromField(field) {
    if (!field) return null;
    return field.querySelector('input[type="text"], input[type="url"], textarea');
  }

  function seoText(value) {
    return (value || '').replace(/\s+/g, ' ').trim();
  }

  function seoMetric(count, min, max) {
    var score = 0;
    if (count <= 0) score = 0;
    else if (count >= min && count <= max) score = 100;
    else if (count < min) score = Math.max(25, Math.round((count / Math.max(min, 1)) * 100));
    else score = Math.max(35, 100 - (count - max) * 2);
    return Math.max(0, Math.min(100, score));
  }

  function seoScoreModel(root) {
    var titleInput = seoInputFromField(seoFieldByName(root, 'sp_core_seopress_meta_title'));
    var descInput = seoInputFromField(seoFieldByName(root, 'sp_core_seopress_meta_description'));
    var keywordInput = seoInputFromField(seoFieldByName(root, 'sp_core_seopress_focus_keyword'));
    var canonicalInput = seoInputFromField(seoFieldByName(root, 'sp_core_seopress_canonical_url'));

    var title = seoText(titleInput ? titleInput.value : '');
    var desc = seoText(descInput ? descInput.value : '');
    var keyword = seoText(keywordInput ? keywordInput.value : '');
    var canonical = seoText(canonicalInput ? canonicalInput.value : '');

    var total = Math.round(
      seoMetric(title.length, 50, 60) * 0.35 +
      seoMetric(desc.length, 120, 160) * 0.35 +
      (keyword.length ? 100 : 30) * 0.15 +
      (canonical.indexOf('http') === 0 ? 100 : 35) * 0.15
    );

    return { title: title, desc: desc, keyword: keyword, canonical: canonical, titleCount: title.length, descCount: desc.length, keywordCount: keyword.length, total: total };
  }

  function seoUiIcon(name) {
    var icons = {
      check: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.9"/><path d="m8.6 12 2.1 2.2 4.8-5" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      spark: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3.5 13.8 9l5.2 1.8-5.2 1.8L12 18l-1.8-5.4L5 10.8 10.2 9 12 3.5Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M18.5 4.5v2M17.5 5.5h2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
      dots: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="12" cy="19" r="1.7"/></svg>',
      tt: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 6h14M9 6v12M14 10h6M17 10v8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      note: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="5" y="3.5" width="14" height="17" rx="1.5" stroke="currentColor" stroke-width="1.9"/><path d="M9 8.5h6M9 12h6M9 15.5h4" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
      target: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.9"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.9"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
      link: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M10 13.5 14 9.5" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/><path d="M8.7 16.3 6.9 18a4 4 0 1 1-5.7-5.7L3 10.6" transform="translate(5 1)" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/><path d="m15.3 7.7 1.8-1.7a4 4 0 0 1 5.7 5.7L21 13.4" transform="translate(-3 1)" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      search: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4.5" y="4.5" width="15" height="15" rx="2" stroke="currentColor" stroke-width="1.9"/><circle cx="10.5" cy="10.5" r="3.5" stroke="currentColor" stroke-width="1.9"/><path d="m13.5 13.5 3.5 3.5" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
      desktop: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="5" width="16" height="11" rx="1.5" stroke="currentColor" stroke-width="1.9"/><path d="M9 19h6M12 16v3" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
      mobile: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="8" y="3.5" width="8" height="17" rx="1.8" stroke="currentColor" stroke-width="1.9"/><circle cx="12" cy="17.5" r=".9" fill="currentColor"/></svg>',
      share: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="7" cy="12" r="2.2" stroke="currentColor" stroke-width="1.9"/><circle cx="17" cy="6" r="2.2" stroke="currentColor" stroke-width="1.9"/><circle cx="17" cy="18" r="2.2" stroke="currentColor" stroke-width="1.9"/><path d="m8.9 10.9 5.3-3.1M8.9 13.1l5.3 3.1" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
      globe: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.9"/><path d="M3.5 12h17M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
      x: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 5l14 14M19 5 5 19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
      image: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="5" width="17" height="14" rx="2" stroke="currentColor" stroke-width="1.9"/><circle cx="9" cy="10" r="1.7" stroke="currentColor" stroke-width="1.7"/><path d="m4.5 17.5 4.5-4 3 2.4 3.5-3.4 4 3.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'
    };
    return icons[name] || icons.check;
  }

  function splitStatusLabel(text) {
    if (text === 'Auto-detect On') return '<span>Auto-detect</span><span>On</span>';
    if (text === 'SEO Ready') return '<span>SEO</span><span>Ready</span>';
    if (text === 'Good Score') return '<span>Good</span><span>Score</span>';
    if (text === 'Okay Score') return '<span>Okay</span><span>Score</span>';
    if (text === 'Needs Work') return '<span>Needs</span><span>Work</span>';
    return '<span>' + text + '</span>';
  }

  function ensureSeopressSummary(root, model) {
    var inside = root.querySelector('.inside') || root;
    if (!inside) return;
    var bar = inside.querySelector('.sp-seo-statusbar');
    if (!bar) {
      bar = document.createElement('div');
      bar.className = 'sp-seo-statusbar';
      inside.insertBefore(bar, inside.firstChild);
    }
    var label = model.total >= 80 ? 'Good Score' : (model.total >= 60 ? 'Okay Score' : 'Needs Work');
    bar.innerHTML =
      '<div class="sp-seo-pill">' + seoUiIcon('check') + '<strong>' + splitStatusLabel('Auto-detect On') + '</strong></div>' +
      '<div class="sp-seo-pill">' + seoUiIcon('spark') + '<strong>' + splitStatusLabel('SEO Ready') + '</strong></div>' +
      '<div class="sp-seo-pill"><span class="sp-seo-pill-number">' + model.total + '</span><strong>' + splitStatusLabel(label) + '</strong></div>' +
      '<button type="button" class="sp-seo-menu" aria-label="More options">' + seoUiIcon('dots') + '</button>';
  }

  function ensureSeoFieldShell(field, iconName) {
    if (!field) return;
    field.classList.add('sp-seo-row');
    var labelWrap = field.querySelector('.acf-label');
    var inputWrap = field.querySelector('.acf-input');
    if (!labelWrap || !inputWrap) return;

    var shell = field.querySelector('.sp-seo-row-shell');
    if (!shell) {
      shell = document.createElement('div');
      shell.className = 'sp-seo-row-shell';
      var icon = document.createElement('div');
      icon.className = 'sp-seo-row-icon';
      var body = document.createElement('div');
      body.className = 'sp-seo-row-body';
      shell.appendChild(icon);
      shell.appendChild(body);
      body.appendChild(labelWrap);
      body.appendChild(inputWrap);
      field.appendChild(shell);
    }
    var iconNode = shell.querySelector('.sp-seo-row-icon');
    if (iconNode) iconNode.innerHTML = seoUiIcon(iconName);
  }

  function prepareSeoField(field, config) {
    if (!field || !config) return;
    ensureSeoFieldShell(field, config.icon);
    var labelWrap = field.querySelector('.acf-label');
    var titleNode = labelWrap ? labelWrap.querySelector('label') : null;
    if (!labelWrap || !titleNode) return;

    var top = labelWrap.querySelector('.sp-seo-field-topline');
    if (!top) {
      top = document.createElement('div');
      top.className = 'sp-seo-field-topline';
      labelWrap.insertBefore(top, titleNode);
      top.appendChild(titleNode);
    }
    var count = top.querySelector('.sp-seo-count');
    if (!count) {
      count = document.createElement('span');
      count.className = 'sp-seo-count';
      top.appendChild(count);
    }
    if (config.limit) {
      count.style.display = '';
      count.textContent = config.count + ' / ' + config.limit;
    } else {
      count.style.display = 'none';
      count.textContent = '';
    }
    var note = labelWrap.querySelector('.sp-seo-field-note');
    if (!note) {
      note = document.createElement('p');
      note.className = 'sp-seo-field-note';
      labelWrap.appendChild(note);
    }
    note.textContent = config.note;
    labelWrap.querySelectorAll('p.description').forEach(function (node) {
      if (!node.classList.contains('sp-seo-field-note')) node.style.display = 'none';
    });
  }

  function ensureSerpPreview(root, model) {
    var canonicalField = seoFieldByName(root, 'sp_core_seopress_canonical_url');
    var keywordField = seoFieldByName(root, 'sp_core_seopress_focus_keyword');
    var anchor = canonicalField || keywordField || seoFieldByName(root, 'sp_core_seopress_meta_description');
    var parent = anchor && anchor.parentNode ? anchor.parentNode : (root.querySelector('.acf-fields') || root.querySelector('.inside') || root);
    if (!parent) return;

    var preview = root.querySelector('.sp-seo-preview-section');
    if (!preview) {
      preview = document.createElement('div');
      preview.className = 'sp-seo-preview-section';
    }

    if (canonicalField && canonicalField.parentNode) {
      canonicalField.parentNode.insertBefore(preview, canonicalField.nextSibling);
    } else if (anchor && anchor.parentNode) {
      anchor.parentNode.insertBefore(preview, anchor.nextSibling);
    } else if (!preview.parentNode) {
      parent.appendChild(preview);
    }

    var permalink = model.canonical || window.location.href;
    var hostname = 'spesification.com';
    try { hostname = new URL(permalink).hostname || hostname; } catch (e) {}

    preview.innerHTML = '<div class="sp-seo-section-head">' +
      '<div class="sp-seo-section-titlebox">' + seoUiIcon('search') + '<div><strong>SERP Preview</strong><span>Preview how this content can appear in search.</span></div></div>' +
      '<div class="sp-seo-device-toggle"><button type="button" class="is-active" aria-label="Desktop preview">' + seoUiIcon('desktop') + '</button><button type="button" aria-label="Mobile preview">' + seoUiIcon('mobile') + '</button></div>' +
      '</div>' +
      '<div class="sp-seo-serp-card">' +
      '<div class="sp-seo-serp-line1"><div class="sp-seo-serp-brand"><span class="sp-seo-serp-logo">S</span><div><p class="sp-seo-serp-host">' + hostname + '</p><p class="sp-seo-serp-url">' + permalink + '</p></div></div><button type="button" class="sp-seo-menu" aria-label="SERP options">' + seoUiIcon('dots') + '</button></div>' +
      '<p class="sp-seo-serp-title">' + (model.title || 'Add a meta title') + '</p>' +
      '<p class="sp-seo-serp-desc">' + (model.desc || 'Add a meta description to preview how this page can appear in search results.') + '</p>' +
      '</div>';
  }

  function seoEscape(value) {
    return (value == null ? '' : String(value)).replace(/[&<>"']/g, function (char) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char];
    });
  }

  function buildSocialPreviewCard(panel, type, root, model) {
    if (!panel) return;
    var titleName = type === 'og' ? 'sp_core_seopress_social_title' : 'sp_core_seopress_twitter_title';
    var descName = type === 'og' ? 'sp_core_seopress_social_description' : 'sp_core_seopress_twitter_description';
    var imgName = type === 'og' ? 'sp_core_seopress_social_image' : 'sp_core_seopress_twitter_image';

    var card = panel.querySelector('.sp-seo-social-preview');
    if (!card) {
      card = document.createElement('div');
      card.className = 'sp-seo-social-preview';
      panel.insertBefore(card, panel.firstChild);
    }

    var permalink = (model && model.canonical) || window.location.href;
    var hostname = 'spesification.com';
    try { hostname = new URL(permalink).hostname || hostname; } catch (e) {}

    function render() {
      var imgInput = seoInputFromField(seoFieldByName(root, imgName));
      var titleInput = seoInputFromField(seoFieldByName(root, titleName));
      var descInput = seoInputFromField(seoFieldByName(root, descName));
      var img = imgInput ? (imgInput.value || '').trim() : '';
      var title = seoText(titleInput ? titleInput.value : '') || (model && model.title) || 'Add a social title';
      var desc = seoText(descInput ? descInput.value : '') || (model && model.desc) || 'Add a social description to preview the share card.';

      var media = img
        ? '<div class="sp-seo-social-media"><img src="' + seoEscape(img) + '" alt="" referrerpolicy="no-referrer" onerror="this.closest(\'.sp-seo-social-media\').classList.add(\'is-broken\');this.remove();" /><span class="sp-seo-social-media-fallback">' + seoUiIcon('image') + '<em>Image not reachable</em></span></div>'
        : '<div class="sp-seo-social-media is-empty"><span class="sp-seo-social-media-fallback">' + seoUiIcon('image') + '<em>No image set</em></span></div>';

      card.innerHTML =
        '<span class="sp-seo-social-preview-tag">' + (type === 'og' ? 'Open Graph preview' : 'Twitter / X preview') + '</span>' +
        media +
        '<div class="sp-seo-social-copy">' +
          '<p class="sp-seo-social-host">' + seoEscape(hostname) + '</p>' +
          '<p class="sp-seo-social-title">' + seoEscape(title) + '</p>' +
          '<p class="sp-seo-social-desc">' + seoEscape(desc) + '</p>' +
        '</div>';
    }

    [titleName, descName, imgName].forEach(function (name) {
      var input = seoInputFromField(seoFieldByName(root, name));
      if (input && !input.getAttribute('data-sp-social-bound')) {
        input.setAttribute('data-sp-social-bound', '1');
        input.addEventListener('input', render);
        input.addEventListener('change', render);
      }
    });

    render();
  }

  function ensureSocialTabs(root, model) {
    var ogFields = [seoFieldByName(root, 'sp_core_seopress_social_title'), seoFieldByName(root, 'sp_core_seopress_social_description'), seoFieldByName(root, 'sp_core_seopress_social_image')].filter(Boolean);
    var twFields = [seoFieldByName(root, 'sp_core_seopress_twitter_title'), seoFieldByName(root, 'sp_core_seopress_twitter_description'), seoFieldByName(root, 'sp_core_seopress_twitter_image')].filter(Boolean);
    if (!ogFields.length && !twFields.length) return;
    var preview = root.querySelector('.sp-seo-preview-section') || seoFieldByName(root, 'sp_core_seopress_canonical_url');
    if (!preview || !preview.parentNode) return;
    var section = root.querySelector('.sp-seo-social-section');
    if (!section) {
      section = document.createElement('div');
      section.className = 'sp-seo-social-section';
      preview.parentNode.insertBefore(section, preview.nextSibling);
    }
    if (!section.querySelector('.sp-seo-tabs')) {
      section.innerHTML = '<div class="sp-seo-section-head"><div class="sp-seo-section-titlebox">' + seoUiIcon('share') + '<div><strong>Social</strong><span>Optimize how this content appears when shared.</span></div></div></div>' +
        '<div class="sp-seo-tabs"><button type="button" class="is-active" data-target="og">' + seoUiIcon('globe') + '<span>Open Graph</span></button><button type="button" data-target="tw">' + seoUiIcon('x') + '<span>Twitter / X</span></button></div>' +
        '<div class="sp-seo-tab-panel is-active" data-panel="og"></div><div class="sp-seo-tab-panel" data-panel="tw"></div>';
    }
    var ogPanel = section.querySelector('[data-panel="og"]');
    var twPanel = section.querySelector('[data-panel="tw"]');
    ogFields.forEach(function (field) { ogPanel.appendChild(field); });
    twFields.forEach(function (field) { twPanel.appendChild(field); });
    buildSocialPreviewCard(ogPanel, 'og', root, model);
    buildSocialPreviewCard(twPanel, 'tw', root, model);
    section.querySelectorAll('.sp-seo-tabs button').forEach(function (button) {
      button.onclick = function () {
        var target = button.getAttribute('data-target');
        section.querySelectorAll('.sp-seo-tabs button').forEach(function (btn) { btn.classList.toggle('is-active', btn === button); });
        section.querySelectorAll('.sp-seo-tab-panel').forEach(function (panel) { panel.classList.toggle('is-active', panel.getAttribute('data-panel') === target); });
      };
    });
  }

  function ensureVisibilityToggles(root) {
    var noindex = seoFieldByName(root, 'sp_core_seopress_noindex');
    var nofollow = seoFieldByName(root, 'sp_core_seopress_nofollow');
    if (!noindex && !nofollow) return;
    var social = root.querySelector('.sp-seo-social-section') || root.querySelector('.sp-seo-preview-section');
    if (!social || !social.parentNode) return;
    var section = root.querySelector('.sp-seo-toggles-section');
    if (!section) {
      section = document.createElement('div');
      section.className = 'sp-seo-toggles-section';
      social.parentNode.insertBefore(section, social.nextSibling);
    }
    if (!section.querySelector('.sp-seo-toggle-row')) {
      section.innerHTML = '<div class="sp-seo-section-head"><div class="sp-seo-section-titlebox">' + seoUiIcon('target') + '<div><strong>Search Visibility</strong><span>Optional indexing controls.</span></div></div></div><div class="sp-seo-toggle-row"></div>';
    }
    var row = section.querySelector('.sp-seo-toggle-row');
    [noindex, nofollow].filter(Boolean).forEach(function (field) {
      field.classList.add('sp-seo-toggle-card');
      row.appendChild(field);
    });
  }

  function hideFloatingSeopressControls() {
    var customRoot = getSeopressMetaboxRoot();
    var viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
    var candidates = [];

    document.querySelectorAll('[class*="seopress"], [id*="seopress"], button, a, [role="button"]').forEach(function (node) {
      candidates.push(node);
    });

    // Some SEOPress universal widgets render as plain fixed divs with only “S” text.
    document.querySelectorAll('body > div, body > aside, body > section, .interface-interface-skeleton__body > div, .interface-interface-skeleton__content > div').forEach(function (node) {
      candidates.push(node);
    });

    candidates.forEach(function (node) {
      if (!node || !node.style || (customRoot && customRoot.contains(node))) return;
      if (node.closest && (node.closest('#wpadminbar') || node.closest('#adminmenuwrap') || node.closest('#acf-group_sp_core_seopress_seo') || node.closest('#sp_core_seopress_phone_fallback'))) return;

      var text = seoText(node.textContent || '').toLowerCase();
      var cls = ((node.className || '') + '').toLowerCase();
      var id = ((node.id || '') + '').toLowerCase();
      var style = window.getComputedStyle ? window.getComputedStyle(node) : null;
      var rect = node.getBoundingClientRect ? node.getBoundingClientRect() : null;
      var nearRight = rect && viewportWidth && rect.right > (viewportWidth - 96) && rect.width <= 120 && rect.height <= 220;
      var isFloating = style && (style.position === 'fixed' || style.position === 'sticky' || style.position === 'absolute');
      var looksSeopress = cls.indexOf('seopress') !== -1 || id.indexOf('seopress') !== -1 || text === 's' || text === 'seo' || text.indexOf('seopress') !== -1;

      if (looksSeopress && (nearRight || isFloating || cls.indexOf('seopress') !== -1 || id.indexOf('seopress') !== -1)) {
        node.style.setProperty('display', 'none', 'important');
        node.style.setProperty('visibility', 'hidden', 'important');
        node.setAttribute('aria-hidden', 'true');
      }
    });
  }

  function initSeopressMetaboxRedesign() {
    var root = getSeopressMetaboxRoot();
    if (!root) return;
    root.classList.add('sp-seo-premium-ready');
    root.querySelectorAll('.sp-seo-section-label, .sp-seo-serp-preview').forEach(function (node) { node.remove(); });

    var model = seoScoreModel(root);
    ensureSeopressSummary(root, model);
    prepareSeoField(seoFieldByName(root, 'sp_core_seopress_meta_title'), { icon: 'tt', limit: 60, count: model.titleCount, note: 'Auto-detected from the Phone title.' });
    prepareSeoField(seoFieldByName(root, 'sp_core_seopress_meta_description'), { icon: 'note', limit: 160, count: model.descCount, note: 'Auto-detected from the Phone description.' });
    prepareSeoField(seoFieldByName(root, 'sp_core_seopress_focus_keyword'), { icon: 'target', limit: 60, count: model.keywordCount, note: 'Auto-detected from the Phone title.' });
    prepareSeoField(seoFieldByName(root, 'sp_core_seopress_canonical_url'), { icon: 'link', limit: 0, count: 0, note: 'Auto-detected from the Phone permalink.' });
    ensureSerpPreview(root, model);
    ensureSocialTabs(root, model);
    ensureVisibilityToggles(root);
    hideFloatingSeopressControls();
  }


  function buildToolbar() {
    // Phone Specification toolbar removed in v0.8.7 for a cleaner mobile workflow.
    return;
  }

  function boot() {
    Object.keys(fields).forEach(function (fieldName) {
      var wrappers = document.querySelectorAll('.acf-field[data-name="' + fieldName + '"]');
      wrappers.forEach(enhanceField);
    });

    document.querySelectorAll('#acf-group_sp_core_phone_specs .acf-field.sp-core-accordion-child').forEach(enhanceField);

    normalizePhoneEditorWidth();
    buildToolbar();
    buildGlobalQuickPastePanel();
    initAccordions();
    // Hide only the native SEOPress top-bar / Universal panel outside the
    // classic metabox area. The custom SEOPress SEO metabox remains visible.
    guardSeopressUniversalUI();
    cleanupPhoneDescriptionEditor();
    initPhoneReviewEditor();
    initSeopressMetaboxRedesign();
    orderPhoneEditorMetaboxes();

    if (!booted) {
      booted = true;
      var target = document.querySelector('#poststuff') || document.body;
      if (target && 'MutationObserver' in window) {
        var observer = new MutationObserver(function () {
          Object.keys(fields).forEach(function (fieldName) {
            var wrappers = document.querySelectorAll('.acf-field[data-name="' + fieldName + '"]');
            wrappers.forEach(enhanceField);
          });
          document.querySelectorAll('#acf-group_sp_core_phone_specs .acf-field.sp-core-accordion-child').forEach(enhanceField);
          normalizePhoneEditorWidth();
          buildToolbar();
          buildGlobalQuickPastePanel();
          initAccordions();
          // Hide only the native SEOPress top-bar / Universal panel outside the
          // classic metabox area. The custom SEOPress SEO metabox remains visible.
          guardSeopressUniversalUI();
          cleanupPhoneDescriptionEditor();
                initPhoneReviewEditor();
          initSeopressMetaboxRedesign();
          orderPhoneEditorMetaboxes();
        });
        observer.observe(target, { childList: true, subtree: true });
      }
    }
  }

  document.addEventListener('click', function (event) {
    if (!event.target.closest('.sp-core-spec-suggest-list') && !event.target.closest('.sp-core-valuebox-enabled')) {
      closeActiveList();
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
