(function () {
  'use strict';

  document.querySelectorAll('.sp-core-modules-page .sp-core-toggle-input').forEach((input) => {
    input.addEventListener('change', () => {
      const row = input.closest('.sp-core-module-row');
      if (!row || input.disabled) return;
      const enabled = input.checked;
      row.classList.toggle('is-enabled', enabled);
      row.classList.toggle('is-disabled', !enabled);
      const status = row.querySelector('.sp-core-module-status');
      if (status) status.textContent = enabled ? 'Enabled' : 'Disabled';
    });
  });

  const config = window.spCoreDashboard || {};
  const root = document.querySelector('[data-sp-core-dashboard]');
  if (!root || !config.ajaxUrl || !config.nonce) return;

  const stateClass = (state) => {
    state = String(state || 'working').replace(/_/g, '-');
    return ['is-active', 'is-detected', 'is-working', 'is-not-working'].includes('is-' + state) ? 'is-' + state : 'is-working';
  };

  const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
  const escapeAttr = escapeHtml;

  const mini = (item) => {
    const state = stateClass(item.state);
    return `
      <div class="sp-core-mini-status ${state}" data-sp-core-mini="${escapeAttr(item.key || '')}">
        <span class="sp-core-pulse" aria-hidden="true"></span>
        <div class="sp-core-status-copy"><strong>${escapeHtml(item.label || '')}</strong><p>${escapeHtml(item.message || '')}</p></div>
        <em>${escapeHtml(item.status || 'Working')}</em>
      </div>`;
  };

  const status = (item) => {
    const state = stateClass(item.state);
    return `
      <div class="sp-core-status-item ${state}" data-sp-core-check="${escapeAttr(item.key || '')}">
        <span class="sp-core-pulse" aria-hidden="true"></span>
        <div class="sp-core-status-copy"><strong>${escapeHtml(item.label || '')}</strong><p>${escapeHtml(item.message || '')}</p></div>
        <em>${escapeHtml(item.status || 'Working')}</em>
      </div>`;
  };

  async function scan(force = false) {
    root.classList.add('is-scanning');
    try {
      const body = new URLSearchParams({
        action: 'sp_core_dashboard_scan',
        nonce: config.nonce,
        force: force ? '1' : ''
      });
      const response = await fetch(config.ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
        body
      });
      const json = await response.json();
      if (!json || !json.success || !json.data) return;
      render(json.data);
    } catch (error) {
      const title = root.querySelector('[data-sp-core-summary-title]');
      const copy = root.querySelector('[data-sp-core-summary-copy]');
      if (title) title.textContent = 'Not Working';
      if (copy) copy.textContent = 'Scanner could not refresh.';
      root.classList.add('has-scan-error');
    } finally {
      root.classList.remove('is-scanning');
    }
  }

  function render(data) {
    const summary = data.overall || {};
    const summaryBox = root.querySelector('[data-sp-core-summary]');
    const title = root.querySelector('[data-sp-core-summary-title]');
    const copy = root.querySelector('[data-sp-core-summary-copy]');
    if (summaryBox) {
      summaryBox.classList.remove('is-active', 'is-detected', 'is-working', 'is-not-working');
      summaryBox.classList.add(stateClass(summary.state || 'working'));
    }
    if (title) title.textContent = summary.title || 'Working';
    if (copy) {
      const suffix = data.generated_at ? ` Last scan: ${data.generated_at}.` : '';
      copy.textContent = (summary.message || 'System snapshot ready.') + suffix;
    }

    if (Array.isArray(data.stats)) {
      data.stats.forEach((stat) => {
        const node = root.querySelector(`[data-sp-core-stat="${CSS.escape(stat.key)}"]`);
        if (node) node.textContent = Number(stat.value || 0).toLocaleString();
      });
    }

    const statusGrid = root.querySelector('[data-sp-core-status-grid]');
    if (statusGrid && Array.isArray(data.checks)) statusGrid.innerHTML = data.checks.map(status).join('');

    const integrity = root.querySelector('[data-sp-core-integrity]');
    if (integrity && Array.isArray(data.integrity)) integrity.innerHTML = data.integrity.map(mini).join('');

    const registry = root.querySelector('[data-sp-core-registry]');
    if (registry && Array.isArray(data.registry)) registry.innerHTML = data.registry.map(mini).join('');

    const template = root.querySelector('[data-sp-core-template]');
    if (template && Array.isArray(data.template)) template.innerHTML = data.template.map(mini).join('');

    const integrations = root.querySelector('[data-sp-core-integrations]');
    if (integrations && Array.isArray(data.integrations)) integrations.innerHTML = data.integrations.map(mini).join('');

    const security = root.querySelector('[data-sp-core-security]');
    if (security && Array.isArray(data.security)) security.innerHTML = data.security.map(mini).join('');
  }

  root.querySelectorAll('[data-sp-core-rescan]').forEach((button) => {
    button.addEventListener('click', () => scan(true));
  });
})();

(() => {
  'use strict';

  const initTermImagePickers = () => {
    document.querySelectorAll('[data-sp-term-image-row]').forEach((row) => {
      if (row.dataset.spTermImageReady === '1') return;
      row.dataset.spTermImageReady = '1';

      const input = row.querySelector('[data-sp-term-image-input]');
      const preview = row.querySelector('[data-sp-term-image-preview]');
      const upload = row.querySelector('[data-sp-term-image-upload]');
      const remove = row.querySelector('[data-sp-term-image-remove]');
      if (!input || !preview || !upload) return;

      const placeholder = preview.innerHTML || '<span>—</span>';

      const setPreview = (id, url) => {
        input.value = id ? String(id) : '0';
        if (url) {
          preview.innerHTML = `<img src="${String(url).replace(/"/g, '&quot;')}" alt="">`;
          preview.classList.add('has-image');
        } else {
          preview.innerHTML = placeholder.indexOf('<img') === -1 ? placeholder : '<span>—</span>';
          preview.classList.remove('has-image');
        }
      };

      let frame = null;
      upload.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();

        if (!window.wp || !wp.media) {
          window.alert('WordPress Media Library belum siap. Refresh halaman lalu coba lagi.');
          return;
        }

        if (!frame) {
          frame = wp.media({
            title: 'Select term image',
            button: { text: 'Use this image' },
            library: { type: 'image' },
            multiple: false
          });

          frame.on('select', () => {
            const attachment = frame.state().get('selection').first();
            if (!attachment) return;
            const data = attachment.toJSON();
            const thumb = data.sizes && data.sizes.thumbnail && data.sizes.thumbnail.url ? data.sizes.thumbnail.url : data.url;
            setPreview(data.id || 0, thumb || '');
          });
        }

        frame.open();
      });

      if (remove) {
        remove.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          setPreview(0, '');
        });
      }
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTermImagePickers);
  } else {
    initTermImagePickers();
  }
})();
