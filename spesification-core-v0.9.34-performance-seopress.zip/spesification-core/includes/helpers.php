<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('sp_core_charset')) {
    /**
     * Cached blog charset. get_bloginfo('charset') is called inside hot-path
     * string cleaners that run dozens of times per request, so we resolve it
     * once per request instead of repeatedly hitting the options/bloginfo layer.
     */
    function sp_core_charset() {
        static $charset = null;
        if ($charset === null) {
            $charset = get_bloginfo('charset');
            if (!is_string($charset) || $charset === '') {
                $charset = 'UTF-8';
            }
        }
        return $charset;
    }
}

if (!function_exists('sp_core_clean_string')) {
    function sp_core_clean_string($value) {
        if (is_array($value)) {
            $parts = [];
            array_walk_recursive($value, static function ($item) use (&$parts) {
                if (is_scalar($item)) {
                    $item = trim(wp_strip_all_tags((string) $item));
                    if ($item !== '') {
                        $parts[] = $item;
                    }
                }
            });
            return implode(', ', array_values(array_unique($parts)));
        }

        if (is_object($value)) {
            $value = method_exists($value, '__toString') ? (string) $value : '';
        } elseif (!is_scalar($value) && $value !== null) {
            $value = '';
        }

        $value = html_entity_decode((string) $value, ENT_QUOTES, sp_core_charset());
        $value = wp_strip_all_tags($value);
        $value = preg_replace('/\s+/', ' ', $value);
        return trim((string) $value);
    }
}

if (!function_exists('sp_core_clean_slug')) {
    function sp_core_clean_slug($value) {
        $value = sp_core_clean_string($value);
        return sanitize_title($value);
    }
}

if (!function_exists('sp_core_get_field')) {
    function sp_core_get_field($key, $post_id = null, $default = '') {
        $post_id = $post_id ?: get_the_ID();
        if (!$post_id || !$key) {
            return $default;
        }

        if (function_exists('get_field')) {
            $value = get_field($key, $post_id);
            if ($value !== null && $value !== false && $value !== '') {
                return $value;
            }
        }

        $meta = get_post_meta($post_id, $key, true);
        if ($meta !== null && $meta !== false && $meta !== '') {
            return $meta;
        }

        return $default;
    }
}

if (!function_exists('sp_core_get_phone_price_html')) {
    function sp_core_get_phone_price_html($post_id = null) {
        $post_id = $post_id ?: get_the_ID();
        $price = sp_core_clean_string(sp_core_get_field('price', $post_id, ''));

        if ($price === '') {
            return '<span class="sp-price-unavailable">Check Price</span>';
        }

        return '<span class="sp-price">' . esc_html($price) . '</span>';
    }
}


if (!function_exists('sp_core_clean_description_html')) {
    function sp_core_clean_description_html($value) {
        if (is_array($value) || is_object($value)) {
            $value = '';
        }

        $value = html_entity_decode((string) $value, ENT_QUOTES, sp_core_charset());
        $value = preg_replace('/\x{00a0}/u', ' ', $value);
        $value = trim((string) $value);

        if ($value === '') {
            return '';
        }

        $value = wp_kses_post($value);
        $value = preg_replace("/\r\n|\r/u", "\n", $value);
        $value = preg_replace("/\n{3,}/u", "\n\n", $value);
        return trim((string) $value);
    }
}

if (!function_exists('sp_core_get_phone_description')) {
    function sp_core_get_phone_description($post_id = null, $include_saved = true) {
        $post_id = absint($post_id ?: get_the_ID());
        if (!$post_id || get_post_type($post_id) !== 'phone') {
            return '';
        }

        $candidates = [];
        if ($include_saved) {
            $candidates[] = get_post_meta($post_id, 'phone_description', true);
        }

        // Match the same practical fallback chain used by single-phone.php, while
        // also supporting legacy WooCommerce/product short-description meta.
        $candidates[] = get_post_field('post_excerpt', $post_id);
        $candidates[] = get_post_field('post_content', $post_id);
        $candidates[] = get_post_meta($post_id, '_short_description', true);
        $candidates[] = get_post_meta($post_id, 'short_description', true);
        $candidates[] = get_post_meta($post_id, '_product_short_description', true);
        $candidates[] = get_post_meta($post_id, 'product_short_description', true);

        foreach ($candidates as $candidate) {
            $candidate = sp_core_clean_description_html($candidate);
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }
}

if (!function_exists('sp_core_get_phone_spec_groups')) {
    function sp_core_get_phone_spec_groups($post_id = null) {
        $post_id = $post_id ?: get_the_ID();
        $groups = sp_core_get_field('specification_groups', $post_id, []);

        if (is_array($groups) && !empty($groups)) {
            return $groups;
        }

        $legacy = get_post_meta($post_id, '_sp_legacy_attribute_groups', true);
        return is_array($legacy) ? $legacy : [];
    }
}

if (!function_exists('sp_core_get_phone_specs_raw')) {
    function sp_core_get_phone_specs_raw($post_id = null) {
        $post_id = $post_id ?: get_the_ID();
        $index = get_post_meta($post_id, '_sp_legacy_attribute_index', true);
        if (is_array($index) && $index) {
            $out = [];
            foreach ($index as $label => $value) {
                $label = sp_core_clean_string($label);
                $value = sp_core_clean_string($value);
                if ($label !== '' && $value !== '') {
                    $out[$label] = $value;
                }
            }
            return $out;
        }

        $map = [
            'Release Date' => 'release_date',
            'Network' => 'network',
            'Technology' => 'technology',
            'Speed' => 'speed',
            'SIM' => 'sim',
            'Dimensions' => 'dimensions',
            'Weight' => 'weight',
            'Display' => 'display',
            'Panel Type' => 'panel_type',
            'Size' => 'display_size',
            'Resolution' => 'resolution',
            'Brightness' => 'brightness',
            'Protection' => 'protection',
            'OS' => 'os',
            'Processor' => 'processor',
            'Chipset' => 'chipset',
            'Processor Type' => 'processor_type',
            'CPU' => 'cpu',
            'Cores' => 'cores',
            'RAM' => 'ram',
            'RAM Type' => 'ram_type',
            'Storage' => 'storage',
            'Internal Storage' => 'internal_storage',
            'Main Camera' => 'main_camera',
            'Rear Camera' => 'rear_camera',
            'Rear Video' => 'rear_video',
            'Battery' => 'battery',
            'Capacity' => 'capacity',
            'Battery Type' => 'battery_type',
            'Charging' => 'charging',
            'Quick Charge' => 'quick_charge',
        ];

        $specs = [];
        foreach ($map as $label => $key) {
            $value = sp_core_clean_string(sp_core_get_field($key, $post_id, ''));
            if ($value !== '') {
                $specs[$label] = $value;
            }
        }

        return $specs;
    }
}

if (!function_exists('sp_core_get_phone_payload')) {
    function sp_core_get_phone_payload($post_id, $image_size = 'thumbnail') {
        $post_id = absint($post_id);
        if (!$post_id || get_post_status($post_id) !== 'publish') {
            return null;
        }

        $post_type = get_post_type($post_id);
        if ($post_type !== 'phone') {
            return null;
        }

        return [
            'id' => $post_id,
            'post_type' => 'phone',
            'title' => html_entity_decode(wp_strip_all_tags(get_the_title($post_id)), ENT_QUOTES, sp_core_charset()),
            'slug' => get_post_field('post_name', $post_id),
            'url' => get_permalink($post_id),
            'img' => get_the_post_thumbnail_url($post_id, $image_size) ?: '',
            'price' => sp_core_get_phone_price_html($post_id),
            'price_text' => wp_strip_all_tags(sp_core_get_phone_price_html($post_id)),
        ];
    }
}

if (!function_exists('sp_core_get_phone_market_info')) {
    function sp_core_get_phone_market_info($post_id = null) {
        $post_id = $post_id ?: get_the_ID();
        return [
            'market_status' => sp_core_clean_string(sp_core_get_field('market_status', $post_id, '')),
            'release_date'  => sp_core_clean_string(sp_core_get_field('release_date', $post_id, '')),
            'models'        => sp_core_clean_string(sp_core_get_field('models', $post_id, '')),
        ];
    }
}

if (!function_exists('sp_core_get_phone_performance_scores')) {
    function sp_core_get_phone_performance_scores($post_id = null) {
        $post_id = $post_id ?: get_the_ID();
        $group = sp_core_get_field('performance_scores', $post_id, []);
        $group = is_array($group) ? $group : [];
        return [
            'display'      => $group['score_display'] ?? '',
            'camera'       => $group['score_camera'] ?? '',
            'performance'  => $group['score_performance'] ?? '',
            'gaming'       => $group['score_gaming'] ?? '',
            'battery'      => $group['score_battery'] ?? '',
            'connectivity' => $group['score_connectivity'] ?? '',
        ];
    }
}

if (!function_exists('sp_core_get_phone_antutu_benchmark')) {
    function sp_core_get_phone_antutu_benchmark($post_id = null) {
        $post_id = $post_id ?: get_the_ID();
        $group = sp_core_get_field('antutu_benchmark', $post_id, []);
        $group = is_array($group) ? $group : [];
        return [
            'cpu_score'    => $group['cpu_score'] ?? '',
            'gpu_score'    => $group['gpu_score'] ?? '',
            'memory_score' => $group['memory_score'] ?? '',
            'ux_score'     => $group['ux_score'] ?? '',
        ];
    }
}

if (!function_exists('sp_core_get_phone_review_list')) {
    function sp_core_get_phone_review_list($type = 'pros', $post_id = null) {
        $post_id = $post_id ?: get_the_ID();
        $type = $type === 'cons' ? 'cons' : 'pros';
        $field = $type === 'pros' ? 'pros_list' : 'cons_list';
        $preferred = $type === 'pros'
            ? ['pros_text', 'item', 'pro_item', 'pros_item', 'text', 'value']
            : ['cons_text', 'item', 'con_item', 'cons_item', 'text', 'value'];

        $rows = sp_core_get_field($field, $post_id, []);
        $items = [];
        $push = static function ($value) use (&$items) {
            if (is_array($value) || is_object($value)) {
                return;
            }
            $value = sp_core_clean_string($value);
            if ($value === '' || preg_match('/^\d+$/', $value)) {
                return;
            }
            if (!in_array($value, $items, true)) {
                $items[] = $value;
            }
        };

        if (is_array($rows)) {
            foreach ($rows as $row) {
                if (is_array($row)) {
                    foreach ($preferred as $key) {
                        if (isset($row[$key])) {
                            $push($row[$key]);
                        }
                    }
                } else {
                    $push($row);
                }
            }
        } else {
            foreach (preg_split('/\r\n|\r|\n|;/', (string) $rows) as $line) {
                $push($line);
            }
        }

        // Fallback for raw ACF repeater meta if get_field is unavailable.
        if (!$items) {
            $count = absint(get_post_meta($post_id, $field, true));
            if ($count > 0 && $count < 100) {
                for ($i = 0; $i < $count; $i++) {
                    foreach ($preferred as $key) {
                        $push(get_post_meta($post_id, $field . '_' . $i . '_' . $key, true));
                    }
                }
            }
        }

        return $items;
    }
}

/**
 * Specification Core public Attribute API.
 *
 * These helpers are intentionally global so Blocksy Child and other themes can
 * render native phone attributes without keeping their own mapping layer.
 */
if (!function_exists('sp_core_contextual_attribute_field')) {
    function sp_core_contextual_attribute_field($group_key, $field_name, $label = '') {
        $group_key = sanitize_key((string) $group_key);
        $field_name = sanitize_key((string) $field_name);
        $label_key = sanitize_key(str_replace([' ', '-', '/', '.'], '_', strtolower((string) $label)));

        if ($group_key === 'front_camera') {
            $map = [
                'main' => 'front_main',
                'front_main' => 'front_main',
                'main_front' => 'front_main',
                'front_camera' => 'front_main',
                'selfie_camera' => 'front_main',
                'second' => 'front_second',
                'front_second' => 'front_second',
                'second_front' => 'front_second',
                'secondary_front' => 'front_second',
                'features' => 'front_features',
                'display_features' => 'front_features',
                'front_features' => 'front_features',
                'features_front' => 'front_features',
                'front_camera_features' => 'front_features',
                'video' => 'front_video',
                'front_video' => 'front_video',
                'video_front' => 'front_video',
                'sensor_front' => 'sensor_front',
            ];
            if (isset($map[$field_name])) {
                return $map[$field_name];
            }
            if (isset($map[$label_key])) {
                return $map[$label_key];
            }
        }

        if ($group_key === 'rear_camera') {
            $map = [
                'main' => 'rear_main',
                'rear_main' => 'rear_main',
                'main_rear' => 'rear_main',
                'main_camera' => 'rear_main',
                'rear_camera' => 'rear_main',
                'second' => 'rear_second',
                'rear_second' => 'rear_second',
                'second_rear' => 'rear_second',
                'secondary_rear' => 'rear_second',
                'third' => 'rear_third',
                'rear_third' => 'rear_third',
                'third_rear' => 'rear_third',
                'quad' => 'rear_quad',
                'rear_quad' => 'rear_quad',
                'quad_rear' => 'rear_quad',
                'features' => 'rear_features',
                'display_features' => 'rear_features',
                'rear_features' => 'rear_features',
                'features_rear' => 'rear_features',
                'rear_camera_features' => 'rear_features',
                'video' => 'rear_video',
                'rear_video' => 'rear_video',
                'video_rear' => 'rear_video',
            ];
            if (isset($map[$field_name])) {
                return $map[$field_name];
            }
            if (isset($map[$label_key])) {
                return $map[$label_key];
            }
        }

        return $field_name;
    }
}

if (!function_exists('sp_core_default_phone_attribute_groups')) {
    function sp_core_default_phone_attribute_groups() {
        static $cached_groups = null;
        if (is_array($cached_groups)) {
            return $cached_groups;
        }

        $defaults = [
            'network' => ['Network', 10, ['Technology' => 'technology', 'Speed' => 'speed', 'SIM' => 'sim']],
            'design' => ['Design', 20, ['Dimensions' => 'dimensions', 'Weight' => 'weight', 'Material' => 'material', 'Colors' => 'colors', 'IP Rating' => 'ip_rating', 'Other' => 'other']],
            'display' => ['Display', 30, ['Panel Type' => 'panel_type', 'Size' => 'display_size', 'Resolution' => 'resolution', 'Cover Type' => 'cover_type', 'Cover Size' => 'cover_size', 'Cover Resolution' => 'cover_resolution', 'Cover Display' => 'cover_display', 'Brightness' => 'brightness', 'Protection' => 'protection', 'Features' => 'display_features']],
            'platform' => ['Platform', 40, ['Processor' => 'processor', 'Processor Type' => 'processor_type', 'Cores' => 'cores', 'Clockspeed' => 'clock_speed', 'GPU' => 'gpu', 'Operating System' => 'os']],
            'storage' => ['Storage', 50, ['Internal Storage' => 'internal_storage', 'RAM' => 'ram', 'RAM Type' => 'ram_type', 'SD Card Slot' => 'sd_slot', 'UFS' => 'ufs']],
            'front_camera' => ['Front Camera', 60, ['Main' => 'front_main', 'Second' => 'front_second', 'Features' => 'front_features', 'Video' => 'front_video', 'Sensor Front' => 'sensor_front']],
            'rear_camera' => ['Rear Camera', 70, ['Main' => 'rear_main', 'Second' => 'rear_second', 'Third' => 'rear_third', 'Quad' => 'rear_quad', 'Features' => 'rear_features', 'Video' => 'rear_video']],
            'connectivity' => ['Connectivity', 80, ['WLAN' => 'wlan', 'Bluetooth' => 'bluetooth', 'Codec' => 'codec', 'GPS' => 'gps', 'NFC' => 'nfc', 'Infrared' => 'infrared', 'Radio' => 'radio', 'USB' => 'usb']],
            'audio' => ['Audio', 90, ['Loudspeaker' => 'loudspeaker', '3.5mm' => 'audio_jack_3_5mm', 'Audio Jack' => 'audio_jack']],
            'battery' => ['Battery', 100, ['Capacity' => 'capacity', 'Battery Type' => 'battery_type', 'Charging' => 'charging', 'Quick Charge' => 'quick_charge', 'Power Delivery' => 'power_delivery', 'Wireless Charging' => 'wireless_charging', 'Reverse Charging' => 'reverse_charging']],
            'sensor' => ['Sensor', 110, ['Fingerprint' => 'fingerprint', 'Face ID' => 'face_id', 'Accelerometer' => 'accelerometer', 'Gyroscope' => 'gyroscope', 'Proximity' => 'proximity', 'Compass' => 'compass', 'Barometer' => 'barometer', 'Color Spectrum' => 'color_spectrum']],
        ];

        $groups = [];
        foreach ($defaults as $group_key => $data) {
            [$group_label, $position, $attributes] = $data;
            $rows = [];
            foreach ($attributes as $label => $field_name) {
                $rows[] = [
                    'label' => sp_core_clean_string($label),
                    'field_name' => sanitize_key($field_name),
                ];
            }
            $groups[$group_key] = [
                'group_key' => $group_key,
                'group_label' => $group_label,
                'position' => $position,
                'attributes' => $rows,
                'updated_at' => '',
            ];
        }
        $cached_groups = $groups;
        return $cached_groups;
    }
}

if (!function_exists('sp_core_normalize_phone_attribute_group')) {
    function sp_core_normalize_phone_attribute_group($key, $group) {
        if (!is_array($group)) {
            return null;
        }

        $group_key = sanitize_key($group['group_key'] ?? $key);
        $group_label = sp_core_clean_string($group['group_label'] ?? $group['label'] ?? $group_key);
        if ($group_key === '' || $group_label === '') {
            return null;
        }

        $attributes = [];
        $seen = [];
        foreach ((array) ($group['attributes'] ?? []) as $attribute) {
            if (is_array($attribute)) {
                $label = sp_core_clean_string($attribute['label'] ?? ($attribute['name'] ?? ''));
                $field_name = sanitize_key($attribute['field_name'] ?? ($attribute['field'] ?? ''));
            } else {
                $label = sp_core_clean_string($attribute);
                $field_name = '';
            }

            if ($label === '') {
                continue;
            }
            if ($field_name === '') {
                $field_name = sanitize_key(str_replace('-', '_', sanitize_title($label)));
            }
            $field_name = sp_core_contextual_attribute_field($group_key, $field_name, $label);
            if ($field_name === '') {
                continue;
            }

            $signature = $group_key . '|' . $field_name;
            if (isset($seen[$signature])) {
                continue;
            }
            $seen[$signature] = true;
            $attributes[] = [
                'label' => $label,
                'field_name' => $field_name,
            ];
        }

        if (!$attributes) {
            return null;
        }

        return [
            'group_key' => $group_key,
            'group_label' => $group_label,
            'position' => absint($group['position'] ?? 90),
            'attributes' => $attributes,
            'updated_at' => $group['updated_at'] ?? '',
        ];
    }
}

if (!function_exists('sp_core_get_phone_attribute_groups')) {
    function sp_core_get_phone_attribute_groups() {
        static $cached_groups = null;
        if (is_array($cached_groups)) {
            return $cached_groups;
        }

        $defaults = sp_core_default_phone_attribute_groups();
        $groups = $defaults;
        $stored = get_option('sp_core_phone_attribute_groups', []);

        if (is_array($stored) && $stored) {
            foreach ($stored as $key => $group) {
                $normalized = sp_core_normalize_phone_attribute_group(is_string($key) ? $key : '', $group);
                if (!$normalized) {
                    continue;
                }

                // Keep the default canonical attributes for every native group.
                // Stored options may come from older exports and can miss fields such as
                // Storage > SD Card Slot, Battery > Wireless Charging, or Sensor > Barometer.
                // We merge defaults first to preserve the correct frontend order, then
                // overlay stored labels/custom additions without dropping canonical fields.
                if (isset($defaults[$normalized['group_key']])) {
                    $base = $defaults[$normalized['group_key']];
                    $merged = [];
                    foreach ((array) ($base['attributes'] ?? []) as $attr) {
                        $field = sanitize_key($attr['field_name'] ?? '');
                        if ($field !== '') {
                            $merged[$field] = $attr;
                        }
                    }
                    foreach ((array) ($normalized['attributes'] ?? []) as $attr) {
                        $field = sanitize_key($attr['field_name'] ?? '');
                        if ($field !== '') {
                            $merged[$field] = $attr;
                        }
                    }
                    $normalized['attributes'] = array_values($merged);
                }

                $groups[$normalized['group_key']] = $normalized;
            }
        }

        uasort($groups, static function ($a, $b) {
            return ((int) ($a['position'] ?? 90) <=> (int) ($b['position'] ?? 90)) ?: strcmp((string) ($a['group_label'] ?? ''), (string) ($b['group_label'] ?? ''));
        });

        $cached_groups = $groups;
        return $cached_groups;
    }
}

if (!function_exists('sp_core_phone_field_aliases')) {
    function sp_core_phone_field_aliases($field_name, $label = '', $group_key = '') {
        static $alias_cache = [];
        $cache_key = sanitize_key((string) $group_key) . '|' . sanitize_key((string) $field_name) . '|' . md5((string) $label);
        if (isset($alias_cache[$cache_key])) {
            return $alias_cache[$cache_key];
        }

        $group_key = sanitize_key((string) $group_key);
        $field_name = sp_core_contextual_attribute_field($group_key, $field_name, $label);
        $aliases = [$field_name];

        $map = [
            'technology' => ['network_technology'],
            'dimensions' => ['dimension'],
            'colors' => ['color'],
            'panel_type' => ['display', 'screen_type', 'display_type'],
            'display_size' => ['size', 'screen_size'],
            'display_features' => ['display_feature', 'refresh_rate'],
            'processor' => ['chipset', 'cpu', 'soc'],
            'processor_type' => ['processor_model', 'chipset_type'],
            'clock_speed' => ['clockspeed', 'clock'],
            'os' => ['operating_system'],
            'internal_storage' => ['storage'],
            'sd_slot' => ['sd_card_slot', 'sdcard_slot', 'micro_sd_slot', 'microsd_slot', 'microsdslot', 'micro_sdslot', 'micro_sd', 'microsd', 'micro_sd_card', 'microsd_card', 'micro_sd_card_slot', 'microsd_card_slot', 'card_slot', 'memory_card', 'memory_card_slot', 'sdcard', 'sd_card'],
            'front_main' => ['main_front', 'mainfront', 'front_camera', 'frontcamera', 'selfie_camera', 'selfiecamera', 'single_front', 'singlefront'],
            'front_second' => ['second_front', 'secondfront', 'secondary_front', 'secondaryfront'],
            'front_features' => ['features_front', 'featuresfront', 'front_features', 'frontfeatures', 'featured_front', 'featuredfront', 'front_camera_features', 'frontcamerafeatures', 'selfie_features', 'selfiefeatures'],
            'front_video' => ['video_front', 'videofront', 'front_video', 'frontvideo', 'selfie_video', 'selfievideo'],
            'rear_main' => ['main_rear', 'mainrear', 'main_camera', 'maincamera', 'rear_camera', 'rearcamera', 'single_rear', 'singlerear'],
            'rear_second' => ['second_rear', 'secondrear', 'secondary_rear', 'secondaryrear', 'second_rear_cam', 'secondrearcam'],
            'rear_third' => ['third_rear', 'thirdrear', 'third_rear_cam', 'thirdrearcam'],
            'rear_quad' => ['quad_rear', 'quadrear', 'quad', 'quad_rear_cam', 'quadrearcam'],
            'rear_features' => ['features_rear', 'featuresrear', 'rear_features', 'rearfeatures', 'rear_camera_features', 'rearcamerafeatures', 'features_rear_cam', 'featuresrearcam'],
            'rear_video' => ['video_rear', 'videorear', 'rear_video', 'rearvideo', 'video_rear_cam', 'videorearcam'],
            'audio_jack_3_5mm' => ['35mm', '3_5mm', 'audiojack35', 'audio_jack_35'],
            'audio_jack' => ['audiojack'],
            'ip_rating' => ['iprating'],
            'battery_type' => ['battery', 'batterytype', 'battery_technology', 'batterytech', 'type'],
            'reverse_charging' => ['reverse', 'reverse_charge', 'reversecharging', 'reverse_wireless_charging', 'reverse_wireless'],
            'capacity' => ['battery_capacity', 'batterycapacity', 'battery_size'],
            'charging' => ['charge', 'wired_charging', 'wiredcharging', 'charging_speed'],
            'quick_charge' => ['quickcharge', 'fast_charging', 'fastcharging', 'fast_charge', 'quick_charge_support'],
            'power_delivery' => ['pd', 'usb_pd', 'usb_power_delivery', 'powerdelivery'],
            'wireless_charging' => ['wirelesscharging', 'wireless_charge', 'wireless', 'wireless_charge_support'],
            'face_id' => ['faceid', 'face_unlock', 'faceunlock', 'face_recognition'],
            'gyroscope' => ['gyro'],
            'color_spectrum' => ['colorspectrum', 'colour_spectrum', 'colourspectrum', 'color_sensor', 'colour_sensor'],
        ];

        if (isset($map[$field_name])) {
            $aliases = array_merge($aliases, $map[$field_name]);
        }
        if ($group_key !== '') {
            $aliases[] = $group_key . '_' . $field_name;
        }

        $label_key = sanitize_key(str_replace([' ', '-', '/', '.'], '_', strtolower((string) $label)));
        if ($label_key !== '') {
            $contextual_label_key = sp_core_contextual_attribute_field($group_key, $label_key, $label);
            $aliases[] = $contextual_label_key;
            if ($group_key !== '') {
                $aliases[] = $group_key . '_' . $contextual_label_key;
            }
        }

        $alias_cache[$cache_key] = array_values(array_unique(array_filter($aliases)));
        return $alias_cache[$cache_key];
    }
}

if (!function_exists('sp_core_is_empty_frontend_value')) {
    function sp_core_is_empty_frontend_value($value) {
        $clean = sp_core_clean_string($value);
        return $clean === '' || preg_match('/^(no|n\/?a|na|-|none|null)$/i', trim($clean));
    }
}

if (!function_exists('sp_core_get_legacy_attribute_value')) {
    function sp_core_get_legacy_attribute_value($post_id, $group_key, $field_name, $label = '') {
        static $legacy_cache = [];
        $post_id = absint($post_id);
        if (!array_key_exists($post_id, $legacy_cache)) {
            $legacy_cache[$post_id] = get_post_meta($post_id, '_sp_legacy_attribute_index', true);
        }
        $legacy = $legacy_cache[$post_id];
        if (!is_array($legacy) || empty($legacy)) {
            return '';
        }

        $wanted = [];
        foreach (sp_core_phone_field_aliases($field_name, $label, $group_key) as $alias) {
            $wanted[] = sp_core_normalize_label_key($alias);
            $wanted[] = sp_core_normalize_label_key(str_replace('_', ' ', $alias));
        }
        if ($label !== '') {
            $wanted[] = sp_core_normalize_label_key($label);
        }
        if ($group_key !== '') {
            $wanted[] = sp_core_normalize_label_key($group_key . ' ' . $label);
        }
        $wanted = array_values(array_unique(array_filter($wanted)));

        foreach ($legacy as $legacy_label => $legacy_value) {
            $legacy_key = sp_core_normalize_label_key($legacy_label);
            if (in_array($legacy_key, $wanted, true)) {
                return sp_core_clean_string($legacy_value);
            }
        }

        return '';
    }
}

if (!function_exists('sp_core_get_phone_attribute_value')) {
    function sp_core_get_phone_attribute_value($post_id, $group_key, $field_name, $label = '', $default = '') {
        $post_id = absint($post_id ?: get_the_ID());
        if (!$post_id) {
            return $default;
        }

        foreach (sp_core_phone_field_aliases($field_name, $label, $group_key) as $key) {
            $value = sp_core_get_field($key, $post_id, null);
            $clean = sp_core_clean_string($value);
            if ($clean !== '') {
                return $clean;
            }
        }

        $legacy = sp_core_get_legacy_attribute_value($post_id, $group_key, $field_name, $label);
        if ($legacy !== '') {
            return $legacy;
        }

        return $default;
    }
}

if (!function_exists('sp_core_normalize_label_key')) {
    function sp_core_normalize_label_key($label) {
        return strtolower(preg_replace('/[^a-z0-9]/i', '', (string) $label));
    }
}

if (!function_exists('sp_core_classify_legacy_attribute_label')) {
    function sp_core_classify_legacy_attribute_label($label) {
        $key = sp_core_normalize_label_key($label);
        $map = [
            'frontcamera' => ['front_camera', 'front_main', 'Main'],
            'selfiecamera' => ['front_camera', 'front_main', 'Main'],
            'mainfront' => ['front_camera', 'front_main', 'Main'],
            'singlefront' => ['front_camera', 'front_main', 'Main'],
            'secondfront' => ['front_camera', 'front_second', 'Second'],
            'secondaryfront' => ['front_camera', 'front_second', 'Second'],
            'featuresfront' => ['front_camera', 'front_features', 'Features'],
            'featuredfront' => ['front_camera', 'front_features', 'Features'],
            'frontfeatures' => ['front_camera', 'front_features', 'Features'],
            'frontcamerafeatures' => ['front_camera', 'front_features', 'Features'],
            'selfiefeatures' => ['front_camera', 'front_features', 'Features'],
            'videofront' => ['front_camera', 'front_video', 'Video'],
            'frontvideo' => ['front_camera', 'front_video', 'Video'],
            'selfievideo' => ['front_camera', 'front_video', 'Video'],
            'rearcamera' => ['rear_camera', 'rear_main', 'Main'],
            'maincamera' => ['rear_camera', 'rear_main', 'Main'],
            'mainrear' => ['rear_camera', 'rear_main', 'Main'],
            'singlerear' => ['rear_camera', 'rear_main', 'Main'],
            'secondrear' => ['rear_camera', 'rear_second', 'Second'],
            'secondaryrear' => ['rear_camera', 'rear_second', 'Second'],
            'secondrearcam' => ['rear_camera', 'rear_second', 'Second'],
            'thirdrear' => ['rear_camera', 'rear_third', 'Third'],
            'thirdrearcam' => ['rear_camera', 'rear_third', 'Third'],
            'quadrear' => ['rear_camera', 'rear_quad', 'Quad'],
            'quadrearcam' => ['rear_camera', 'rear_quad', 'Quad'],
            'featuresrear' => ['rear_camera', 'rear_features', 'Features'],
            'rearfeatures' => ['rear_camera', 'rear_features', 'Features'],
            'rearcamerafeatures' => ['rear_camera', 'rear_features', 'Features'],
            'featuresrearcam' => ['rear_camera', 'rear_features', 'Features'],
            'videorear' => ['rear_camera', 'rear_video', 'Video'],
            'rearvideo' => ['rear_camera', 'rear_video', 'Video'],
            'videorearcam' => ['rear_camera', 'rear_video', 'Video'],
            'internalstorage' => ['storage', 'internal_storage', 'Internal Storage'],
            'storage' => ['storage', 'internal_storage', 'Internal Storage'],
            'ram' => ['storage', 'ram', 'RAM'],
            'ramtype' => ['storage', 'ram_type', 'RAM Type'],
            'sdslot' => ['storage', 'sd_slot', 'SD Card Slot'],
            'sdcardslot' => ['storage', 'sd_slot', 'SD Card Slot'],
            'sdcard' => ['storage', 'sd_slot', 'SD Card Slot'],
            'microsdslot' => ['storage', 'sd_slot', 'SD Card Slot'],
            'microsd' => ['storage', 'sd_slot', 'SD Card Slot'],
            'microsdcard' => ['storage', 'sd_slot', 'SD Card Slot'],
            'microsdcardslot' => ['storage', 'sd_slot', 'SD Card Slot'],
            'cardslot' => ['storage', 'sd_slot', 'SD Card Slot'],
            'memorycardslot' => ['storage', 'sd_slot', 'SD Card Slot'],
            'ufs' => ['storage', 'ufs', 'UFS'],
            'capacity' => ['battery', 'capacity', 'Capacity'],
            'batterycapacity' => ['battery', 'capacity', 'Capacity'],
            'batterytype' => ['battery', 'battery_type', 'Battery Type'],
            'charging' => ['battery', 'charging', 'Charging'],
            'quickcharge' => ['battery', 'quick_charge', 'Quick Charge'],
            'fastcharging' => ['battery', 'quick_charge', 'Quick Charge'],
            'powerdelivery' => ['battery', 'power_delivery', 'Power Delivery'],
            'usbpd' => ['battery', 'power_delivery', 'Power Delivery'],
            'wirelesscharging' => ['battery', 'wireless_charging', 'Wireless Charging'],
            'reversecharging' => ['battery', 'reverse_charging', 'Reverse Charging'],
            'reverse' => ['battery', 'reverse_charging', 'Reverse Charging'],
            'fingerprint' => ['sensor', 'fingerprint', 'Fingerprint'],
            'faceid' => ['sensor', 'face_id', 'Face ID'],
            'faceunlock' => ['sensor', 'face_id', 'Face ID'],
            'accelerometer' => ['sensor', 'accelerometer', 'Accelerometer'],
            'gyroscope' => ['sensor', 'gyroscope', 'Gyroscope'],
            'gyro' => ['sensor', 'gyroscope', 'Gyroscope'],
            'proximity' => ['sensor', 'proximity', 'Proximity'],
            'compass' => ['sensor', 'compass', 'Compass'],
            'barometer' => ['sensor', 'barometer', 'Barometer'],
            'colorspectrum' => ['sensor', 'color_spectrum', 'Color Spectrum'],
            'colourspectrum' => ['sensor', 'color_spectrum', 'Color Spectrum'],
        ];
        return $map[$key] ?? null;
    }
}

if (!function_exists('sp_core_get_grouped_phone_specs')) {
    function sp_core_get_grouped_phone_specs($post_id = null, $args = []) {
        static $grouped_cache = [];
        $post_id = absint($post_id ?: get_the_ID());
        if (!$post_id) {
            return [];
        }
        $args = wp_parse_args((array) $args, [
            'include_other' => false,
            'hide_empty' => true,
            'hide_no_single' => false,
        ]);
        $cache_key = $post_id . ':' . md5(wp_json_encode($args));
        if (isset($grouped_cache[$cache_key])) {
            return $grouped_cache[$cache_key];
        }

        $groups = sp_core_get_phone_attribute_groups();
        $grouped = [];
        $used = [];

        foreach ($groups as $group_key => $group) {
            $group_label = sp_core_clean_string($group['group_label'] ?? $group_key);
            if ($group_label === '') {
                continue;
            }
            foreach ((array) ($group['attributes'] ?? []) as $attribute) {
                $label = sp_core_clean_string($attribute['label'] ?? '');
                $field_name = sanitize_key($attribute['field_name'] ?? '');
                if ($label === '' || $field_name === '') {
                    continue;
                }
                $field_name = sp_core_contextual_attribute_field($group_key, $field_name, $label);
                $value = sp_core_get_phone_attribute_value($post_id, $group_key, $field_name, $label, '');
                if ($value === '') {
                    continue;
                }
                if (!empty($args['hide_no_single']) && preg_match('/^(no|n\/a|na|-|none)$/i', trim($value))) {
                    continue;
                }
                if (!isset($grouped[$group_label])) {
                    $grouped[$group_label] = [];
                }
                $grouped[$group_label][$label] = $value;
                $used[sp_core_normalize_label_key($group_label . '|' . $label)] = true;
                $used[sp_core_normalize_label_key($label . '|' . $value)] = true;
            }
        }

        // Recover old migrated labels and place camera values into canonical groups.
        $legacy = get_post_meta($post_id, '_sp_legacy_attribute_index', true);
        if (!is_array($legacy)) {
            $legacy = [];
        }
        foreach ($legacy as $legacy_label => $legacy_value) {
            $legacy_label = sp_core_clean_string($legacy_label);
            $legacy_value = sp_core_clean_string($legacy_value);
            if ($legacy_label === '' || $legacy_value === '') {
                continue;
            }
            $classified = sp_core_classify_legacy_attribute_label($legacy_label);
            if ($classified) {
                if (!empty($args['hide_no_single']) && sp_core_is_empty_frontend_value($legacy_value)) {
                    continue;
                }
                [$group_key, $field_name, $label] = $classified;
                $group_label = isset($groups[$group_key]['group_label']) ? sp_core_clean_string($groups[$group_key]['group_label']) : ucwords(str_replace('_', ' ', $group_key));
                if (!isset($grouped[$group_label])) {
                    $grouped[$group_label] = [];
                }
                if (empty($grouped[$group_label][$label])) {
                    $grouped[$group_label][$label] = $legacy_value;
                }
                continue;
            }

            if (!empty($args['include_other'])) {
                $signature = sp_core_normalize_label_key($legacy_label . '|' . $legacy_value);
                if (!isset($used[$signature])) {
                    $grouped['Other Specs'][$legacy_label] = $legacy_value;
                }
            }
        }

        $grouped_cache[$cache_key] = $grouped;
        return $grouped_cache[$cache_key];
    }
}




if (!function_exists('sp_core_extract_attachment_id_from_value')) {
    function sp_core_extract_attachment_id_from_value($value) {
        if (is_numeric($value)) {
            $id = absint($value);
            return $id > 0 ? $id : 0;
        }

        if (is_string($value)) {
            $value = trim($value);
            if ($value === '') {
                return 0;
            }
            if (ctype_digit($value)) {
                return absint($value);
            }
            if (filter_var($value, FILTER_VALIDATE_URL)) {
                $id = attachment_url_to_postid($value);
                return $id ? absint($id) : 0;
            }
            return 0;
        }

        if (is_array($value)) {
            foreach (['id', 'ID', 'attachment_id', 'media_id', 'image_id', 'logo_id', 'icon_id', 'value'] as $key) {
                if (isset($value[$key])) {
                    $id = sp_core_extract_attachment_id_from_value($value[$key]);
                    if ($id) {
                        return $id;
                    }
                }
            }
            foreach ($value as $nested_key => $nested_value) {
                $key = strtolower((string) $nested_key);
                if (preg_match('/(image|img|logo|icon|thumbnail|featured|attachment|media)/', $key)) {
                    $id = sp_core_extract_attachment_id_from_value($nested_value);
                    if ($id) {
                        return $id;
                    }
                }
            }
        }

        return 0;
    }
}

if (!function_exists('sp_core_extract_image_url_from_value')) {
    function sp_core_extract_image_url_from_value($value) {
        if (is_string($value) && filter_var(trim($value), FILTER_VALIDATE_URL)) {
            return esc_url_raw(trim($value));
        }
        if (is_array($value)) {
            foreach (['url', 'src', 'image_url', 'logo_url', 'icon_url', 'full', 'thumbnail'] as $key) {
                if (!empty($value[$key]) && is_string($value[$key]) && filter_var(trim($value[$key]), FILTER_VALIDATE_URL)) {
                    return esc_url_raw(trim($value[$key]));
                }
            }
            foreach ($value as $nested_key => $nested_value) {
                $key = strtolower((string) $nested_key);
                if (preg_match('/(image|img|logo|icon|thumbnail|featured|url|src)/', $key)) {
                    $url = sp_core_extract_image_url_from_value($nested_value);
                    if ($url) {
                        return $url;
                    }
                }
            }
        }
        return '';
    }
}

if (!function_exists('sp_core_get_term_image_id')) {
    function sp_core_get_term_image_id($term_id, $context = 'image') {
        static $image_id_cache = [];
        $term_id = absint($term_id);
        if (!$term_id) {
            return 0;
        }

        $context = sanitize_key((string) $context);
        $cache_key = $term_id . ':' . $context;
        if (array_key_exists($cache_key, $image_id_cache)) {
            return $image_id_cache[$cache_key];
        }
        $image_keys = [
            'sp_term_featured_image_id',
            'featured_image_id',
            'featured_image',
            'thumbnail_id',
            '_thumbnail_id',
            'image_id',
            'term_image_id',
            'term_image',
            'sp_brand_image_id',
            'sp_category_image_id',
            'pwb_brand_image',
            'product_brand_thumbnail_id',
            'yith_product_brand_thumbnail',
        ];
        $logo_keys = [
            'sp_term_featured_icon_logo_id',
            'featured_icon_logo_id',
            'featured_icon_logo',
            'sp_brand_logo_id',
            'sp_category_logo_id',
            'logo_id',
            'term_logo_id',
            'term_logo',
            'icon_id',
            'term_icon_id',
            'brand_logo',
            'brand_image',
        ];
        $keys = $context === 'logo' || $context === 'icon' ? array_merge($logo_keys, $image_keys) : array_merge($image_keys, $logo_keys);

        foreach ($keys as $key) {
            $id = sp_core_extract_attachment_id_from_value(get_term_meta($term_id, $key, true));
            if ($id) {
                $image_id_cache[$cache_key] = $id;
                return $id;
            }
        }

        foreach (['ct_term_options', 'blocksy_taxonomy_meta_options', 'ct_term_atts', 'blocksy_term_options'] as $bundle_key) {
            $bundle = get_term_meta($term_id, $bundle_key, true);
            $id = sp_core_extract_attachment_id_from_value($bundle);
            if ($id) {
                $image_id_cache[$cache_key] = $id;
                return $id;
            }
        }

        $image_id_cache[$cache_key] = 0;
        return 0;
    }
}

if (!function_exists('sp_core_get_term_image_url')) {
    function sp_core_get_term_image_url($term_id, $context = 'image', $size = 'thumbnail') {
        static $image_url_cache = [];
        $term_id = absint($term_id);
        if (!$term_id) {
            return '';
        }
        $cache_key = $term_id . ':' . sanitize_key((string) $context) . ':' . sanitize_key((string) $size);
        if (array_key_exists($cache_key, $image_url_cache)) {
            return $image_url_cache[$cache_key];
        }

        $id = sp_core_get_term_image_id($term_id, $context);
        if ($id) {
            $url = wp_get_attachment_image_url($id, $size ?: 'thumbnail');
            if ($url) {
                $image_url_cache[$cache_key] = $url;
                return $url;
            }
        }

        $url_keys = $context === 'logo' || $context === 'icon'
            ? ['sp_brand_logo_url', 'sp_category_logo_url', 'sp_term_featured_icon_logo_url', 'featured_icon_logo_url', 'logo_url', 'icon_url', 'sp_brand_image_url', 'sp_category_image_url', 'featured_image_url']
            : ['sp_brand_image_url', 'sp_category_image_url', 'sp_term_featured_image_url', 'featured_image_url', 'image_url', 'thumbnail_url', 'logo_url', 'icon_url'];
        foreach ($url_keys as $key) {
            $url = sp_core_extract_image_url_from_value(get_term_meta($term_id, $key, true));
            if ($url) {
                $image_url_cache[$cache_key] = $url;
                return $url;
            }
        }

        foreach (['ct_term_options', 'blocksy_taxonomy_meta_options', 'ct_term_atts', 'blocksy_term_options'] as $bundle_key) {
            $url = sp_core_extract_image_url_from_value(get_term_meta($term_id, $bundle_key, true));
            if ($url) {
                $image_url_cache[$cache_key] = $url;
                return $url;
            }
        }

        $image_url_cache[$cache_key] = '';
        return '';
    }
}

if (!function_exists('sp_core_get_term_image_html')) {
    function sp_core_get_term_image_html($term_id, $context = 'image', $size = 'thumbnail', $attr = []) {
        $term_id = absint($term_id);
        if (!$term_id) {
            return '';
        }

        $term = get_term($term_id);
        $attr = wp_parse_args((array) $attr, [
            'alt' => (!is_wp_error($term) && $term && !empty($term->name)) ? $term->name : '',
            'loading' => 'lazy',
            'decoding' => 'async',
        ]);

        $id = sp_core_get_term_image_id($term_id, $context);
        if ($id) {
            return wp_get_attachment_image($id, $size ?: 'thumbnail', false, $attr);
        }

        $url = sp_core_get_term_image_url($term_id, $context, $size);
        if (!$url) {
            return '';
        }
        $html_attr = '';
        foreach ($attr as $key => $value) {
            if (is_scalar($value) && $value !== '') {
                $html_attr .= ' ' . esc_attr($key) . '="' . esc_attr($value) . '"';
            }
        }
        return '<img src="' . esc_url($url) . '"' . $html_attr . ' />';
    }
}

if (!function_exists('sp_core_get_phone_primary_term')) {
    function sp_core_get_phone_primary_term($post_id, $taxonomy) {
        static $primary_term_cache = [];
        $post_id = absint($post_id ?: get_the_ID());
        $taxonomy = sanitize_key((string) $taxonomy);
        if (!$post_id || $taxonomy === '' || !taxonomy_exists($taxonomy)) {
            return null;
        }
        $cache_key = $post_id . ':' . $taxonomy;
        if (array_key_exists($cache_key, $primary_term_cache)) {
            return $primary_term_cache[$cache_key];
        }
        $terms = wp_get_object_terms($post_id, $taxonomy, ['orderby' => 'term_order', 'order' => 'ASC']);
        if (is_wp_error($terms) || empty($terms)) {
            $primary_term_cache[$cache_key] = null;
            return null;
        }
        $primary_term_cache[$cache_key] = $terms[0];
        return $primary_term_cache[$cache_key];
    }
}

if (!function_exists('sp_core_get_phone_brand_logo_html')) {
    function sp_core_get_phone_brand_logo_html($post_id, $size = 'thumbnail', $attr = []) {
        $term = sp_core_get_phone_primary_term($post_id, 'phone_brand');
        if (!$term) {
            return '';
        }
        $attr = wp_parse_args((array) $attr, ['alt' => $term->name, 'class' => 'sp-phone-brand-logo']);
        return sp_core_get_term_image_html($term->term_id, 'logo', $size, $attr);
    }
}

if (!function_exists('sp_core_get_phone_category_image_html')) {
    function sp_core_get_phone_category_image_html($post_id, $size = 'thumbnail', $attr = []) {
        $term = sp_core_get_phone_primary_term($post_id, 'phone_category');
        if (!$term) {
            return '';
        }
        $attr = wp_parse_args((array) $attr, ['alt' => $term->name, 'class' => 'sp-phone-category-image']);
        return sp_core_get_term_image_html($term->term_id, 'image', $size, $attr);
    }
}

if (!function_exists('sp_core_get_attribute_value_term_asset')) {
    function sp_core_get_attribute_value_term_asset($label, $value) {
        static $result_cache = [];
        static $registry_by_label = null;

        $label_key = sanitize_key($label);
        $value_clean = sp_core_clean_string($value);
        if ($value_clean === '') {
            return [];
        }

        $cache_key = $label_key . ':' . md5(strtolower($value_clean));
        if (array_key_exists($cache_key, $result_cache)) {
            return $result_cache[$cache_key];
        }

        if ($registry_by_label === null) {
            $registry_by_label = [];
            $registry = get_option('sp_core_phone_attribute_registry', []);
            if (is_array($registry)) {
                foreach ($registry as $attribute) {
                    if (!is_array($attribute)) {
                        continue;
                    }
                    $keys = array_filter(array_unique([
                        sanitize_key($attribute['label'] ?? ''),
                        sanitize_key($attribute['attribute_key'] ?? ''),
                    ]));
                    if (!$keys) {
                        continue;
                    }
                    foreach ((array) ($attribute['terms'] ?? []) as $term) {
                        if (!is_array($term) || empty($term['name']) || empty($term['image_id'])) {
                            continue;
                        }
                        $term_name = sp_core_clean_string($term['name']);
                        $image_id = absint($term['image_id']);
                        if ($term_name === '' || !$image_id) {
                            continue;
                        }
                        foreach ($keys as $key) {
                            if (!isset($registry_by_label[$key])) {
                                $registry_by_label[$key] = [];
                            }
                            $registry_by_label[$key][] = [
                                'name' => $term_name,
                                'image_id' => $image_id,
                            ];
                        }
                    }
                }
            }
        }

        foreach ((array) ($registry_by_label[$label_key] ?? []) as $term) {
            $term_name = $term['name'];
            $match_exact = strcasecmp($value_clean, $term_name) === 0;
            $match_prefix = stripos($value_clean, $term_name . ',') === 0 || stripos($value_clean, $term_name . ' ') === 0;
            if (!$match_exact && !$match_prefix) {
                continue;
            }
            $image_id = absint($term['image_id']);
            $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : '';
            if (!$image_url) {
                continue;
            }
            $result_cache[$cache_key] = [
                'term' => $term_name,
                'image_id' => $image_id,
                'image_url' => $image_url,
            ];
            return $result_cache[$cache_key];
        }

        $result_cache[$cache_key] = [];
        return [];
    }
}

if (!function_exists('sp_core_render_phone_specs')) {
    function sp_core_render_phone_specs($post_id = null, $args = []) {
        $groups = sp_core_get_grouped_phone_specs($post_id, $args);
        if (!$groups) {
            return '';
        }

        ob_start();
        foreach ($groups as $group_label => $items) {
            if (!$items) {
                continue;
            }
            echo '<section class="sp-core-spec-group">';
            echo '<h2 class="sp-core-spec-group-title">' . esc_html($group_label) . '</h2>';
            echo '<div class="sp-core-spec-rows">';
            foreach ($items as $label => $value) {
                echo '<div class="sp-core-spec-row">';
                echo '<div class="sp-core-spec-label">' . esc_html($label) . '</div>';
                $term_asset = sp_core_get_attribute_value_term_asset($label, $value);
                if (!empty($term_asset['image_url'])) {
                    echo '<div class="sp-core-spec-value"><span class="sp-core-spec-value-media"><img src="' . esc_url($term_asset['image_url']) . '" alt="" loading="lazy" decoding="async"><span>' . esc_html($value) . '</span></span></div>';
                } else {
                    echo '<div class="sp-core-spec-value">' . esc_html($value) . '</div>';
                }
                echo '</div>';
            }
            echo '</div></section>';
        }
        return trim((string) ob_get_clean());
    }
}
