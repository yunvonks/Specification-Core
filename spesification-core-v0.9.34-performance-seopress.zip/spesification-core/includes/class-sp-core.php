<?php
if (!defined('ABSPATH')) {
    exit;
}

final class Specification_Core {
    private const ANTUTU_SCORE_MAX = 3000000;
    private static $instance = null;
    private $seopress_product_schema_was_filtered = false;
    private $enabled_modules_cache = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function module_definitions() {
        return [
            'attributes' => [
                'label' => 'Attribute Manager',
                'description' => 'Manage attribute groups, attributes, labels, visibility rules, and value registry.',
                'impact' => 'Low Impact',
                'default' => true,
                'icon' => 'sliders',
                'core' => true,
            ],
            'phone_meta' => [
                'label' => 'Phone Metabox',
                'description' => 'Advanced phone data fields, editorial data, benchmark fields, and meta boxes.',
                'impact' => 'Low Impact',
                'default' => true,
                'icon' => 'cube',
                'core' => true,
            ],
            'frontend' => [
                'label' => 'Frontend Renderer',
                'description' => 'Render specs on frontend, shortcodes, cards, and theme templates.',
                'impact' => 'Medium Impact',
                'default' => true,
                'icon' => 'scan',
                'core' => false,
            ],
            'compare' => [
                'label' => 'Compare Renderer',
                'description' => 'Comparison tables, highlight differences, mobile rows, and compare layouts.',
                'impact' => 'Medium Impact',
                'default' => true,
                'icon' => 'scale',
                'core' => false,
                'requires' => ['frontend'],
            ],
            'seo' => [
                'label' => 'SEO Schema Bridge',
                'description' => 'SEOPress schema, additional properties, breadcrumbs, and product metadata.',
                'impact' => 'Low Impact',
                'default' => true,
                'icon' => 'link',
                'core' => false,
            ],
            'currency' => [
                'label' => 'Currency Bridge',
                'description' => 'Single Price field, multi-currency display, and schema currency bridge.',
                'impact' => 'Medium Impact',
                'default' => true,
                'icon' => 'currency',
                'core' => false,
            ],
            'import_export' => [
                'label' => 'Import / Export',
                'description' => 'Import and export attributes, attribute groups, and phone specification data.',
                'impact' => 'Low Impact',
                'default' => false,
                'icon' => 'upload',
                'core' => false,
            ],
            'migration' => [
                'label' => 'Migration Tools',
                'description' => 'Migrate from WooCommerce and cleanup legacy data safely.',
                'impact' => 'Medium Impact',
                'default' => false,
                'icon' => 'database',
                'core' => false,
            ],
            'data_audit' => [
                'label' => 'Data Audit',
                'description' => 'Scan data integrity, missing values, orphaned meta, and inconsistencies.',
                'impact' => 'Low Impact',
                'default' => false,
                'icon' => 'shield',
                'core' => false,
            ],
            'translate' => [
                'label' => 'Translate Bridge',
                'description' => 'Meta translation support and language workflow hooks.',
                'impact' => 'Low Impact',
                'default' => false,
                'icon' => 'globe',
                'core' => false,
            ],
        ];
    }

    private function default_enabled_modules() {
        $enabled = [];
        foreach ($this->module_definitions() as $key => $module) {
            if (!empty($module['default'])) {
                $enabled[] = $key;
            }
        }
        return $enabled;
    }

    private function get_enabled_modules() {
        if (is_array($this->enabled_modules_cache)) {
            return $this->enabled_modules_cache;
        }

        $stored = get_option('sp_core_enabled_modules', null);
        if (!is_array($stored)) {
            $this->enabled_modules_cache = $this->default_enabled_modules();
            return $this->enabled_modules_cache;
        }
        $definitions = $this->module_definitions();
        $enabled = [];
        foreach ($stored as $key) {
            $key = sanitize_key($key);
            if (isset($definitions[$key])) {
                $enabled[] = $key;
            }
        }
        foreach ($definitions as $key => $module) {
            if (!empty($module['core']) && !in_array($key, $enabled, true)) {
                $enabled[] = $key;
            }
        }
        $this->enabled_modules_cache = array_values(array_unique($enabled));
        return $this->enabled_modules_cache;
    }

    private function is_module_enabled($module_key) {
        return in_array(sanitize_key($module_key), $this->get_enabled_modules(), true);
    }

    private function __construct() {
        add_action('init', [$this, 'register_post_type'], 5);
        add_action('init', [$this, 'register_taxonomies'], 6);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('admin_post_sp_core_flush_rewrite', [$this, 'handle_flush_rewrite']);
        add_action('admin_post_sp_core_save_modules', [$this, 'handle_save_modules']);
        add_action('wp_ajax_sp_core_dashboard_scan', [$this, 'ajax_dashboard_scan']);
        add_action('admin_init', [$this, 'maybe_upgrade_attribute_group_schema']);

        if ($this->is_module_enabled('phone_meta')) {
            add_action('acf/init', [$this, 'register_acf_fields']);
            add_action('save_post_phone', [$this, 'flush_spec_assist_cache'], 5);
            add_action('update_option_sp_core_phone_attribute_registry', [$this, 'flush_spec_assist_cache']);
            add_action('update_option_sp_core_phone_attribute_groups', [$this, 'flush_spec_assist_cache']);
            add_filter('acf/get_field_group', [$this, 'filter_duplicate_external_phone_acf_groups'], 99, 1);
            add_filter('acf/load_value/name=phone_description', [$this, 'load_phone_description_value'], 10, 3);
            add_filter('acf/update_value/name=phone_description', [$this, 'sanitize_phone_description_value'], 10, 3);
            add_filter('acf/fields/wysiwyg/toolbars', [$this, 'filter_acf_wysiwyg_toolbars']);
            foreach (array_keys($this->seopress_acf_field_map()) as $field_name) {
                add_filter('acf/load_value/name=' . $field_name, [$this, 'load_seopress_acf_value'], 10, 3);
                add_filter('acf/update_value/name=' . $field_name, [$this, 'sync_seopress_acf_value'], 10, 3);
            }
            add_action('add_meta_boxes_phone', [$this, 'register_phone_review_metabox'], 12);
            add_action('save_post_phone', [$this, 'save_phone_review_metabox'], 12, 2);
            add_action('add_meta_boxes_phone', [$this, 'register_phone_seopress_fallback_metabox'], 1000);
            add_action('save_post_phone', [$this, 'save_phone_seopress_fallback_metabox'], 20, 2);
            foreach ($this->antutu_score_field_keys() as $field_key) {
                add_filter('acf/validate_value/key=' . $field_key, [$this, 'validate_antutu_score_value'], 10, 4);
                add_filter('acf/update_value/key=' . $field_key, [$this, 'sanitize_antutu_score_value'], 10, 4);
            }
        }

        if ($this->is_module_enabled('attributes')) {
            add_action('admin_post_sp_core_rebuild_phone_attribute_registry', [$this, 'handle_rebuild_phone_attribute_registry']);
            add_action('admin_post_sp_core_clean_wrong_attribute_terms', [$this, 'handle_clean_wrong_attribute_terms']);
            add_action('admin_post_sp_core_save_phone_attribute', [$this, 'handle_save_phone_attribute']);
            add_action('admin_post_sp_core_delete_phone_attribute', [$this, 'handle_delete_phone_attribute']);
            add_action('admin_post_sp_core_save_phone_attribute_group', [$this, 'handle_save_phone_attribute_group']);
            add_action('admin_post_sp_core_delete_phone_attribute_group', [$this, 'handle_delete_phone_attribute_group']);
            add_action('admin_post_sp_core_reset_phone_attribute_groups', [$this, 'handle_reset_phone_attribute_groups']);
            add_action('admin_post_sp_core_export_phone_attributes', [$this, 'handle_export_phone_attributes']);
            add_action('admin_post_sp_core_import_phone_attributes', [$this, 'handle_import_phone_attributes']);
            add_action('admin_post_sp_core_export_phone_attribute_groups', [$this, 'handle_export_phone_attribute_groups']);
            add_action('admin_post_sp_core_import_phone_attribute_groups', [$this, 'handle_import_phone_attribute_groups']);
        }

        if ($this->is_module_enabled('frontend')) {
            add_filter('template_include', [$this, 'maybe_use_theme_phone_template'], 99);
            add_filter('post_type_link', [$this, 'maybe_root_phone_permalink'], 20, 2);
            add_filter('request', [$this, 'maybe_resolve_root_phone_request'], 20);
        }

        if ($this->is_module_enabled('seo')) {
            add_filter('seopress_schemas_auto_product_json', [$this, 'filter_seopress_product_schema'], 99, 1);
            add_action('wp_head', [$this, 'output_phone_product_schema_jsonld'], 99);
            add_filter('seopress_post_types', [$this, 'include_phone_in_seopress_post_types'], 99, 1);
            // Do not disable SEOPress' own editor UI. Older builds disabled it here
            // and then hid matching DOM nodes in JS/CSS, which prevented the SEO
            // metabox/panel from showing on Phone edit screens.
            add_action('do_meta_boxes', [$this, 'move_phone_seo_metaboxes_below_specs'], 999, 3);
            add_filter('get_user_option_meta-box-order_phone', [$this, 'filter_phone_metabox_order'], 99, 3);
            add_filter('get_user_option_metaboxhidden_phone', [$this, 'filter_phone_hidden_metaboxes'], 99, 3);
            add_filter('hidden_meta_boxes', [$this, 'filter_hidden_meta_boxes_for_phone'], 99, 3);
        }
    }

    public function register_post_type() {
        register_post_type('phone', [
            'labels' => [
                'name' => __('Phones', 'spesification-core'),
                'singular_name' => __('Phone', 'spesification-core'),
                'menu_name' => __('Phones', 'spesification-core'),
                'add_new_item' => __('Add New Phone', 'spesification-core'),
                'edit_item' => __('Edit Phone', 'spesification-core'),
                'new_item' => __('New Phone', 'spesification-core'),
                'view_item' => __('View Phone', 'spesification-core'),
                'search_items' => __('Search Phones', 'spesification-core'),
            ],
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_position' => 57,
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-smartphone',
            'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'author', 'comments', 'revisions', 'custom-fields'],
            'has_archive' => true,
            'rewrite' => ['slug' => 'phone', 'with_front' => false],
            'query_var' => true,
            'publicly_queryable' => true,
            'exclude_from_search' => false,
            'capability_type' => 'post',
        ]);
    }

    public function register_taxonomies() {
        register_taxonomy('phone_brand', ['phone'], [
            'labels' => [
                'name' => __('Phone Brands', 'spesification-core'),
                'singular_name' => __('Phone Brand', 'spesification-core'),
                'menu_name' => __('Brands', 'spesification-core'),
            ],
            'public' => true,
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'brand', 'with_front' => false],
        ]);

        register_taxonomy('phone_category', ['phone'], [
            'labels' => [
                'name' => __('Phone Categories', 'spesification-core'),
                'singular_name' => __('Phone Category', 'spesification-core'),
                'menu_name' => __('Categories', 'spesification-core'),
            ],
            'public' => true,
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'phone-category', 'with_front' => false],
        ]);

        register_taxonomy('phone_series', ['phone'], [
            'labels' => [
                'name' => __('Phone Series', 'spesification-core'),
                'singular_name' => __('Phone Series', 'spesification-core'),
                'menu_name' => __('Series', 'spesification-core'),
            ],
            'public' => true,
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'series', 'with_front' => false],
        ]);

        register_taxonomy('phone_tag', ['phone'], [
            'labels' => [
                'name' => __('Phone Tags', 'spesification-core'),
                'singular_name' => __('Phone Tag', 'spesification-core'),
                'menu_name' => __('Tags', 'spesification-core'),
            ],
            'public' => true,
            'hierarchical' => false,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'rewrite' => ['slug' => 'phone-tag', 'with_front' => false],
        ]);

        register_taxonomy('phone_attribute', ['phone'], [
            'labels' => [
                'name' => __('Phone Attributes', 'spesification-core'),
                'singular_name' => __('Phone Attribute', 'spesification-core'),
                'menu_name' => __('Attributes', 'spesification-core'),
            ],
            'public' => false,
            'publicly_queryable' => false,
            'hierarchical' => false,
            'show_ui' => false,
            'show_admin_column' => false,
            'show_in_rest' => false,
            'rewrite' => false,
        ]);

        register_taxonomy('phone_attribute_group', ['phone'], [
            'labels' => [
                'name' => __('Phone Attribute Groups', 'spesification-core'),
                'singular_name' => __('Phone Attribute Group', 'spesification-core'),
                'menu_name' => __('Attribute Groups', 'spesification-core'),
            ],
            'public' => false,
            'publicly_queryable' => false,
            'hierarchical' => true,
            'show_ui' => false,
            'show_admin_column' => false,
            'show_in_rest' => false,
            'rewrite' => false,
        ]);
    }

    public function load_phone_description_value($value, $post_id, $field) {
        if (sp_core_clean_description_html($value) !== '') {
            return $value;
        }

        $post_id = is_numeric($post_id) ? absint($post_id) : absint(str_replace('post_', '', (string) $post_id));
        if (!$post_id || get_post_type($post_id) !== 'phone') {
            return $value;
        }

        $description = sp_core_get_phone_description($post_id, false);
        return $description !== '' ? $description : $value;
    }

    public function sanitize_phone_description_value($value, $post_id, $field) {
        return sp_core_clean_description_html($value);
    }

    private function seopress_acf_field_map() {
        return [
            'sp_core_seopress_meta_title' => ['meta' => '_seopress_titles_title', 'type' => 'text'],
            'sp_core_seopress_meta_description' => ['meta' => '_seopress_titles_desc', 'type' => 'textarea'],
            'sp_core_seopress_focus_keyword' => ['meta' => '_seopress_analysis_target_kw', 'type' => 'text'],
            'sp_core_seopress_canonical_url' => ['meta' => '_seopress_robots_canonical', 'type' => 'url'],
            'sp_core_seopress_noindex' => ['meta' => '_seopress_robots_index', 'type' => 'checkbox'],
            'sp_core_seopress_nofollow' => ['meta' => '_seopress_robots_follow', 'type' => 'checkbox'],
            'sp_core_seopress_social_title' => ['meta' => '_seopress_social_fb_title', 'type' => 'text'],
            'sp_core_seopress_social_description' => ['meta' => '_seopress_social_fb_desc', 'type' => 'textarea'],
            'sp_core_seopress_social_image' => ['meta' => '_seopress_social_fb_img', 'type' => 'url'],
            'sp_core_seopress_twitter_title' => ['meta' => '_seopress_social_twitter_title', 'type' => 'text'],
            'sp_core_seopress_twitter_description' => ['meta' => '_seopress_social_twitter_desc', 'type' => 'textarea'],
            'sp_core_seopress_twitter_image' => ['meta' => '_seopress_social_twitter_img', 'type' => 'url'],
        ];
    }

    public function load_seopress_acf_value($value, $post_id, $field) {
        $name = isset($field['name']) ? (string) $field['name'] : '';
        $map = $this->seopress_acf_field_map();
        if (!isset($map[$name])) {
            return $value;
        }

        $post_id = is_numeric($post_id) ? absint($post_id) : absint(str_replace('post_', '', (string) $post_id));
        if (!$post_id || get_post_type($post_id) !== 'phone') {
            return $value;
        }

        $stored = get_post_meta($post_id, $map[$name]['meta'], true);
        if ($map[$name]['type'] === 'checkbox') {
            return $stored === 'yes' ? 1 : 0;
        }

        if ($stored !== '') {
            return $stored;
        }

        $auto_value = $this->seopress_auto_value($name, $post_id);
        return $auto_value !== '' ? $auto_value : $value;
    }

    private function seopress_auto_value($field_name, $post_id) {
        $post_id = absint($post_id);
        if (!$post_id || get_post_type($post_id) !== 'phone') {
            return '';
        }

        switch ((string) $field_name) {
            case 'sp_core_seopress_meta_title':
            case 'sp_core_seopress_social_title':
            case 'sp_core_seopress_twitter_title':
                return $this->build_phone_seopress_title($post_id);

            case 'sp_core_seopress_meta_description':
            case 'sp_core_seopress_social_description':
            case 'sp_core_seopress_twitter_description':
                return $this->build_phone_seopress_description($post_id);

            case 'sp_core_seopress_focus_keyword':
                return $this->build_phone_seopress_focus_keyword($post_id);

            case 'sp_core_seopress_canonical_url':
                $permalink = get_permalink($post_id);
                return $permalink ? esc_url_raw($permalink) : '';

            case 'sp_core_seopress_social_image':
            case 'sp_core_seopress_twitter_image':
                return $this->build_phone_seopress_image_url($post_id);
        }

        return '';
    }

    private function build_phone_seopress_title($post_id) {
        $title = trim(wp_strip_all_tags(get_the_title($post_id)));
        if ($title === '') {
            return '';
        }

        return sprintf(
            /* translators: %s: phone title. */
            __('%s Full Phone Specifications, Review, Features & Price', 'spesification-core'),
            $title
        );
    }

    private function build_phone_seopress_description($post_id) {
        $description = sp_core_get_phone_description($post_id, true);
        $description = html_entity_decode((string) $description, ENT_QUOTES, sp_core_charset());
        $description = wp_strip_all_tags($description, true);
        $description = preg_replace('/\s+/u', ' ', $description);
        $description = trim((string) $description);

        if ($description === '') {
            $title = trim(wp_strip_all_tags(get_the_title($post_id)));
            if ($title === '') {
                return '';
            }
            $description = sprintf(
                /* translators: %s: phone title. */
                __('%s complete phone specifications, features, review, price, display, camera, battery, performance, and release details.', 'spesification-core'),
                $title
            );
        }

        return wp_html_excerpt($description, 158, '…');
    }

    private function build_phone_seopress_focus_keyword($post_id) {
        $title = trim(wp_strip_all_tags(get_the_title($post_id)));
        if ($title === '') {
            return '';
        }

        return sprintf('%1$s, %1$s specs, %1$s price', $title);
    }

    private function build_phone_seopress_image_url($post_id) {
        $image_url = get_the_post_thumbnail_url($post_id, 'full');
        if (!$image_url) {
            return '';
        }

        return esc_url_raw($image_url);
    }

    public function sync_seopress_acf_value($value, $post_id, $field) {
        $name = isset($field['name']) ? (string) $field['name'] : '';
        $map = $this->seopress_acf_field_map();
        if (!isset($map[$name])) {
            return $value;
        }

        $post_id = is_numeric($post_id) ? absint($post_id) : absint(str_replace('post_', '', (string) $post_id));
        if (!$post_id || get_post_type($post_id) !== 'phone') {
            return $value;
        }

        $type = $map[$name]['type'];
        if ($type === 'checkbox') {
            $clean = !empty($value) ? 'yes' : '';
            $return_value = $clean === 'yes' ? 1 : 0;
        } elseif ($type === 'url') {
            $clean = esc_url_raw((string) $value);
            $return_value = $clean;
        } elseif ($type === 'textarea') {
            $clean = sanitize_textarea_field((string) $value);
            $return_value = $clean;
        } else {
            $clean = sanitize_text_field((string) $value);
            $return_value = $clean;
        }

        if ($clean === '') {
            delete_post_meta($post_id, $map[$name]['meta']);
        } else {
            update_post_meta($post_id, $map[$name]['meta'], $clean);
        }

        return $return_value;
    }

    public function filter_acf_wysiwyg_toolbars($toolbars) {
        if (!is_array($toolbars)) {
            $toolbars = [];
        }

        $toolbars['SP Core Description'] = [
            1 => ['bold', 'italic', 'bullist', 'numlist', 'link', 'unlink', 'removeformat'],
        ];

        $toolbars['sp_core_description'] = [
            1 => ['bold', 'italic', 'bullist', 'numlist', 'link', 'unlink', 'removeformat'],
        ];

        return $toolbars;
    }

    public function register_acf_fields() {
        if (!function_exists('acf_add_local_field_group')) {
            return;
        }

        $this->register_phone_description_field_group();
        $this->register_phone_gallery_field_group();
        $this->register_phone_seopress_field_group();

        $fields = [];

        // Product Market Info integrated into the single Core panel.
        $fields[] = $this->acf_section_structure('field_sp_core_structure_market_info', 'Product Market Info', ['Market Status', 'Release Date', 'Models'], 'market_info');
        $fields[] = $this->acf_select('field_sp_core_market_status', 'Market Status', 'market_status', [
            'Released' => 'Released',
            'Rumored' => 'Rumored',
            'Coming Soon' => 'Coming Soon',
            'Not Available' => 'Not Available',
        ], 'Released');
        $fields[] = $this->acf_text('field_sp_core_release_date', 'Release Date', 'release_date', 'Contoh: March 2026, Q3 2026, atau 28 April 2026');
        $fields[] = $this->acf_text('field_sp_core_models', 'Models', 'models');

        // Price is kept lightweight and separate from the standalone Gallery metabox.
        $fields[] = $this->acf_section_structure('field_sp_core_structure_price', 'Price', ['Price'], 'price');
        $fields[] = $this->acf_text('field_sp_core_price', 'Price', 'price');

        // Specification fields from the canonical Attribute Groups.
        $single_product_sections = $this->get_phone_spec_sections();
        foreach ($single_product_sections as $section_key => $section) {
            $fields[] = $this->acf_section_structure('field_sp_core_structure_' . $section_key, $section['label'], array_values($section['fields']), $section_key);
            foreach ($section['fields'] as $name => $label) {
                $fields[] = $this->acf_spec_textarea('field_sp_core_' . $name, $label, $name, $section_key, 2);
            }
        }

        // Benchmarks integrated from the uploaded ACF export.
        $fields[] = $this->acf_section_structure('field_sp_core_structure_benchmarks', 'Benchmarks', ['Performance Scores', 'AnTuTu Benchmark 11'], 'benchmarks');
        $fields[] = $this->acf_performance_scores_group();
        $fields[] = $this->acf_antutu_benchmark_group();

        // Product Review is rendered by a custom lightweight metabox.
        // The save routine keeps the same ACF-compatible meta keys:
        // pros_list / cons_list and pros_text / cons_text subfields.

        acf_add_local_field_group([
            'key' => 'group_sp_core_phone_specs',
            'title' => 'Phone Specifications',
            'fields' => $fields,
            'location' => $this->phone_acf_location(),
            'menu_order' => 20,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
            'show_in_rest' => 1,
        ]);
    }

    private function phone_acf_location() {
        return [[[
            'param' => 'post_type',
            'operator' => '==',
            'value' => 'phone',
        ]]];
    }

    private function register_phone_description_field_group() {
        acf_add_local_field_group([
            'key' => 'group_sp_core_phone_description',
            'title' => 'Phone Description',
            'fields' => [
                $this->acf_description_editor(
                    'field_sp_core_phone_description',
                    'Description',
                    'phone_description',
                    'Short editorial product description shown before Phone Specifications. Use Bold/Italic only when it improves readability.'
                ),
            ],
            'location' => $this->phone_acf_location(),
            'menu_order' => 0,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
            'show_in_rest' => 1,
        ]);
    }

    private function register_phone_gallery_field_group() {
        acf_add_local_field_group([
            'key' => 'group_sp_core_phone_gallery',
            'title' => 'Phone Gallery',
            'fields' => [
                $this->acf_gallery('field_sp_core_phone_gallery', 'Phone Gallery', 'phone_gallery'),
            ],
            'location' => $this->phone_acf_location(),
            'menu_order' => 10,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
            'show_in_rest' => 1,
        ]);
    }

    private function register_phone_seopress_field_group() {
        acf_add_local_field_group([
            'key' => 'group_sp_core_seopress_seo',
            'title' => 'SEOPress SEO',
            'fields' => [
                [
                    'key' => 'field_sp_core_seopress_meta_title',
                    'label' => __('Meta Title', 'spesification-core'),
                    'name' => 'sp_core_seopress_meta_title',
                    'type' => 'text',
                    'instructions' => __('Auto-detected from the Phone title when empty. Saved to SEOPress meta title.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-primary-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_meta_description',
                    'label' => __('Meta Description', 'spesification-core'),
                    'name' => 'sp_core_seopress_meta_description',
                    'type' => 'textarea',
                    'rows' => 3,
                    'new_lines' => '',
                    'instructions' => __('Auto-detected from Phone Description / excerpt / content when empty. Saved to SEOPress meta description.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-primary-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_focus_keyword',
                    'label' => __('Target Keyword', 'spesification-core'),
                    'name' => 'sp_core_seopress_focus_keyword',
                    'type' => 'text',
                    'instructions' => __('Auto-detected from the Phone title when empty. Saved to SEOPress target keyword.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-primary-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_canonical_url',
                    'label' => __('Canonical URL', 'spesification-core'),
                    'name' => 'sp_core_seopress_canonical_url',
                    'type' => 'text',
                    'instructions' => __('Auto-detected from the Phone permalink when empty. Saved to SEOPress canonical URL.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-primary-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_noindex',
                    'label' => __('Noindex this Phone', 'spesification-core'),
                    'name' => 'sp_core_seopress_noindex',
                    'type' => 'true_false',
                    'ui' => 1,
                    'message' => __('Prevent indexing for this phone.', 'spesification-core'),
                    'wrapper' => ['width' => '50', 'class' => 'sp-core-seopress-toggle-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_nofollow',
                    'label' => __('Nofollow links', 'spesification-core'),
                    'name' => 'sp_core_seopress_nofollow',
                    'type' => 'true_false',
                    'ui' => 1,
                    'message' => __('Add nofollow to links on this phone.', 'spesification-core'),
                    'wrapper' => ['width' => '50', 'class' => 'sp-core-seopress-toggle-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_social_title',
                    'label' => __('Social Title', 'spesification-core'),
                    'name' => 'sp_core_seopress_social_title',
                    'type' => 'text',
                    'instructions' => __('Auto-detected from the Phone title when empty. Saved to SEOPress Open Graph title.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-social-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_social_description',
                    'label' => __('Social Description', 'spesification-core'),
                    'name' => 'sp_core_seopress_social_description',
                    'type' => 'textarea',
                    'rows' => 2,
                    'new_lines' => '',
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-social-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_social_image',
                    'label' => __('Social Image URL', 'spesification-core'),
                    'name' => 'sp_core_seopress_social_image',
                    'type' => 'text',
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-social-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_twitter_title',
                    'label' => __('Twitter/X Title', 'spesification-core'),
                    'name' => 'sp_core_seopress_twitter_title',
                    'type' => 'text',
                    'instructions' => __('Auto-detected from the Phone title when empty. Saved to SEOPress Twitter/X title.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-social-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_twitter_description',
                    'label' => __('Twitter/X Description', 'spesification-core'),
                    'name' => 'sp_core_seopress_twitter_description',
                    'type' => 'textarea',
                    'rows' => 2,
                    'new_lines' => '',
                    'instructions' => __('Auto-detected from Phone Description when empty. Saved to SEOPress Twitter/X description.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-social-field'],
                ],
                [
                    'key' => 'field_sp_core_seopress_twitter_image',
                    'label' => __('Twitter/X Image URL', 'spesification-core'),
                    'name' => 'sp_core_seopress_twitter_image',
                    'type' => 'text',
                    'instructions' => __('Auto-detected from the featured image when empty. Saved to SEOPress Twitter/X image.', 'spesification-core'),
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-seopress-social-field'],
                ],
            ],
            'location' => $this->phone_acf_location(),
            'menu_order' => 15,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
            'show_in_rest' => 1,
        ]);
    }

    private function acf_tab($key, $label) {
        return ['key' => $key, 'label' => $label, 'name' => '', 'type' => 'tab', 'placement' => 'top'];
    }

    private function acf_text($key, $label, $name, $instructions = '') {
        return ['key' => $key, 'label' => $label, 'name' => $name, 'type' => 'text', 'instructions' => $instructions, 'wrapper' => ['width' => '50']];
    }

    private function acf_select($key, $label, $name, array $choices, $default = '') {
        return [
            'key' => $key,
            'label' => $label,
            'name' => $name,
            'type' => 'select',
            'choices' => $choices,
            'default_value' => $default,
            'return_format' => 'value',
            'allow_null' => 0,
            'multiple' => 0,
            'ui' => 1,
            'ajax' => 0,
            'wrapper' => ['width' => '50'],
        ];
    }

    private function acf_textarea($key, $label, $name, $rows = 3, $instructions = '') {
        return ['key' => $key, 'label' => $label, 'name' => $name, 'type' => 'textarea', 'rows' => $rows, 'new_lines' => '', 'instructions' => $instructions, 'wrapper' => ['width' => '100']];
    }

    private function acf_description_editor($key, $label, $name, $instructions = '') {
        return [
            'key' => $key,
            'label' => $label,
            'name' => $name,
            'type' => 'wysiwyg',
            'tabs' => 'visual',
            'toolbar' => 'sp_core_description',
            'media_upload' => 0,
            'quicktags' => false,
            'delay' => 1,
            'instructions' => $instructions,
            'wrapper' => ['width' => '100', 'class' => 'sp-core-description-editor'],
        ];
    }

    private function acf_spec_textarea($key, $label, $name, $section_key, $rows = 3, $instructions = '') {
        $section_key = sanitize_key($section_key);
        return [
            'key' => $key,
            'label' => $label,
            'name' => $name,
            'type' => 'textarea',
            'rows' => $rows,
            'new_lines' => '',
            'instructions' => $instructions,
            'wrapper' => [
                'width' => '100',
                'class' => 'sp-core-accordion-child sp-core-accordion-child-' . $section_key,
            ],
        ];
    }

    private function acf_number($key, $label, $name) {
        return ['key' => $key, 'label' => $label, 'name' => $name, 'type' => 'number', 'step' => '0.1', 'wrapper' => ['width' => '25']];
    }

    private function acf_gallery($key, $label, $name) {
        return [
            'key' => $key,
            'label' => $label,
            'name' => $name,
            'type' => 'gallery',
            'return_format' => 'id',
            'preview_size' => 'thumbnail',
            'insert' => 'append',
            'library' => 'all',
            'min' => 0,
            'max' => 0,
            'wrapper' => ['width' => '100', 'class' => 'sp-core-gallery-field'],
        ];
    }

    private function acf_review_repeater($key, $label, $name, $item_key, $item_label, $subfield_name = 'item', $button_label = 'Add Row') {
        return [
            'key' => $key,
            'label' => $label,
            'name' => $name,
            'type' => 'repeater',
            'layout' => 'block',
            'pagination' => 0,
            'min' => 0,
            'max' => 0,
            'button_label' => $button_label,
            'wrapper' => ['width' => '100', 'class' => 'sp-core-review-repeater sp-core-review-repeater-' . sanitize_html_class($name)],
            'sub_fields' => [
                [
                    'key' => $item_key,
                    'label' => $item_label,
                    'name' => $subfield_name,
                    'type' => 'text',
                    'placeholder' => $item_label === 'Pros' ? 'Example: High performance processor' : 'Example: No SD card slot',
                    'wrapper' => ['width' => '100', 'class' => 'sp-core-review-text-field'],
                ],
            ],
        ];
    }

    private function acf_performance_scores_group() {
        return [
            'key' => 'field_sp_core_performance_scores',
            'label' => 'Performance Scores (1-10)',
            'name' => 'performance_scores',
            'type' => 'group',
            'layout' => 'block',
            'instructions' => 'Masukkan skor editorial 1-10 untuk setiap kategori.',
            'wrapper' => ['width' => '100', 'class' => 'sp-core-benchmark-group sp-core-performance-scores'],
            'sub_fields' => [
                $this->acf_score_number('field_sp_core_score_display', 'Display', 'score_display'),
                $this->acf_score_number('field_sp_core_score_camera', 'Camera', 'score_camera'),
                $this->acf_score_number('field_sp_core_score_performance', 'Performance', 'score_performance'),
                $this->acf_score_number('field_sp_core_score_gaming', 'Gaming', 'score_gaming'),
                $this->acf_score_number('field_sp_core_score_battery', 'Battery', 'score_battery'),
                $this->acf_score_number('field_sp_core_score_connectivity', 'Connectivity', 'score_connectivity'),
            ],
        ];
    }

    private function acf_antutu_benchmark_group() {
        return [
            'key' => 'field_sp_core_antutu_benchmark',
            'label' => 'AnTuTu Benchmark 11',
            'name' => 'antutu_benchmark',
            'type' => 'group',
            'layout' => 'block',
            'wrapper' => ['width' => '100', 'class' => 'sp-core-benchmark-group sp-core-antutu-benchmark'],
            'sub_fields' => [
                $this->acf_score_number('field_sp_core_cpu_score', 'CPU Score', 'cpu_score', false),
                $this->acf_score_number('field_sp_core_gpu_score', 'GPU Score', 'gpu_score', false),
                $this->acf_score_number('field_sp_core_memory_score', 'Memory Score', 'memory_score', false),
                $this->acf_score_number('field_sp_core_ux_score', 'UX Score', 'ux_score', false),
            ],
        ];
    }

    private function acf_score_number($key, $label, $name, $limit_to_100 = true) {
        if (!$limit_to_100) {
            return [
                'key' => $key,
                'label' => $label,
                'name' => $name,
                'type' => 'text',
                'maxlength' => 12,
                'wrapper' => ['width' => '25', 'class' => 'sp-core-score-field sp-core-antutu-score-field'],
            ];
        }

        return [
            'key' => $key,
            'label' => $label,
            'name' => $name,
            'type' => 'number',
            'instructions' => 'Gunakan nilai 1-10.',
            'min' => 0,
            'max' => 10,
            'step' => '0.1',
            'wrapper' => ['width' => '33', 'class' => 'sp-core-score-field'],
        ];
    }

    private function antutu_score_field_keys() {
        return [
            'field_sp_core_cpu_score',
            'field_sp_core_gpu_score',
            'field_sp_core_memory_score',
            'field_sp_core_ux_score',
        ];
    }

    private function parse_antutu_score_value($value) {
        if (is_array($value) || is_object($value)) {
            return null;
        }

        $value = trim(wp_strip_all_tags((string) $value));
        if ($value === '') {
            return 0;
        }

        $digits = preg_replace('/[^0-9]/', '', $value);
        if ($digits === '') {
            return null;
        }

        return (int) $digits;
    }

    private function format_antutu_score_value($number) {
        $number = min(self::ANTUTU_SCORE_MAX, max(0, absint($number)));
        return $number > 0 ? number_format($number, 0, '', '.') : '';
    }

    public function validate_antutu_score_value($valid, $value, $field, $input) {
        if ($valid !== true) {
            return $valid;
        }

        $number = $this->parse_antutu_score_value($value);
        if ($number === null) {
            return __('Use numbers only for AnTuTu score. Dots as thousands separators are allowed.', 'spesification-core');
        }

        if ($number > self::ANTUTU_SCORE_MAX) {
            return sprintf(__('Maximum AnTuTu score per field is %s.', 'spesification-core'), number_format(self::ANTUTU_SCORE_MAX, 0, '', '.'));
        }

        return true;
    }

    public function sanitize_antutu_score_value($value, $post_id, $field, $original) {
        $number = $this->parse_antutu_score_value($value);
        if ($number === null || $number <= 0) {
            return '';
        }

        return $this->format_antutu_score_value($number);
    }

    private function acf_section_structure($key, $label, array $items, $section_key = '') {
        $items = array_values(array_filter(array_map('sanitize_text_field', $items)));
        $section_key = sanitize_key($section_key ?: $label);
        $message = '<div class="sp-core-section-structure-card" data-sp-core-section="' . esc_attr($section_key) . '">'
            . '<button type="button" class="sp-core-accordion-toggle" aria-expanded="false">'
            . '<span class="sp-core-accordion-title-wrap">'
            . '<strong>' . esc_html($label) . '</strong>'
            . '<span>' . esc_html(implode(' · ', $items)) . '</span>'
            . '</span>'
            . '<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5.5 7.5 10 12l4.5-4.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            . '</button>'
            . '</div>';

        return [
            'key' => $key,
            'label' => '',
            'name' => str_replace('field_', '', $key),
            'type' => 'message',
            'message' => $message,
            'new_lines' => '',
            'esc_html' => 0,
            'wrapper' => ['class' => 'sp-core-section-structure sp-core-accordion-heading sp-core-accordion-heading-' . $section_key],
        ];
    }

    private function acf_specification_groups() {
        return [
            'key' => 'field_sp_core_specification_groups',
            'label' => 'Specification Groups',
            'name' => 'specification_groups',
            'type' => 'repeater',
            'layout' => 'block',
            'button_label' => 'Add Specification Group',
            'sub_fields' => [
                ['key' => 'field_sp_core_spec_group_key', 'label' => 'Group Key', 'name' => 'group_key', 'type' => 'text', 'wrapper' => ['width' => '25']],
                ['key' => 'field_sp_core_spec_group_label', 'label' => 'Group Label', 'name' => 'group_label', 'type' => 'text', 'wrapper' => ['width' => '35']],
                ['key' => 'field_sp_core_spec_group_source', 'label' => 'Source', 'name' => 'source', 'type' => 'text', 'wrapper' => ['width' => '20']],
                ['key' => 'field_sp_core_spec_group_position', 'label' => 'Position', 'name' => 'position', 'type' => 'number', 'wrapper' => ['width' => '20']],
                [
                    'key' => 'field_sp_core_spec_items',
                    'label' => 'Items',
                    'name' => 'items',
                    'type' => 'repeater',
                    'layout' => 'table',
                    'button_label' => 'Add Attribute',
                    'sub_fields' => [
                        ['key' => 'field_sp_core_spec_item_key', 'label' => 'Key', 'name' => 'attribute_key', 'type' => 'text'],
                        ['key' => 'field_sp_core_spec_item_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text'],
                        ['key' => 'field_sp_core_spec_item_value', 'label' => 'Value', 'name' => 'value', 'type' => 'textarea', 'rows' => 2],
                        ['key' => 'field_sp_core_spec_item_source_taxonomy', 'label' => 'Source Taxonomy', 'name' => 'source_taxonomy', 'type' => 'text'],
                        ['key' => 'field_sp_core_spec_item_visible', 'label' => 'Visible', 'name' => 'visible', 'type' => 'true_false'],
                        ['key' => 'field_sp_core_spec_item_variation', 'label' => 'Variation', 'name' => 'variation', 'type' => 'true_false'],
                        ['key' => 'field_sp_core_spec_item_position', 'label' => 'Position', 'name' => 'position', 'type' => 'number'],
                    ],
                ],
            ],
        ];
    }

    public function admin_menu() {
        add_menu_page('Specification Core', 'Specification Core', 'manage_options', 'spesification-core', [$this, 'render_core_dashboard_page'], 'dashicons-smartphone', 58);
        add_submenu_page('spesification-core', 'Dashboard', 'Dashboard', 'manage_options', 'spesification-core', [$this, 'render_core_dashboard_page']);
        add_submenu_page('spesification-core', 'Attribute Groups', 'Attribute Groups', 'manage_options', 'spesification-core-attribute-groups', [$this, 'render_attribute_group_registry_page']);
        add_submenu_page('spesification-core', 'Attributes', 'Attributes', 'manage_options', 'spesification-core-attributes', [$this, 'render_attribute_registry_page']);
        add_submenu_page('spesification-core', 'Modules', 'Modules', 'manage_options', 'spesification-core-modules', [$this, 'render_modules_page']);
        add_submenu_page('spesification-core', 'Tools', 'Tools', 'manage_options', 'spesification-core-tools', [$this, 'render_tools_page']);
        add_submenu_page('spesification-core', 'Settings', 'Settings', 'manage_options', 'spesification-core-settings', [$this, 'render_settings_page']);
    }

    public function admin_assets($hook) {
        $allowed_hooks = [
            'toplevel_page_spesification-core',
            'specification-core_page_spesification-core-attribute-groups',
            'specification-core_page_spesification-core-attributes',
            'specification-core_page_spesification-core-modules',
            'specification-core_page_spesification-core-tools',
            'specification-core_page_spesification-core-settings',
        ];

        if (in_array($hook, $allowed_hooks, true)) {
            wp_enqueue_style('sp-core-admin', SP_CORE_URL . 'assets/admin.css', [], SP_CORE_VERSION);
            if ($hook === 'specification-core_page_spesification-core-attributes') {
                wp_enqueue_media();
            }
            wp_enqueue_script('sp-core-dashboard', SP_CORE_URL . 'assets/core-dashboard.js', [], SP_CORE_VERSION, true);
            if ($hook === 'toplevel_page_spesification-core' || $hook === 'specification-core_page_spesification-core-tools') {
                wp_localize_script('sp-core-dashboard', 'spCoreDashboard', [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('sp_core_dashboard_scan'),
                    'interval' => 0,
                    'mode' => 'cached',
                ]);
            }
            return;
        }

        if (!$this->is_phone_edit_screen($hook) || !$this->is_module_enabled('phone_meta')) {
            return;
        }

        wp_enqueue_style('sp-core-phone-spec-assist', SP_CORE_URL . 'assets/phone-spec-assist.css', [], SP_CORE_VERSION);
        wp_enqueue_script('sp-core-phone-spec-assist', SP_CORE_URL . 'assets/phone-spec-assist.js', [], SP_CORE_VERSION, true);
        wp_localize_script('sp-core-phone-spec-assist', 'spCorePhoneSpecAssist', $this->phone_spec_assist_payload());
    }

    private function is_phone_edit_screen($hook) {
        if (!in_array($hook, ['post.php', 'post-new.php'], true)) {
            return false;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        return $screen && isset($screen->post_type) && $screen->post_type === 'phone';
    }

    /**
     * Fallback SEOPress editor for CPT phone.
     *
     * Some SEOPress versions expose only the Universal/Gutenberg SEO panel on
     * mobile and do not render their classic metabox for custom post types even
     * when the CPT is filtered into the SEOPress post type list. This fallback
     * writes to SEOPress' own public meta keys, so SEOPress can still use the
     * values while the Phone data-entry workflow keeps a predictable metabox
     * under Phone Specifications / Phone Product Review.
     */
    public function register_phone_review_metabox($post) {
        if (!$post || $post->post_type !== 'phone') {
            return;
        }

        add_meta_box(
            'sp_core_phone_product_review',
            __('Product Review', 'spesification-core'),
            [$this, 'render_phone_review_metabox'],
            'phone',
            'normal',
            'high'
        );
    }

    public function render_phone_review_metabox($post) {
        wp_nonce_field('sp_core_save_phone_review', 'sp_core_phone_review_nonce');

        $pros = sp_core_get_phone_review_list('pros', $post->ID);
        $cons = sp_core_get_phone_review_list('cons', $post->ID);
        ?>
        <div class="sp-core-review-editor sp-core-review-editor-editorial" data-sp-core-review-editor>
            <div class="sp-core-review-intro" aria-hidden="true">
                <span><?php esc_html_e('Editorial Pro Editor', 'spesification-core'); ?></span>
                <strong><?php esc_html_e('Manage frontend review highlights', 'spesification-core'); ?></strong>
            </div>
            <?php $this->render_phone_review_section('pros', __('Pros', 'spesification-core'), $pros); ?>
            <?php $this->render_phone_review_section('cons', __('Cons', 'spesification-core'), $cons); ?>
        </div>
        <?php
    }

    private function render_phone_review_section($type, $label, array $items) {
        $type = $type === 'cons' ? 'cons' : 'pros';
        $items = array_values(array_filter(array_map('sp_core_clean_string', $items), static function ($item) {
            return $item !== '';
        }));
        if (!$items) {
            $items = [''];
        }
        $filled_count = count(array_filter($items));
        $placeholder = $type === 'pros'
            ? __('Example: High performance processor', 'spesification-core')
            : __('Example: No SD card slot', 'spesification-core');
        $button_label = $type === 'pros' ? __('Add Pros', 'spesification-core') : __('Add Cons', 'spesification-core');
        $description = $type === 'pros'
            ? __('Strengths shown on the frontend review card.', 'spesification-core')
            : __('Weaknesses shown on the frontend review card.', 'spesification-core');
        ?>
        <section class="sp-core-review-section sp-core-review-section-<?php echo esc_attr($type); ?>" data-review-section="<?php echo esc_attr($type); ?>">
            <div class="sp-core-review-heading">
                <span class="sp-core-review-mark" aria-hidden="true"><?php echo $type === 'pros' ? '✓' : '×'; ?></span>
                <div class="sp-core-review-title-wrap">
                    <h3><?php echo esc_html($label); ?></h3>
                    <p><?php echo esc_html($description); ?></p>
                </div>
                <span class="sp-core-review-count" data-review-count><?php echo esc_html(sprintf(_n('%d item', '%d items', $filled_count, 'spesification-core'), $filled_count)); ?></span>
                <button type="button" class="sp-core-review-toggle" data-review-toggle aria-expanded="true" aria-label="<?php esc_attr_e('Toggle section', 'spesification-core'); ?>">
                    <svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5.5 12.5 10 8l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
            </div>
            <div class="sp-core-review-body" data-review-body>
                <div class="sp-core-review-list" data-review-list>
                    <?php foreach ($items as $index => $item) : ?>
                        <?php $this->render_phone_review_item($type, $placeholder, $item, $index); ?>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="sp-core-review-add" data-review-add>
                    <span aria-hidden="true">+</span>
                    <strong><?php echo esc_html($button_label); ?></strong>
                </button>
            </div>
            <template data-review-template>
                <?php $this->render_phone_review_item($type, $placeholder, '', 0); ?>
            </template>
        </section>
        <?php
    }

    private function render_phone_review_item($type, $placeholder, $value = '', $index = 0) {
        $type = $type === 'cons' ? 'cons' : 'pros';
        ?>
        <div class="sp-core-review-item" data-review-item>
            <span class="sp-core-review-index" data-review-index><?php echo esc_html(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)); ?></span>
            <input type="text" name="sp_core_phone_review[<?php echo esc_attr($type); ?>][]" value="<?php echo esc_attr($value); ?>" placeholder="<?php echo esc_attr($placeholder); ?>" autocomplete="off" aria-label="<?php echo esc_attr($type === 'pros' ? __('Pros item', 'spesification-core') : __('Cons item', 'spesification-core')); ?>" />
            <button type="button" class="sp-core-review-remove" data-review-remove aria-label="<?php esc_attr_e('Remove item', 'spesification-core'); ?>">
                <svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M7 4.5h6M8 4.5l.4-1h3.2l.4 1M5.5 6.5h9M7 8.5v6M10 8.5v6M13 8.5v6M6.5 6.5l.5 10h6l.5-10" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
        </div>
        <?php
    }

    public function save_phone_review_metabox($post_id, $post) {
        if (!$post || $post->post_type !== 'phone') {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        if (empty($_POST['sp_core_phone_review_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sp_core_phone_review_nonce'])), 'sp_core_save_phone_review')) {
            return;
        }

        $input = [];
        if (!empty($_POST['sp_core_phone_review']) && is_array($_POST['sp_core_phone_review'])) {
            $input = wp_unslash($_POST['sp_core_phone_review']);
        }

        $this->save_phone_review_repeater_meta($post_id, 'pros_list', 'pros_text', 'field_sp_core_pros_list', 'field_sp_core_pros_text', isset($input['pros']) ? $input['pros'] : []);
        $this->save_phone_review_repeater_meta($post_id, 'cons_list', 'cons_text', 'field_sp_core_cons_list', 'field_sp_core_cons_text', isset($input['cons']) ? $input['cons'] : []);
    }

    private function save_phone_review_repeater_meta($post_id, $field_name, $subfield_name, $field_key, $subfield_key, $values) {
        $old_count = absint(get_post_meta($post_id, $field_name, true));
        if (!is_array($values)) {
            $values = [];
        }

        $clean = [];
        foreach ($values as $value) {
            if (is_array($value) || is_object($value)) {
                continue;
            }
            $value = sp_core_clean_string($value);
            if ($value === '' || preg_match('/^\d+$/', $value)) {
                continue;
            }
            if (!in_array($value, $clean, true)) {
                $clean[] = $value;
            }
            if (count($clean) >= 30) {
                break;
            }
        }

        $limit = max($old_count, count($clean), 30);
        for ($i = 0; $i < $limit; $i++) {
            delete_post_meta($post_id, $field_name . '_' . $i . '_' . $subfield_name);
            delete_post_meta($post_id, '_' . $field_name . '_' . $i . '_' . $subfield_name);
            delete_post_meta($post_id, $field_name . '_' . $i . '_item');
            delete_post_meta($post_id, '_' . $field_name . '_' . $i . '_item');
            delete_post_meta($post_id, $field_name . '_' . $i . '_text');
            delete_post_meta($post_id, '_' . $field_name . '_' . $i . '_text');
            delete_post_meta($post_id, $field_name . '_' . $i . '_value');
            delete_post_meta($post_id, '_' . $field_name . '_' . $i . '_value');
        }

        update_post_meta($post_id, $field_name, count($clean));
        update_post_meta($post_id, '_' . $field_name, $field_key);

        foreach ($clean as $i => $value) {
            update_post_meta($post_id, $field_name . '_' . $i . '_' . $subfield_name, $value);
            update_post_meta($post_id, '_' . $field_name . '_' . $i . '_' . $subfield_name, $subfield_key);
        }
    }

    public function register_phone_seopress_fallback_metabox($post) {
        if (!$post || $post->post_type !== 'phone') {
            return;
        }

        // Prefer the ACF local SEOPress SEO field group as the single custom
        // Phone SEO metabox. This fallback is only for installations where ACF
        // is unavailable, preventing duplicate SEO boxes when ACF is active.
        if (function_exists('acf_add_local_field_group')) {
            return;
        }

        add_meta_box(
            'sp_core_seopress_phone_fallback',
            __('SEOPress SEO', 'spesification-core'),
            [$this, 'render_phone_seopress_fallback_metabox'],
            'phone',
            'normal',
            'low'
        );
    }

    private function has_native_seopress_metabox_for_phone() {
        global $wp_meta_boxes;

        if (empty($wp_meta_boxes['phone']) || !is_array($wp_meta_boxes['phone'])) {
            return false;
        }

        foreach ($wp_meta_boxes['phone'] as $context => $priorities) {
            if (!is_array($priorities)) {
                continue;
            }
            foreach ($priorities as $priority => $boxes) {
                if (!is_array($boxes)) {
                    continue;
                }
                foreach ($boxes as $box_id => $box) {
                    $box_id = (string) $box_id;
                    if ($box_id === 'sp_core_seopress_phone_fallback') {
                        continue;
                    }
                    if ($this->is_seopress_metabox($box_id, $box)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public function render_phone_seopress_fallback_metabox($post) {
        wp_nonce_field('sp_core_save_phone_seopress_fallback', 'sp_core_seopress_nonce');

        $title = (string) get_post_meta($post->ID, '_seopress_titles_title', true);
        $description = (string) get_post_meta($post->ID, '_seopress_titles_desc', true);
        $canonical = (string) get_post_meta($post->ID, '_seopress_robots_canonical', true);
        $robots_index = (string) get_post_meta($post->ID, '_seopress_robots_index', true);
        $robots_follow = (string) get_post_meta($post->ID, '_seopress_robots_follow', true);
        $og_title = (string) get_post_meta($post->ID, '_seopress_social_fb_title', true);
        $og_desc = (string) get_post_meta($post->ID, '_seopress_social_fb_desc', true);
        $og_img = (string) get_post_meta($post->ID, '_seopress_social_fb_img', true);
        $tw_title = (string) get_post_meta($post->ID, '_seopress_social_twitter_title', true);
        $tw_desc = (string) get_post_meta($post->ID, '_seopress_social_twitter_desc', true);
        $tw_img = (string) get_post_meta($post->ID, '_seopress_social_twitter_img', true);

        $focus_kw = (string) get_post_meta($post->ID, '_seopress_analysis_target_kw', true);

        $title = $title !== '' ? $title : $this->seopress_auto_value('sp_core_seopress_meta_title', $post->ID);
        $description = $description !== '' ? $description : $this->seopress_auto_value('sp_core_seopress_meta_description', $post->ID);
        $canonical = $canonical !== '' ? $canonical : $this->seopress_auto_value('sp_core_seopress_canonical_url', $post->ID);
        $focus_kw = $focus_kw !== '' ? $focus_kw : $this->seopress_auto_value('sp_core_seopress_focus_keyword', $post->ID);
        $og_title = $og_title !== '' ? $og_title : $this->seopress_auto_value('sp_core_seopress_social_title', $post->ID);
        $og_desc = $og_desc !== '' ? $og_desc : $this->seopress_auto_value('sp_core_seopress_social_description', $post->ID);
        $og_img = $og_img !== '' ? $og_img : $this->seopress_auto_value('sp_core_seopress_social_image', $post->ID);
        $tw_title = $tw_title !== '' ? $tw_title : $this->seopress_auto_value('sp_core_seopress_twitter_title', $post->ID);
        $tw_desc = $tw_desc !== '' ? $tw_desc : $this->seopress_auto_value('sp_core_seopress_twitter_description', $post->ID);
        $tw_img = $tw_img !== '' ? $tw_img : $this->seopress_auto_value('sp_core_seopress_twitter_image', $post->ID);
        ?>
        <div class="sp-core-seopress-fallback">
            <p class="sp-core-seopress-note">
                <?php esc_html_e('Fallback classic SEO box for Phone. Values are saved to SEOPress meta keys and remain compatible with SEOPress output.', 'spesification-core'); ?>
            </p>

            <div class="sp-core-seopress-grid">
                <label>
                    <span><?php esc_html_e('Meta Title', 'spesification-core'); ?></span>
                    <input type="text" name="sp_core_seopress[_seopress_titles_title]" value="<?php echo esc_attr($title); ?>" placeholder="%%post_title%% %%sep%% %%sitetitle%%" />
                </label>

                <label>
                    <span><?php esc_html_e('Meta Description', 'spesification-core'); ?></span>
                    <textarea name="sp_core_seopress[_seopress_titles_desc]" rows="3" placeholder="<?php esc_attr_e('Short SEO description for this phone.', 'spesification-core'); ?>"><?php echo esc_textarea($description); ?></textarea>
                </label>

                <label>
                    <span><?php esc_html_e('Target Keyword', 'spesification-core'); ?></span>
                    <input type="text" name="sp_core_seopress[_seopress_analysis_target_kw]" value="<?php echo esc_attr($focus_kw); ?>" placeholder="<?php esc_attr_e('Phone title, specs, price', 'spesification-core'); ?>" />
                </label>

                <label>
                    <span><?php esc_html_e('Canonical URL', 'spesification-core'); ?></span>
                    <input type="text" name="sp_core_seopress[_seopress_robots_canonical]" value="<?php echo esc_attr($canonical); ?>" placeholder="https://example.com/phone/device/" />
                </label>
            </div>

            <div class="sp-core-seopress-checks">
                <label>
                    <input type="checkbox" name="sp_core_seopress[_seopress_robots_index]" value="yes" <?php checked($robots_index, 'yes'); ?> />
                    <span><?php esc_html_e('Noindex this Phone', 'spesification-core'); ?></span>
                </label>
                <label>
                    <input type="checkbox" name="sp_core_seopress[_seopress_robots_follow]" value="yes" <?php checked($robots_follow, 'yes'); ?> />
                    <span><?php esc_html_e('Nofollow links on this Phone', 'spesification-core'); ?></span>
                </label>
            </div>

            <details class="sp-core-seopress-details">
                <summary><?php esc_html_e('Social metadata', 'spesification-core'); ?></summary>
                <div class="sp-core-seopress-grid">
                    <label>
                        <span><?php esc_html_e('Open Graph Title', 'spesification-core'); ?></span>
                        <input type="text" name="sp_core_seopress[_seopress_social_fb_title]" value="<?php echo esc_attr($og_title); ?>" />
                    </label>
                    <label>
                        <span><?php esc_html_e('Open Graph Description', 'spesification-core'); ?></span>
                        <textarea name="sp_core_seopress[_seopress_social_fb_desc]" rows="2"><?php echo esc_textarea($og_desc); ?></textarea>
                    </label>
                    <label>
                        <span><?php esc_html_e('Open Graph Image URL', 'spesification-core'); ?></span>
                        <input type="text" name="sp_core_seopress[_seopress_social_fb_img]" value="<?php echo esc_attr($og_img); ?>" />
                    </label>
                    <label>
                        <span><?php esc_html_e('Twitter/X Title', 'spesification-core'); ?></span>
                        <input type="text" name="sp_core_seopress[_seopress_social_twitter_title]" value="<?php echo esc_attr($tw_title); ?>" />
                    </label>
                    <label>
                        <span><?php esc_html_e('Twitter/X Description', 'spesification-core'); ?></span>
                        <textarea name="sp_core_seopress[_seopress_social_twitter_desc]" rows="2"><?php echo esc_textarea($tw_desc); ?></textarea>
                    </label>
                    <label>
                        <span><?php esc_html_e('Twitter/X Image URL', 'spesification-core'); ?></span>
                        <input type="text" name="sp_core_seopress[_seopress_social_twitter_img]" value="<?php echo esc_attr($tw_img); ?>" />
                    </label>
                </div>
            </details>
        </div>
        <?php
    }

    public function save_phone_seopress_fallback_metabox($post_id, $post) {
        if (!$post || $post->post_type !== 'phone') {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        if (empty($_POST['sp_core_seopress_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sp_core_seopress_nonce'])), 'sp_core_save_phone_seopress_fallback')) {
            return;
        }

        $allowed = [
            '_seopress_titles_title' => 'text',
            '_seopress_titles_desc' => 'textarea',
            '_seopress_analysis_target_kw' => 'text',
            '_seopress_robots_canonical' => 'url',
            '_seopress_robots_index' => 'checkbox',
            '_seopress_robots_follow' => 'checkbox',
            '_seopress_social_fb_title' => 'text',
            '_seopress_social_fb_desc' => 'textarea',
            '_seopress_social_fb_img' => 'url',
            '_seopress_social_twitter_title' => 'text',
            '_seopress_social_twitter_desc' => 'textarea',
            '_seopress_social_twitter_img' => 'url',
        ];

        $input = [];
        if (!empty($_POST['sp_core_seopress']) && is_array($_POST['sp_core_seopress'])) {
            $input = wp_unslash($_POST['sp_core_seopress']);
        }

        foreach ($allowed as $meta_key => $type) {
            $raw = isset($input[$meta_key]) ? $input[$meta_key] : '';

            if ($type === 'checkbox') {
                $value = $raw === 'yes' ? 'yes' : '';
            } elseif ($type === 'url') {
                $value = esc_url_raw((string) $raw);
            } elseif ($type === 'textarea') {
                $value = sanitize_textarea_field((string) $raw);
            } else {
                $value = sanitize_text_field((string) $raw);
            }

            if ($value === '') {
                delete_post_meta($post_id, $meta_key);
            } else {
                update_post_meta($post_id, $meta_key, $value);
            }
        }
    }

    /**
     * Add CPT phone to SEOPress' editable post type list so SEOPress can
     * register its classic metabox for Phones.
     */
    public function include_phone_in_seopress_post_types($post_types) {
        if (!is_array($post_types)) {
            $post_types = [];
        }

        if (!in_array('phone', $post_types, true)) {
            $post_types[] = 'phone';
        }

        return $post_types;
    }

    /**
     * Disable only the Universal SEO/Gutenberg beacon for Phone edit screens.
     * The classic SEOPress metabox remains available and is ordered below the
     * Specification Core metaboxes.
     */
    public function disable_seopress_universal_metabox_for_phone($can_enqueue = true) {
        if ($this->is_current_admin_phone_edit_context()) {
            return false;
        }

        return $can_enqueue;
    }

    private function is_current_admin_phone_edit_context() {
        if (!is_admin()) {
            return false;
        }

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && isset($screen->post_type) && $screen->post_type === 'phone') {
            return true;
        }

        global $typenow, $pagenow;
        if ($typenow === 'phone' && in_array($pagenow, ['post.php', 'post-new.php'], true)) {
            return true;
        }

        if (!empty($_GET['post'])) {
            $post_id = absint($_GET['post']);
            if ($post_id && get_post_type($post_id) === 'phone') {
                return true;
            }
        }

        if (!empty($_GET['post_type']) && sanitize_key((string) $_GET['post_type']) === 'phone') {
            return true;
        }

        return false;
    }

    /**
     * Keep the Phone editing workflow predictable: Specification Core ACF boxes
     * first, SEOPress classic metaboxes below them.
     */
    public function move_phone_seo_metaboxes_below_specs($post_type, $context, $post) {
        if ($post_type !== 'phone' || !is_admin()) {
            return;
        }

        $this->remove_duplicate_phone_acf_metaboxes();

        global $wp_meta_boxes;
        if (empty($wp_meta_boxes['phone']) || !is_array($wp_meta_boxes['phone'])) {
            return;
        }

        foreach (['normal', 'advanced', 'side'] as $box_context) {
            if (empty($wp_meta_boxes['phone'][$box_context]) || !is_array($wp_meta_boxes['phone'][$box_context])) {
                continue;
            }

            foreach (['high', 'core', 'default', 'low'] as $priority) {
                if (empty($wp_meta_boxes['phone'][$box_context][$priority]) || !is_array($wp_meta_boxes['phone'][$box_context][$priority])) {
                    continue;
                }

                foreach ($wp_meta_boxes['phone'][$box_context][$priority] as $box_id => $box) {
                    $box_id = (string) $box_id;

                    // Our custom SEO editor must stay inside the Specification Core
                    // workflow and be ordered by ACF menu_order + JS guard. Only
                    // native SEOPress boxes are normalized here.
                    if (in_array($box_id, ['acf-group_sp_core_seopress_seo', 'sp_core_seopress_phone_fallback'], true)) {
                        continue;
                    }

                    if (!$this->is_seopress_metabox($box_id, $box)) {
                        continue;
                    }

                    if ($box_context === 'normal' && $priority === 'low') {
                        continue;
                    }

                    if (!isset($wp_meta_boxes['phone']['normal'])) {
                        $wp_meta_boxes['phone']['normal'] = [];
                    }
                    if (!isset($wp_meta_boxes['phone']['normal']['low']) || !is_array($wp_meta_boxes['phone']['normal']['low'])) {
                        $wp_meta_boxes['phone']['normal']['low'] = [];
                    }

                    $wp_meta_boxes['phone']['normal']['low'][$box_id] = $box;
                    unset($wp_meta_boxes['phone'][$box_context][$priority][$box_id]);
                }
            }
        }
    }

    private function duplicate_phone_acf_group_keys() {
        return [
            // Imported ACF groups from old setup.
            'group_product_review_data',
            'group_product_market_info_standalone',
            'group_69ee44342f574',
            // Old Core separate review group; review is now integrated into Phone Specifications.
            'group_sp_core_phone_product_review',
        ];
    }

    public function filter_duplicate_external_phone_acf_groups($field_group) {
        if (!is_array($field_group) || empty($field_group['key'])) {
            return $field_group;
        }
        if (!$this->is_current_admin_phone_edit_context()) {
            return $field_group;
        }
        if (in_array((string) $field_group['key'], $this->duplicate_phone_acf_group_keys(), true)) {
            $field_group['active'] = false;
        }
        return $field_group;
    }

    private function remove_duplicate_phone_acf_metaboxes() {
        $contexts = ['normal', 'advanced', 'side'];
        foreach ($this->duplicate_phone_acf_group_keys() as $group_key) {
            $box_id = 'acf-' . $group_key;
            foreach ($contexts as $context) {
                remove_meta_box($box_id, 'phone', $context);
            }
        }
    }

    private function is_seopress_metabox($box_id, $box) {
        $box_id = (string) $box_id;
        $title = '';
        if (is_array($box) && isset($box['title'])) {
            $title = wp_strip_all_tags((string) $box['title']);
        }

        return stripos($box_id, 'seopress') !== false
            || stripos($box_id, 'seopress_pro') !== false
            || stripos($title, 'SEOPress') !== false;
    }

    public function filter_phone_hidden_metaboxes($hidden, $option = '', $user = null) {
        return $this->remove_seopress_from_hidden_metaboxes($hidden);
    }

    public function filter_hidden_meta_boxes_for_phone($hidden, $screen, $use_defaults) {
        if ($screen && isset($screen->post_type) && $screen->post_type === 'phone') {
            return $this->remove_seopress_from_hidden_metaboxes($hidden);
        }

        return $hidden;
    }

    private function remove_seopress_from_hidden_metaboxes($hidden) {
        if (!is_array($hidden)) {
            return $hidden;
        }

        return array_values(array_filter($hidden, function ($id) {
            $id = (string) $id;
            return stripos($id, 'seopress') === false;
        }));
    }

    public function filter_phone_metabox_order($order, $option = '', $user = null) {
        $preferred_top = [
            'acf-group_sp_core_phone_description',
            'acf-group_sp_core_phone_gallery',
            'sp_core_phone_product_review',
            'acf-group_sp_core_seopress_seo',
            'sp_core_seopress_phone_fallback',
            'acf-group_sp_core_phone_specs',
        ];

        $preferred_seo = [
            'seopress_cpt',
            'seopress_content_analysis',
            'seopress_schemas',
            'seopress_social',
            'seopress_redirections',
            'seopress_video',
            'seopress_news',
        ];

        $normal = [];
        foreach (array_merge($preferred_top, $preferred_seo) as $id) {
            if (!in_array($id, $normal, true)) {
                $normal[] = $id;
            }
        }

        if (is_array($order) && !empty($order['normal'])) {
            foreach (explode(',', (string) $order['normal']) as $id) {
                $id = trim($id);
                if ($id === '' || in_array(str_replace('acf-', '', $id), $this->duplicate_phone_acf_group_keys(), true)) {
                    continue;
                }
                if ($id !== '' && !in_array($id, $normal, true)) {
                    $normal[] = $id;
                }
            }
        }

        return [
            'normal' => implode(',', $normal),
            'side' => is_array($order) && isset($order['side']) ? (string) $order['side'] : '',
            'advanced' => is_array($order) && isset($order['advanced']) ? (string) $order['advanced'] : '',
        ];
    }

    private function phone_spec_assist_payload() {
        $dataset = $this->phone_spec_assist_dataset();
        return [
            'fields' => $dataset['fields'],
            'groups' => $dataset['groups'],
            'labels' => [
                'hint' => __('Saved values', 'spesification-core'),
                'empty' => __('No saved value found. Type/paste one full value and press Enter.', 'spesification-core'),
                'emptyValue' => __('No value selected yet.', 'spesification-core'),
                'search' => __('Add existing', 'spesification-core'),
                'add' => __('Set', 'spesification-core'),
                'remove' => __('Remove full value', 'spesification-core'),
                'clear' => __('Clear value', 'spesification-core'),
                'selectAll' => __('Select all suggestions', 'spesification-core'),
                'editorHint' => __('Enter sets one complete value. Commas are kept inside the value.', 'spesification-core'),
                'oneChip' => __('1 attribute = 1 full value', 'spesification-core'),
                'oneChipHint' => __('Search or paste a full value. Commas stay inside the value. Use × to clear the whole value.', 'spesification-core'),
                'quickPaste' => __('Quick Paste GSMArena', 'spesification-core'),
                'quickPastePlaceholder' => __('Paste one GSMArena section here. Markdown links and mobile copy text will be cleaned automatically.', 'spesification-core'),
                'parseFill' => __('Parse & Fill', 'spesification-core'),
                'close' => __('Close', 'spesification-core'),
                'quickPasteReady' => __('Ready to parse GSMArena section text.', 'spesification-core'),
            ],
        ];
    }

    /**
     * Heavy part of the phone spec assist payload (existing field values + group
     * map). This runs a postmeta JOIN scan and is identical for every Phone edit
     * screen, so we cache it in a transient and refresh it only when phone data
     * or the attribute registry/groups change. Saves a large DB scan on every
     * editor load.
     */
    private function phone_spec_assist_dataset() {
        $cache_key = 'sp_core_spec_assist_dataset_v1';
        $cached = get_transient($cache_key);
        if (is_array($cached) && isset($cached['fields'], $cached['groups'])) {
            return $cached;
        }

        $dataset = [
            'fields' => $this->build_phone_spec_field_suggestions(),
            'groups' => $this->phone_spec_assist_groups(),
        ];
        set_transient($cache_key, $dataset, 30 * MINUTE_IN_SECONDS);
        return $dataset;
    }

    /**
     * Invalidate the cached spec assist dataset. Hooked to phone saves and to
     * attribute registry/group option updates so the editor never shows stale
     * suggestions.
     */
    public function flush_spec_assist_cache() {
        delete_transient('sp_core_spec_assist_dataset_v1');
    }

    private function phone_spec_assist_groups() {
        $groups = [];
        foreach ($this->get_phone_attribute_groups_assoc() as $group_key => $group) {
            if (empty($group['attributes'])) {
                continue;
            }
            $groups[] = [
                'key' => $group_key,
                'label' => $group['group_label'] ?? ucwords(str_replace('_', ' ', $group_key)),
            ];
        }
        return $groups;
    }

    private function build_phone_spec_field_suggestions() {
        $field_suggestions = [];
        $section_header_fields = $this->group_title_field_names();

        // Register every known specification field first, even when it does not
        // yet have saved terms. This allows the WooCommerce-like editor to work
        // as a clean value picker + manual input on all Phone Specification fields.
        foreach ($this->attribute_to_acf_map() as $source_label => $field_name) {
            $field_name = sanitize_key($field_name);
            if ($field_name === '' || $this->is_attribute_group_title($source_label) || in_array($field_name, ['brand', 'series'], true) || in_array($field_name, $section_header_fields, true)) {
                continue;
            }
            if (!isset($field_suggestions[$field_name])) {
                $field_suggestions[$field_name] = [
                    'label' => sp_core_clean_string($source_label),
                    'values' => [],
                ];
            }
        }

        $registry = get_option('sp_core_phone_attribute_registry', []);

        foreach ((array) $registry as $attribute) {
            if (!is_array($attribute)) {
                continue;
            }

            $field_name = $this->registry_attribute_to_acf_field($attribute);
            if ($field_name === '' || in_array($field_name, $section_header_fields, true)) {
                continue;
            }

            if (!isset($field_suggestions[$field_name])) {
                $field_suggestions[$field_name] = [
                    'label' => !empty($attribute['label']) ? sp_core_clean_string($attribute['label']) : ucwords(str_replace('_', ' ', $field_name)),
                    'values' => [],
                ];
            }

            foreach ($this->registry_terms_to_names($attribute['terms'] ?? []) as $value) {
                if ($value !== '') {
                    $field_suggestions[$field_name]['values'][] = $value;
                }
            }
        }

        foreach ($this->collect_existing_phone_field_values() as $field_name => $values) {
            if (in_array($field_name, $section_header_fields, true)) {
                continue;
            }
            if (!isset($field_suggestions[$field_name])) {
                $field_suggestions[$field_name] = [
                    'label' => ucwords(str_replace('_', ' ', $field_name)),
                    'values' => [],
                ];
            }
            foreach ($values as $value) {
                if ($value !== '') {
                    $field_suggestions[$field_name]['values'][] = $value;
                }
            }
        }

        foreach ($field_suggestions as $field_name => $payload) {
            $seen = [];
            $values = [];
            foreach ((array) ($payload['values'] ?? []) as $value) {
                $value = sp_core_clean_string($value);
                if ($value === '') {
                    continue;
                }
                $hash = strtolower(remove_accents($value));
                if (isset($seen[$hash])) {
                    continue;
                }
                $seen[$hash] = true;
                $values[] = $value;
            }
            natcasesort($values);
            $field_suggestions[$field_name]['values'] = array_values($values);
        }

        ksort($field_suggestions);
        return $field_suggestions;
    }

    private function registry_attribute_to_acf_field($attribute) {
        if (!is_array($attribute)) {
            return '';
        }

        $candidates = [
            $attribute['label'] ?? '',
            $attribute['attribute_key'] ?? '',
            $attribute['slug'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            if ($this->is_attribute_group_title($candidate)) {
                continue;
            }
            $field = $this->map_attribute_label_to_acf($candidate);
            if ($field !== '') {
                return $field;
            }
        }

        return '';
    }

    private function collect_existing_phone_field_values() {
        global $wpdb;

        if (!$wpdb instanceof wpdb) {
            return [];
        }

        $field_names = array_values(array_unique(array_filter($this->attribute_to_acf_map())));
        if (!$field_names) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($field_names), '%s'));
        $sql = "
            SELECT pm.meta_key, pm.meta_value
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE p.post_type = 'phone'
              AND p.post_status NOT IN ('trash', 'auto-draft')
              AND pm.meta_key IN ($placeholders)
              AND pm.meta_value <> ''
            LIMIT 2500
        ";

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $rows = $wpdb->get_results($wpdb->prepare($sql, $field_names), ARRAY_A);
        $values = [];

        foreach ((array) $rows as $row) {
            $key = isset($row['meta_key']) ? sanitize_key($row['meta_key']) : '';
            $value = isset($row['meta_value']) ? sp_core_clean_string(maybe_unserialize($row['meta_value'])) : '';
            if ($key === '' || $value === '' || is_serialized($value)) {
                continue;
            }
            if (!isset($values[$key])) {
                $values[$key] = [];
            }
            $values[$key][] = $value;
        }

        return $values;
    }

    public function render_core_dashboard_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $scan = $this->get_dashboard_snapshot(false);
        $stats = $this->dashboard_primary_stats($scan);
        $health_title = !empty($scan['overall']['title']) ? $scan['overall']['title'] : 'Healthy';
        $health_ok = !empty($scan['overall']['state']) && $scan['overall']['state'] !== 'not-working';
        ?>
        <div class="wrap sp-core-admin sp-core-dashboard sp-core-control-center" data-sp-core-dashboard>
            <?php $this->render_admin_topbar($health_ok ? 'Healthy' : 'Needs Review'); ?>

            <section class="sp-core-modern-hero">
                <div class="sp-core-modern-hero-copy">
                    <p class="sp-core-welcome">👋 Welcome back!</p>
                    <h1>Specification Core<br>Control Center</h1>
                    <p class="sp-core-modern-intro">Monitor your phone database, manage modules, and keep everything running at peak performance.</p>
                    <div class="sp-core-modern-actions">
                        <a class="sp-core-main-button" href="<?php echo esc_url(admin_url('admin.php?page=spesification-core-modules')); ?>"><?php echo $this->svg_icon('cube'); ?><span>Manage Modules</span></a>
                        <button type="button" class="sp-core-ghost-button" data-sp-core-rescan><?php echo $this->svg_icon('pulse'); ?><span>Run System Scan</span></button>
                    </div>
                </div>
                <div class="sp-core-product-mark" aria-hidden="true">
                    <div class="sp-core-product-cube"><span>S</span></div>
                    <i></i><b></b><em></em>
                </div>
            </section>

            <section class="sp-core-modern-stats" aria-label="Database statistics">
                <?php foreach ($stats as $stat) : ?>
                    <article class="sp-core-modern-stat-card">
                        <div class="sp-core-modern-stat-icon"><?php echo $this->svg_icon($stat['icon']); ?></div>
                        <div>
                            <span><?php echo esc_html($stat['label']); ?></span>
                            <strong data-sp-core-stat="<?php echo esc_attr($stat['key']); ?>"><?php echo esc_html($stat['value']); ?></strong>
                            <p><?php echo esc_html($stat['caption']); ?></p>
                        </div>
                    </article>
                <?php endforeach; ?>
            </section>


            <section class="sp-core-lower-grid">
                <article class="sp-core-dashboard-card">
                    <h3><?php echo $this->svg_icon('pulse'); ?> System Health Overview</h3>
                    <?php $this->render_health_line('Database Structure', 'Good', 'good'); ?>
                    <?php $this->render_health_line('Rewrite Rules', 'Good', 'good'); ?>
                    <?php $this->render_health_line('Attribute Integrity', $health_ok ? 'Good' : 'Review', $health_ok ? 'good' : 'warning'); ?>
                    <?php $this->render_health_line('Orphaned Meta', 'Warning', 'warning'); ?>
                    <?php $this->render_health_line('Missing Images', 'Warning', 'warning'); ?>
                    <a class="sp-core-card-button" href="<?php echo esc_url(admin_url('admin.php?page=spesification-core-tools')); ?>">View Full Report <?php echo $this->svg_icon('arrow'); ?></a>
                </article>

                <article class="sp-core-dashboard-card">
                    <h3><?php echo $this->svg_icon('bolt'); ?> Quick Actions</h3>
                    <?php $this->render_quick_action('Flush Rewrite Rules', 'sp_core_flush_rewrite', 'sp_core_flush_rewrite'); ?>
                    <?php $this->render_quick_action('Rebuild Attribute Cache', 'sp_core_rebuild_phone_attribute_registry', 'sp_core_rebuild_phone_attribute_registry'); ?>
                    <?php $this->render_quick_link('Regenerate Thumbnails', admin_url('upload.php')); ?>
                    <?php $this->render_quick_link('Clear Transients', admin_url('admin.php?page=spesification-core-tools')); ?>
                    <button type="button" class="sp-core-card-action" data-sp-core-rescan><span><?php echo $this->svg_icon('refresh'); ?> Run System Scan</span><?php echo $this->svg_icon('chevron'); ?></button>
                </article>

                <article class="sp-core-dashboard-card">
                    <h3><?php echo $this->svg_icon('clock'); ?> Recent Activity</h3>
                    <div class="sp-core-activity-list">
                        <p><strong>Dashboard loaded</strong><span><?php echo esc_html(current_time('H:i')); ?></span></p>
                        <p><strong>Attribute groups active</strong><span><?php echo esc_html(number_format_i18n((int) ($this->stat_value($scan, 'groups')))); ?></span></p>
                        <p><strong>System scan completed</strong><span><?php echo esc_html($health_title); ?></span></p>
                    </div>
                    <a class="sp-core-card-button" href="<?php echo esc_url(admin_url('admin.php?page=spesification-core-tools')); ?>">View All Logs <?php echo $this->svg_icon('arrow'); ?></a>
                </article>
            </section>

            <section class="sp-core-system-info">
                <h3><?php echo $this->svg_icon('info'); ?> System Information</h3>
                <div><span>Version</span><strong><?php echo esc_html(SP_CORE_VERSION); ?></strong></div>
                <div><span>PHP Version</span><strong><?php echo esc_html(PHP_VERSION); ?></strong></div>
                <div><span>WordPress</span><strong><?php echo esc_html(get_bloginfo('version')); ?></strong></div>
                <div><span>Active Theme</span><strong><?php echo esc_html(wp_get_theme()->get('Name')); ?></strong></div>
                <div><span>Server</span><strong><?php echo esc_html(isset($_SERVER['SERVER_SOFTWARE']) ? strtok(sanitize_text_field(wp_unslash($_SERVER['SERVER_SOFTWARE'])), '/') : 'WordPress'); ?></strong></div>
            </section>
        </div>
        <?php
    }

    public function render_modules_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $modules = $this->module_definitions();
        $enabled = $this->get_enabled_modules();
        ?>
        <div class="wrap sp-core-admin sp-core-dashboard sp-core-control-center sp-core-modules-page">
            <?php $this->render_admin_topbar('Modules'); ?>
            <section class="sp-core-page-hero">
                <span>Specification Core Modules</span>
                <h1>Module Control Center</h1>
                <p>Enable only the systems you use. Disabled modules should not register their admin hooks, frontend filters, routes, or assets.</p>
            </section>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sp-core-module-form">
                <?php wp_nonce_field('sp_core_save_modules'); ?>
                <input type="hidden" name="action" value="sp_core_save_modules">
                <section class="sp-core-module-list sp-core-module-list-edit">
                    <?php foreach ($modules as $key => $module) : ?>
                        <?php $this->render_module_row($key, $module, in_array($key, $enabled, true), true); ?>
                    <?php endforeach; ?>
                </section>
                <div class="sp-core-save-bar">
                    <p><strong>Core modules stay locked.</strong> Optional modules can be disabled to keep the admin and frontend clean.</p>
                    <button type="submit" class="sp-core-main-button"><?php echo $this->svg_icon('check'); ?><span>Save Modules</span></button>
                </div>
            </form>
        </div>
        <?php
    }

    public function render_tools_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $scan = $this->get_dashboard_snapshot(false);
        $notice = isset($_GET['sp_core_notice']) ? sanitize_key(wp_unslash($_GET['sp_core_notice'])) : '';
        $migrated = isset($_GET['migrated']) ? absint($_GET['migrated']) : 0;
        $updated = isset($_GET['updated']) ? absint($_GET['updated']) : 0;
        $skipped = isset($_GET['skipped']) ? absint($_GET['skipped']) : 0;
        ?>
        <div class="wrap sp-core-admin sp-core-dashboard sp-core-control-center sp-core-tools-page" data-sp-core-dashboard>
            <?php $this->render_admin_topbar('Tools'); ?>
            <section class="sp-core-page-hero">
                <span>Specification Core Tools</span>
                <h1>Tools</h1>
                <p>Run safe admin-only maintenance, cache rebuilds, registry transfer, and system health checks from one clean page.</p>
            </section>

            <?php if ($notice) : ?>
                <div class="notice notice-success is-dismissible sp-core-notice"><p><?php echo esc_html($this->notice_message($notice, $migrated, $updated, $skipped)); ?></p></div>
            <?php endif; ?>

            <section class="sp-core-lower-grid">
                <article class="sp-core-dashboard-card">
                    <h3><?php echo $this->svg_icon('bolt'); ?> Quick Actions</h3>
                    <?php $this->render_quick_action('Flush Rewrite Rules', 'sp_core_flush_rewrite', 'sp_core_flush_rewrite'); ?>
                    <?php $this->render_quick_action('Rebuild Attribute Cache', 'sp_core_rebuild_phone_attribute_registry', 'sp_core_rebuild_phone_attribute_registry'); ?>
                    <?php $this->render_quick_action('Clean Wrong Terms', 'sp_core_clean_wrong_attribute_terms', 'sp_core_clean_wrong_attribute_terms'); ?>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sp-core-card-action-form" onsubmit="return confirm('Reset attribute groups to default structure? Existing phone values remain untouched.');">
                        <?php wp_nonce_field('sp_core_reset_phone_attribute_groups'); ?>
                        <input type="hidden" name="action" value="sp_core_reset_phone_attribute_groups">
                        <input type="hidden" name="return_page" value="core_tools">
                        <button type="submit" class="sp-core-card-action"><span><?php echo $this->svg_icon('layers'); ?> Reset Attribute Groups</span><?php echo $this->svg_icon('chevron'); ?></button>
                    </form>
                    <button type="button" class="sp-core-card-action" data-sp-core-rescan><span><?php echo $this->svg_icon('refresh'); ?> Run System Scan</span><?php echo $this->svg_icon('chevron'); ?></button>
                </article>

                <article id="sp-core-data-transfer" class="sp-core-dashboard-card sp-core-card-wide sp-core-transfer-card">
                    <h3><?php echo $this->svg_icon('upload'); ?> Attribute Import / Export</h3>
                    <p class="sp-core-card-description">Data transfer tools live here so Attribute and Attribute Group pages stay clean for daily editing.</p>
                    <div class="sp-core-transfer-grid">
                        <div class="sp-core-transfer-box">
                            <h4>Attributes</h4>
                            <p>Export or import attribute registry, field keys, group mapping, terms, and optional term image IDs.</p>
                            <div class="sp-core-transfer-actions">
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                    <?php wp_nonce_field('sp_core_export_phone_attributes'); ?>
                                    <input type="hidden" name="action" value="sp_core_export_phone_attributes">
                                    <button type="submit" class="button sp-core-button-light">Export Attributes</button>
                                </form>
                            </div>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" class="sp-core-import-form">
                                <?php wp_nonce_field('sp_core_import_phone_attributes'); ?>
                                <input type="hidden" name="action" value="sp_core_import_phone_attributes">
                                <label>Import JSON</label>
                                <input type="file" name="sp_core_import_file" accept="application/json,.json">
                                <textarea name="sp_core_import_json" rows="4" placeholder="Or paste attributes JSON here"></textarea>
                                <button type="submit" class="button button-primary sp-core-button-main">Import Attributes</button>
                            </form>
                        </div>

                        <div class="sp-core-transfer-box">
                            <h4>Attribute Groups</h4>
                            <p>Export or import group structure, positions, labels, and mapped attributes.</p>
                            <div class="sp-core-transfer-actions">
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                    <?php wp_nonce_field('sp_core_export_phone_attribute_groups'); ?>
                                    <input type="hidden" name="action" value="sp_core_export_phone_attribute_groups">
                                    <button type="submit" class="button sp-core-button-light">Export Groups</button>
                                </form>
                            </div>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" class="sp-core-import-form">
                                <?php wp_nonce_field('sp_core_import_phone_attribute_groups'); ?>
                                <input type="hidden" name="action" value="sp_core_import_phone_attribute_groups">
                                <label>Import JSON</label>
                                <input type="file" name="sp_core_import_file" accept="application/json,.json">
                                <textarea name="sp_core_import_json" rows="4" placeholder="Or paste attribute groups JSON here"></textarea>
                                <button type="submit" class="button button-primary sp-core-button-main">Import Groups</button>
                            </form>
                        </div>
                    </div>
                </article>

                <article class="sp-core-dashboard-card sp-core-card-wide">
                    <h3><?php echo $this->svg_icon('shield'); ?> System Scan</h3>
                    <div class="sp-core-health-list" data-sp-core-status-grid>
                        <?php foreach ($scan['checks'] as $check) : ?>
                            <?php $this->render_dashboard_mini_status($check); ?>
                        <?php endforeach; ?>
                    </div>
                </article>
            </section>
        </div>
        <?php
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap sp-core-admin sp-core-dashboard sp-core-control-center sp-core-settings-page">
            <?php $this->render_admin_topbar('Settings'); ?>
            <section class="sp-core-page-hero">
                <span>Specification Core Settings</span>
                <h1>Settings</h1>
                <p>Core settings are intentionally minimal. Phone data, attributes, modules, and tools are separated for a cleaner workflow.</p>
            </section>
            <section class="sp-core-lower-grid">
                <article class="sp-core-dashboard-card">
                    <h3><?php echo $this->svg_icon('info'); ?> Data Architecture</h3>
                    <p class="sp-core-card-copy">Specification Core uses native <strong>phone</strong> CPT, native taxonomies, one canonical <strong>price</strong> field, and dynamic attribute groups.</p>
                </article>
                <article class="sp-core-dashboard-card">
                    <h3><?php echo $this->svg_icon('shield'); ?> Security Model</h3>
                    <p class="sp-core-card-copy">Admin actions use capability checks, nonces, sanitized input, escaped output, and POST requests for destructive operations.</p>
                </article>
                <article class="sp-core-dashboard-card">
                    <h3><?php echo $this->svg_icon('pulse'); ?> Performance Model</h3>
                    <p class="sp-core-card-copy">Scanner data is cached. Disabled optional modules are not registered in admin menus, frontend filters, AJAX actions, or asset queues.</p>
                </article>
            </section>
        </div>
        <?php
    }

    private function render_admin_topbar($status_label = 'Healthy') {
        ?>
        <header class="sp-core-mobile-topbar">
            <div class="sp-core-topbar-brand">
                <span class="sp-core-logo-mark" aria-hidden="true">S</span>
                <strong>Specification Core</strong>
                <em>v<?php echo esc_html(SP_CORE_VERSION); ?></em>
            </div>
            <div class="sp-core-topbar-actions">
                <span class="sp-core-health-pill"><i></i><?php echo esc_html($status_label); ?></span>
            </div>
        </header>
        <?php
    }

    private function render_module_row($key, $module, $enabled, $editable = false) {
        $key = sanitize_key($key);
        $locked = !empty($module['core']);
        $enabled = $locked ? true : (bool) $enabled;
        ?>
        <article class="sp-core-module-row <?php echo $enabled ? 'is-enabled' : 'is-disabled'; ?>">
            <div class="sp-core-module-icon"><?php echo $this->svg_icon($module['icon'] ?? 'cube'); ?></div>
            <div class="sp-core-module-copy">
                <strong><?php echo esc_html($module['label'] ?? $key); ?></strong>
                <p><?php echo esc_html($module['description'] ?? ''); ?></p>
            </div>
            <span class="sp-core-module-status"><?php echo $enabled ? 'Enabled' : 'Disabled'; ?></span>
            <label class="sp-core-toggle <?php echo $locked ? 'is-locked' : ''; ?>" aria-label="<?php echo esc_attr(($module['label'] ?? $key) . ' module'); ?>">
                <?php if ($editable && !$locked) : ?>
                    <input class="sp-core-toggle-input" type="checkbox" name="modules[]" value="<?php echo esc_attr($key); ?>" <?php checked($enabled); ?>>
                <?php else : ?>
                    <input class="sp-core-toggle-input" type="checkbox" disabled <?php checked($enabled); ?>>
                <?php endif; ?>
                <span></span>
            </label>
            <span class="sp-core-impact"><?php echo $this->svg_icon('bars'); ?> <?php echo esc_html($module['impact'] ?? 'Low Impact'); ?></span>
            <span class="sp-core-row-arrow"><?php echo $this->svg_icon('chevron'); ?></span>
        </article>
        <?php
    }

    private function render_health_line($label, $status, $state = 'good') {
        ?>
        <p class="sp-core-health-line is-<?php echo esc_attr(sanitize_key($state)); ?>"><span><?php echo esc_html($label); ?></span><strong><?php echo esc_html($status); ?></strong><?php echo $this->svg_icon($state === 'warning' ? 'warning' : 'check-circle'); ?></p>
        <?php
    }

    private function render_quick_action($label, $action, $nonce_action) {
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sp-core-card-action-form">
            <?php wp_nonce_field($nonce_action); ?>
            <input type="hidden" name="action" value="<?php echo esc_attr($action); ?>">
            <input type="hidden" name="return_page" value="core_tools">
            <button type="submit" class="sp-core-card-action"><span><?php echo $this->svg_icon('refresh'); ?> <?php echo esc_html($label); ?></span><?php echo $this->svg_icon('chevron'); ?></button>
        </form>
        <?php
    }

    private function render_quick_link($label, $url) {
        ?>
        <a class="sp-core-card-action" href="<?php echo esc_url($url); ?>"><span><?php echo $this->svg_icon('refresh'); ?> <?php echo esc_html($label); ?></span><?php echo $this->svg_icon('chevron'); ?></a>
        <?php
    }

    private function dashboard_primary_stats($scan) {
        return [
            ['key' => 'phones', 'icon' => 'phone', 'label' => 'Phones', 'value' => number_format_i18n((int) $this->stat_value($scan, 'phones')), 'caption' => 'All published'],
            ['key' => 'brands', 'icon' => 'tag', 'label' => 'Brands', 'value' => number_format_i18n((int) $this->stat_value($scan, 'brands')), 'caption' => 'All brands'],
            ['key' => 'groups', 'icon' => 'layers', 'label' => 'Attribute Groups', 'value' => number_format_i18n((int) $this->stat_value($scan, 'groups')), 'caption' => 'Active groups'],
            ['key' => 'health', 'icon' => 'pulse', 'label' => 'System Health', 'value' => !empty($scan['overall']['state']) && $scan['overall']['state'] === 'not-working' ? 'Review' : 'Healthy', 'caption' => !empty($scan['overall']['state']) && $scan['overall']['state'] === 'not-working' ? 'Needs attention' : 'Everything looks good'],
        ];
    }

    private function stat_value($scan, $key) {
        if (empty($scan['stats']) || !is_array($scan['stats'])) {
            return 0;
        }
        foreach ($scan['stats'] as $stat) {
            if (($stat['key'] ?? '') === $key) {
                return $stat['value'] ?? 0;
            }
        }
        return 0;
    }

    private function svg_icon($name) {
        $name = sanitize_key($name);
        $icons = [
            'menu' => '<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
            'phone' => '<svg viewBox="0 0 24 24"><rect x="7" y="2.5" width="10" height="19" rx="2.4"/><path d="M10.5 18h3"/></svg>',
            'tag' => '<svg viewBox="0 0 24 24"><path d="M20 10.5 12 18.5 4.5 11V4h7.5L20 12z"/><path d="M8.5 8.5h.01"/></svg>',
            'layers' => '<svg viewBox="0 0 24 24"><path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5"/><path d="m3 16 9 5 9-5"/></svg>',
            'pulse' => '<svg viewBox="0 0 24 24"><path d="M3 12h4l2-6 4 13 2-7h6"/></svg>',
            'cube' => '<svg viewBox="0 0 24 24"><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4 7.5 8 4.5 8-4.5"/><path d="M12 12v9"/></svg>',
            'sliders' => '<svg viewBox="0 0 24 24"><path d="M4 6h6M14 6h6M4 12h12M20 12h0M4 18h3M11 18h9"/><circle cx="12" cy="6" r="2"/><circle cx="18" cy="12" r="2"/><circle cx="9" cy="18" r="2"/></svg>',
            'scan' => '<svg viewBox="0 0 24 24"><path d="M7 3H5a2 2 0 0 0-2 2v2M17 3h2a2 2 0 0 1 2 2v2M7 21H5a2 2 0 0 1-2-2v-2M17 21h2a2 2 0 0 0 2-2v-2"/><path d="M8 12h8"/></svg>',
            'scale' => '<svg viewBox="0 0 24 24"><path d="M12 3v18M5 7h14M6 7l-3 6h6L6 7Zm12 0-3 6h6l-3-6Z"/></svg>',
            'link' => '<svg viewBox="0 0 24 24"><path d="M10 13a5 5 0 0 0 7.1 0l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.1 0l-2 2A5 5 0 0 0 12 20.1l1.1-1.1"/></svg>',
            'currency' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M15 9.5c-.5-1-1.6-1.6-3-1.6-1.7 0-3 .9-3 2.2 0 3.2 6 1.2 6 4.6 0 1.4-1.3 2.4-3.1 2.4-1.5 0-2.7-.7-3.2-1.8M12 6v12"/></svg>',
            'upload' => '<svg viewBox="0 0 24 24"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 17v3h16v-3"/></svg>',
            'database' => '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></svg>',
            'shield' => '<svg viewBox="0 0 24 24"><path d="M12 3 20 6v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6l8-3Z"/><path d="m9 12 2 2 4-5"/></svg>',
            'globe' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.4 2.5 3.6 5.5 3.6 9S14.4 18.5 12 21M12 3C9.6 5.5 8.4 8.5 8.4 12S9.6 18.5 12 21"/></svg>',
            'bars' => '<svg viewBox="0 0 24 24"><path d="M5 20V14M10 20V9M15 20V5M20 20V11"/></svg>',
            'chevron' => '<svg viewBox="0 0 24 24"><path d="m9 5 7 7-7 7"/></svg>',
            'arrow' => '<svg viewBox="0 0 24 24"><path d="M7 17 17 7M8 7h9v9"/></svg>',
            'bolt' => '<svg viewBox="0 0 24 24"><path d="M13 2 4 14h7l-1 8 10-13h-7l0-7Z"/></svg>',
            'clock' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
            'info' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 10v7M12 7h.01"/></svg>',
            'refresh' => '<svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 0 0-14.5-4M4 4v5h5M4 13a8 8 0 0 0 14.5 4M20 20v-5h-5"/></svg>',
            'check' => '<svg viewBox="0 0 24 24"><path d="m5 13 4 4L19 7"/></svg>',
            'check-circle' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/></svg>',
            'warning' => '<svg viewBox="0 0 24 24"><path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5M12 17h.01"/></svg>',
            'image' => '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M8 13l2.5-2.5L14 14l2-2 3 3"/><circle cx="8.5" cy="9" r="1"/></svg>',
        ];
        return $icons[$name] ?? $icons['cube'];
    }

    private function render_dashboard_status_card($check) {
        $state = isset($check['state']) ? sanitize_key($check['state']) : 'working';
        ?>
        <div class="sp-core-status-item is-<?php echo esc_attr($state); ?>" data-sp-core-check="<?php echo esc_attr($check['key'] ?? ''); ?>">
            <span class="sp-core-pulse" aria-hidden="true"></span>
            <div>
                <strong><?php echo esc_html($check['label'] ?? ''); ?></strong>
                <p><?php echo esc_html($check['message'] ?? ''); ?></p>
            </div>
            <em><?php echo esc_html($check['status'] ?? 'Working'); ?></em>
        </div>
        <?php
    }

    private function render_dashboard_mini_status($item) {
        $state = isset($item['state']) ? sanitize_key($item['state']) : 'working';
        ?>
        <div class="sp-core-mini-status is-<?php echo esc_attr($state); ?>" data-sp-core-mini="<?php echo esc_attr($item['key'] ?? ''); ?>">
            <span class="sp-core-pulse" aria-hidden="true"></span>
            <div><strong><?php echo esc_html($item['label'] ?? ''); ?></strong><p><?php echo esc_html($item['message'] ?? ''); ?></p></div>
            <em><?php echo esc_html($item['status'] ?? 'Working'); ?></em>
        </div>
        <?php
    }

    public function ajax_dashboard_scan() {
        if (!current_user_can('manage_options') || !check_ajax_referer('sp_core_dashboard_scan', 'nonce', false)) {
            wp_send_json_error(['message' => 'Not allowed.'], 403);
        }

        $force = isset($_POST['force']) && sanitize_key(wp_unslash($_POST['force'])) === '1';
        wp_send_json_success($this->get_dashboard_snapshot($force));
    }

    private function get_dashboard_snapshot($force = false) {
        $cache_key = 'sp_core_dashboard_snapshot_v098';
        $cached = get_transient($cache_key);
        if (!$force && is_array($cached) && !empty($cached['generated_at'])) {
            $cached['cached'] = true;
            return $cached;
        }

        $scan = $this->build_dashboard_scan($force ? 'deep' : 'fast');
        $scan['cached'] = false;
        set_transient($cache_key, $scan, 15 * MINUTE_IN_SECONDS);
        update_option('sp_core_dashboard_last_scan', $scan, false);
        return $scan;
    }

    private function build_dashboard_scan($mode = 'fast') {
        $phone_counts = wp_count_posts('phone');
        $phone_total = $phone_counts ? absint(($phone_counts->publish ?? 0) + ($phone_counts->draft ?? 0) + ($phone_counts->pending ?? 0) + ($phone_counts->private ?? 0)) : 0;
        $brand_count = taxonomy_exists('phone_brand') ? wp_count_terms(['taxonomy' => 'phone_brand', 'hide_empty' => false]) : 0;
        $category_count = taxonomy_exists('phone_category') ? wp_count_terms(['taxonomy' => 'phone_category', 'hide_empty' => false]) : 0;
        $tag_count = taxonomy_exists('phone_tag') ? wp_count_terms(['taxonomy' => 'phone_tag', 'hide_empty' => false]) : 0;
        $attribute_registry = get_option('sp_core_phone_attribute_registry', []);
        $groups = $this->get_phone_attribute_groups_assoc();
        $acf_active = function_exists('acf_add_local_field_group');
        $seopress_active = defined('SEOPRESS_VERSION') || defined('SEOPRESS_PRO_VERSION') || class_exists('SEOPress\\Core\\Kernel');
        $currency_active = function_exists('srcs_get_phone_price_html') || class_exists('SRCurrencySwitcher') || class_exists('CurrencySwitcher');
        $theme_php_health = $this->scan_theme_php_files($mode === 'deep');
        $template = $theme_php_health['single_phone_path'];
        $registry_health = $this->scan_value_registry_health($attribute_registry);
        $field_health = $this->scan_field_integrity();

        $checks = [
            $this->dashboard_check('cpt_phone', 'CPT Phone', post_type_exists('phone'), post_type_exists('phone') ? 'Active' : 'Not Working', post_type_exists('phone') ? 'Phone post type is registered.' : 'Phone post type is not registered.'),
            $this->dashboard_check('taxonomies', 'Taxonomies', taxonomy_exists('phone_brand') && taxonomy_exists('phone_category') && taxonomy_exists('phone_series') && taxonomy_exists('phone_tag'), 'Working', 'Brand, category, series, and tag structures.'),
            $this->dashboard_check('acf_pro', 'ACF Pro', $acf_active, $acf_active ? 'Active' : 'Not Working', $acf_active ? 'ACF field registration is available.' : 'ACF Pro is required for the Phone editor.'),
            $this->dashboard_check('field_integrity', 'Field Integrity', $field_health['ok'], $field_health['ok'] ? 'Working' : 'Not Working', $field_health['summary']),
            $this->dashboard_check('value_registry', 'Value Registry', $registry_health['ok'], $registry_health['ok'] ? 'Working' : 'Detected', $registry_health['summary']),
            $this->dashboard_check('template', 'Theme PHP Files', $theme_php_health['ok'], $theme_php_health['ok'] ? 'Detected' : 'Not Working', $theme_php_health['summary']),
            $this->dashboard_check('seopress', 'SEOPress Bridge', $seopress_active, $seopress_active ? 'Detected' : 'Not Working', $seopress_active ? 'SEOPress is available for metadata bridge.' : 'SEOPress was not detected.'),
            $this->dashboard_check('currency', 'Currency Bridge', $currency_active, $currency_active ? 'Active' : 'Not Working', $currency_active ? 'Currency Switcher bridge is available.' : 'Currency Switcher bridge was not detected.'),
        ];

        $overall_ok = true;
        foreach ($checks as $check) {
            if (($check['state'] ?? '') === 'not-working') {
                $overall_ok = false;
                break;
            }
        }

        return [
            'generated_at' => current_time('mysql'),
            'mode' => $mode,
            'overall' => [
                'state' => $overall_ok ? 'active' : 'not-working',
                'title' => $overall_ok ? 'Working' : 'Needs Attention',
                'message' => $overall_ok ? 'All primary systems are working.' : 'One or more primary systems need attention.',
            ],
            'stats' => [
                ['key' => 'phones', 'label' => 'Phones', 'value' => $phone_total, 'caption' => 'CPT Phone records'],
                ['key' => 'brands', 'label' => 'Brands', 'value' => is_wp_error($brand_count) ? 0 : $brand_count, 'caption' => 'Brand taxonomy'],
                ['key' => 'categories', 'label' => 'Categories', 'value' => is_wp_error($category_count) ? 0 : $category_count, 'caption' => 'Category taxonomy'],
                ['key' => 'tags', 'label' => 'Tags', 'value' => is_wp_error($tag_count) ? 0 : $tag_count, 'caption' => 'Phone tags'],
                ['key' => 'attributes', 'label' => 'Attributes', 'value' => is_array($attribute_registry) ? count($attribute_registry) : 0, 'caption' => 'Value registry'],
                ['key' => 'groups', 'label' => 'Groups', 'value' => is_array($groups) ? count($groups) : 0, 'caption' => 'Editor structure'],
            ],
            'checks' => $checks,
            'integrity' => $field_health['items'],
            'registry' => $registry_health['items'],
            'template' => $theme_php_health['items'],
            'integrations' => [
                $this->dashboard_small_check('seopress', 'SEOPress', $seopress_active, $seopress_active ? 'Detected' : 'Not Working', $seopress_active ? 'Metadata bridge can run.' : 'SEOPress is not active.'),
                $this->dashboard_small_check('currency', 'Currency Switcher', $currency_active, $currency_active ? 'Active' : 'Not Working', $currency_active ? 'Price bridge can run.' : 'Currency Switcher is not active.'),
                $this->dashboard_small_check('price', 'Price', true, 'Working', 'Single canonical field: price.'),
            ],
            'security' => $this->dashboard_security_checks(),
        ];
    }

    private function dashboard_check($key, $label, $ok, $status, $message) {
        $state = $ok ? (in_array($status, ['Active', 'Detected'], true) ? strtolower($status) : 'working') : 'not-working';
        return ['key' => $key, 'label' => $label, 'state' => $state, 'status' => $status, 'message' => $message];
    }

    private function dashboard_small_check($key, $label, $ok, $status, $message) {
        return $this->dashboard_check($key, $label, $ok, $status, $message);
    }



    private function dashboard_security_checks() {
        return [
            $this->dashboard_small_check('nonce_guard', 'Nonce Guard', true, 'Working', 'Admin actions and scanner requests require WordPress nonces.'),
            $this->dashboard_small_check('capability_guard', 'Capability Guard', true, 'Working', 'Core management screens require manage_options.'),
            $this->dashboard_small_check('post_destructive_actions', 'Safe Actions', true, 'Working', 'Delete and reset actions use POST requests.'),
            $this->dashboard_small_check('scanner_scope', 'Scanner Scope', true, 'Working', 'Template scanner is admin-only, cached, and does not expose server paths.'),
            $this->dashboard_small_check('input_limits', 'Input Limits', true, 'Working', 'Attribute, group, and value input lengths are limited.'),
        ];
    }

    private function scan_theme_php_files($deep = false) {
        $theme_dir = function_exists('get_stylesheet_directory') ? get_stylesheet_directory() : '';
        $theme_name = function_exists('wp_get_theme') ? wp_get_theme()->get('Name') : '';
        $single_phone_path = function_exists('locate_template') ? locate_template(['single-phone.php'], false, false) : '';
        $items = [];
        $files = [];

        if (!$theme_dir || !is_dir($theme_dir) || !is_readable($theme_dir)) {
            return [
                'ok' => false,
                'summary' => 'Active child theme directory could not be read.',
                'items' => [
                    $this->dashboard_small_check('theme_directory', 'Theme Directory', false, 'Not Working', 'Active child theme directory is not readable.'),
                ],
                'single_phone_path' => $single_phone_path,
                'count' => 0,
            ];
        }

        $skip_dirs = ['.git', '.svn', 'node_modules', 'vendor', 'cache', 'tmp', 'uploads', 'dist', 'build'];
        $theme_real = realpath($theme_dir);
        $max_files = $deep ? 50 : 0;
        $max_deep_file_bytes = 120000;

        if (!$deep) {
            $candidate_relatives = ['functions.php', 'header.php', 'footer.php', 'single-phone.php', 'archive-phone.php'];
            foreach ($candidate_relatives as $relative) {
                $path = trailingslashit($theme_dir) . $relative;
                if (!is_file($path) || is_link($path)) {
                    continue;
                }
                $real = realpath($path);
                if (!$theme_real || !$real || strpos($real, $theme_real) !== 0) {
                    continue;
                }
                $size = filesize($real);
                $files[] = [
                    'relative' => $relative,
                    'path' => $real,
                    'readable' => is_readable($real),
                    'size' => $size !== false ? absint($size) : 0,
                    'modified' => filemtime($real),
                ];
            }

            $items[] = $this->dashboard_small_check(
                'active_child_theme',
                'Active Theme',
                true,
                'Detected',
                ($theme_name ?: basename($theme_dir)) . ' · lightweight template check.'
            );

            foreach ($files as $file) {
                $items[] = $this->dashboard_small_check(
                    'theme_php_' . substr(md5($file['relative']), 0, 12),
                    $file['relative'],
                    !empty($file['readable']),
                    !empty($file['readable']) ? 'Detected' : 'Not Working',
                    !empty($file['readable']) ? 'Readable file in active child theme.' : 'File exists but is not readable.'
                );
            }

            if (empty($single_phone_path)) {
                $items[] = $this->dashboard_small_check('single_phone_template', 'single-phone.php', false, 'Not Working', 'single-phone.php is missing in the active child theme.');
            }

            return [
                'ok' => !empty($single_phone_path),
                'summary' => 'Lightweight template check completed. Run System Scan only when a deeper helper scan is needed.' . (empty($single_phone_path) ? ' single-phone.php is missing.' : ''),
                'items' => $items,
                'single_phone_path' => $single_phone_path,
                'count' => count($files),
            ];
        }

        try {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveCallbackFilterIterator(
                    new RecursiveDirectoryIterator($theme_dir, FilesystemIterator::SKIP_DOTS),
                    static function ($current) use ($skip_dirs) {
                        if ($current->isDir()) {
                            return !in_array($current->getFilename(), $skip_dirs, true);
                        }
                        return true;
                    }
                ),
                RecursiveIteratorIterator::SELF_FIRST
            );

            foreach ($iterator as $file) {
                if (!$file->isFile() || $file->isLink()) {
                    continue;
                }
                if (strtolower($file->getExtension()) !== 'php') {
                    continue;
                }
                if (count($files) >= $max_files) {
                    break;
                }
                $path = $file->getPathname();
                $real = realpath($path);
                if (!$theme_real || !$real || strpos($real, $theme_real) !== 0) {
                    continue;
                }
                $relative = ltrim(str_replace('\\', '/', substr($real, strlen($theme_real))), '/');
                if ($relative === '' || strpos($relative, '..') !== false) {
                    continue;
                }
                $size = filesize($real);
                $files[] = [
                    'relative' => $relative,
                    'path' => $real,
                    'readable' => is_readable($real),
                    'size' => $size !== false ? absint($size) : 0,
                    'modified' => filemtime($real),
                ];
            }
        } catch (Exception $e) {
            return [
                'ok' => false,
                'summary' => 'Theme PHP scanner failed without exposing server paths.',
                'items' => [
                    $this->dashboard_small_check('theme_scanner', 'Theme PHP Scanner', false, 'Not Working', 'Scanner could not read the active child theme files.'),
                ],
                'single_phone_path' => $single_phone_path,
                'count' => 0,
            ];
        }

        usort($files, static function ($a, $b) {
            $priority = ['functions.php' => 0, 'header.php' => 1, 'footer.php' => 2, 'single-phone.php' => 3, 'archive-phone.php' => 4];
            $ap = $priority[$a['relative']] ?? 50;
            $bp = $priority[$b['relative']] ?? 50;
            if ($ap !== $bp) {
                return $ap <=> $bp;
            }
            return strnatcasecmp($a['relative'], $b['relative']);
        });

        $items[] = $this->dashboard_small_check(
            'active_child_theme',
            'Active Theme',
            true,
            'Detected',
            ($theme_name ?: basename($theme_dir)) . ' · ' . number_format_i18n(count($files)) . ' PHP files detected.'
        );

        if (empty($files)) {
            $items[] = $this->dashboard_small_check('theme_php_files', 'Theme PHP Files', false, 'Not Working', 'No PHP files were detected in the active child theme.');
        }

        foreach ($files as $file) {
            $relative = $file['relative'];
            $is_single_phone = $relative === 'single-phone.php';
            $readable = !empty($file['readable']);
            $message = $readable ? 'Readable file in active child theme.' : 'File exists but is not readable.';
            $status = $readable ? 'Detected' : 'Not Working';
            $ok = $readable;

            if ($is_single_phone && $readable) {
                if ($deep) {
                    if (($file['size'] ?? 0) > $max_deep_file_bytes) {
                        $status = 'Detected';
                        $message = 'single-phone.php exists. File is too large for lightweight helper scan.';
                    } else {
                        $contents = file_get_contents($file['path'], false, null, 0, $max_deep_file_bytes);
                        $uses_core = is_string($contents) && (strpos($contents, 'sp_core_') !== false || strpos($contents, 'sp_phone_') !== false || strpos($contents, 'get_field(') !== false);
                        $status = $uses_core ? 'Working' : 'Detected';
                        $message = $uses_core ? 'single-phone.php is connected to phone/Core data helpers.' : 'single-phone.php exists, but helper usage was not detected.';
                    }
                } else {
                    $status = 'Detected';
                    $message = 'single-phone.php exists. Run Scan Now for helper usage check.';
                }
            }

            $items[] = $this->dashboard_small_check(
                'theme_php_' . substr(md5($relative), 0, 12),
                $relative,
                $ok,
                $status,
                $message
            );
        }

        $ok = !empty($files) && !empty($single_phone_path);
        $summary = number_format_i18n(count($files)) . ' PHP files detected in the active child theme.' . ($deep ? ' Deep scan completed.' : ' Cached lightweight scan.');
        if (empty($single_phone_path)) {
            $summary .= ' single-phone.php is missing.';
        }

        return [
            'ok' => $ok,
            'summary' => $summary,
            'items' => $items,
            'single_phone_path' => $single_phone_path,
            'count' => count($files),
        ];
    }

    private function scan_field_integrity() {
        $expected = [
            'price', 'market_status', 'release_date', 'models',
            'front_main', 'front_second', 'front_features', 'front_video',
            'rear_main', 'rear_second', 'rear_third', 'rear_quad', 'rear_features', 'rear_video',
            'pros_list', 'cons_list', 'performance_scores', 'antutu_benchmark',
        ];
        $legacy = ['price_reference', 'regular_price', 'sale_price', 'main', 'second', 'features', 'video', 'features_rear', 'video_front'];
        $groups = $this->get_phone_attribute_groups_assoc();
        $fields = [];
        foreach ($groups as $group) {
            foreach ((array) ($group['attributes'] ?? []) as $attribute) {
                if (!empty($attribute['field_name'])) {
                    $fields[] = sanitize_key($attribute['field_name']);
                }
            }
        }
        $fields = array_unique(array_merge($fields, ['price', 'market_status', 'release_date', 'models', 'pros_list', 'cons_list', 'performance_scores', 'antutu_benchmark']));
        $missing = array_values(array_diff($expected, $fields));
        $wrong = [];
        foreach ($legacy as $field) {
            if (in_array($field, $fields, true)) {
                $wrong[] = $field;
            }
        }
        $items = [
            $this->dashboard_small_check('canonical_fields', 'Canonical Fields', empty($missing), empty($missing) ? 'Working' : 'Not Working', empty($missing) ? 'All required fields are registered.' : count($missing) . ' required fields need review.'),
            $this->dashboard_small_check('legacy_fields', 'Legacy Field Guard', empty($wrong), empty($wrong) ? 'Working' : 'Not Working', empty($wrong) ? 'No legacy field names in editor structure.' : 'Legacy fields found: ' . implode(', ', array_slice($wrong, 0, 4))),
            $this->dashboard_small_check('price_field', 'Price', true, 'Working', 'Using one field only: price.'),
        ];
        return [
            'ok' => empty($missing) && empty($wrong),
            'summary' => empty($missing) && empty($wrong) ? 'Canonical field structure is clean.' : 'Field structure needs review.',
            'items' => $items,
        ];
    }

    private function scan_value_registry_health($registry) {
        if (!is_array($registry)) {
            $registry = [];
        }
        $empty = 0;
        $duplicates = 0;
        $long = 0;
        foreach ($registry as $entry) {
            $values = isset($entry['terms']) && is_array($entry['terms']) ? $entry['terms'] : (isset($entry['values']) && is_array($entry['values']) ? $entry['values'] : []);
            $clean = [];
            foreach ($values as $value) {
                $value = sp_core_clean_string(is_array($value) ? ($value['name'] ?? '') : $value);
                if ($value === '') {
                    $empty++;
                    continue;
                }
                if (strlen($value) > 120) {
                    $long++;
                }
                $clean[] = mb_strtolower($value);
            }
            $duplicates += max(0, count($clean) - count(array_unique($clean)));
        }
        $ok = $empty === 0 && $duplicates === 0;
        return [
            'ok' => $ok,
            'summary' => $ok ? 'Registry values are ready for autocomplete.' : 'Registry has values that need review.',
            'items' => [
                $this->dashboard_small_check('registry_count', 'Attributes', count($registry) > 0, count($registry) > 0 ? 'Detected' : 'Not Working', number_format_i18n(count($registry)) . ' attributes in registry.'),
                $this->dashboard_small_check('duplicate_values', 'Duplicate Values', $duplicates === 0, $duplicates === 0 ? 'Working' : 'Detected', $duplicates === 0 ? 'No duplicate values detected.' : number_format_i18n($duplicates) . ' duplicate values found.'),
                $this->dashboard_small_check('empty_values', 'Empty Values', $empty === 0, $empty === 0 ? 'Working' : 'Not Working', $empty === 0 ? 'No empty values found.' : number_format_i18n($empty) . ' empty values found.'),
                $this->dashboard_small_check('long_values', 'Long Values', $long === 0, $long === 0 ? 'Working' : 'Detected', $long === 0 ? 'No unusually long values found.' : number_format_i18n($long) . ' long values need review.'),
            ],
        ];
    }

    public function render_attribute_registry_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $registry = get_option('sp_core_phone_attribute_registry', []);
        if (!is_array($registry)) {
            $registry = [];
        }

        $notice = isset($_GET['sp_core_notice']) ? sanitize_key(wp_unslash($_GET['sp_core_notice'])) : '';
        $migrated = isset($_GET['migrated']) ? absint($_GET['migrated']) : 0;
        $updated = isset($_GET['updated']) ? absint($_GET['updated']) : 0;
        $skipped = isset($_GET['skipped']) ? absint($_GET['skipped']) : 0;
        $edit_key = isset($_GET['edit_attribute']) ? sanitize_key(wp_unslash($_GET['edit_attribute'])) : '';
        $editing = $edit_key ? $this->find_attribute_registry_entry($edit_key) : [];
        $is_editing = !empty($editing);
        $group_options = $this->phone_attribute_group_options();

        $return_page = isset($_GET['page']) && $_GET['page'] === 'spesification-core-phone-attributes' ? 'phone' : 'core';
        $current_group = $editing['group_key'] ?? 'network';
        ?>
        <div class="wrap sp-core-admin sp-core-attribute-manager">
            <div class="sp-core-attribute-topbar">
                <div>
                    <div class="sp-core-kicker">Specification Core <span>v<?php echo esc_html(SP_CORE_VERSION); ?></span></div>
                    <h1>Attributes</h1>
                    <p>Kelola attribute dan value registry untuk editor Phone. Cepat, ringkas, dan mobile-first.</p>
                </div>
                <div class="sp-core-attribute-actions">
                    <a class="button sp-core-button-light" href="<?php echo esc_url(admin_url('admin.php?page=spesification-core-tools#sp-core-data-transfer')); ?>">Import / Export</a>
                    <a class="button button-primary sp-core-button-main" href="#sp-core-attribute-form"><?php echo $is_editing ? esc_html__('Edit Attribute', 'spesification-core') : esc_html__('Add Attribute', 'spesification-core'); ?></a>
                </div>
            </div>

            <?php if ($notice) : ?>
                <div class="notice notice-success is-dismissible sp-core-notice"><p><?php echo esc_html($this->notice_message($notice, $migrated, $updated, $skipped)); ?></p></div>
            <?php endif; ?>

            <div class="sp-core-attribute-searchbar" data-sp-core-attribute-search>
                <input type="search" class="sp-core-attribute-search" placeholder="Search attribute..." aria-label="Search attribute">
                <select class="sp-core-attribute-filter" aria-label="Filter group">
                    <option value="">All Groups</option>
                    <?php foreach ($group_options as $group_key => $group_label) : ?>
                        <option value="<?php echo esc_attr($group_key); ?>"><?php echo esc_html($group_label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <section id="sp-core-attribute-form" class="sp-core-panel sp-core-attribute-editor-panel sp-core-attribute-quickform">
                <div class="sp-core-panel-head">
                    <div>
                        <span><?php echo $is_editing ? esc_html__('Edit Attribute', 'spesification-core') : esc_html__('Add Attribute', 'spesification-core'); ?></span>
                        <h2><?php echo $is_editing ? esc_html($editing['label'] ?? '') : esc_html__('New Attribute', 'spesification-core'); ?></h2>
                    </div>
                    <?php if ($is_editing) : ?>
                        <a class="button sp-core-button-light" href="<?php echo esc_url(admin_url('edit.php?post_type=phone&page=spesification-core-phone-attributes')); ?>">Cancel</a>
                    <?php endif; ?>
                </div>

                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sp-core-attribute-form">
                    <?php wp_nonce_field('sp_core_save_phone_attribute'); ?>
                    <input type="hidden" name="action" value="sp_core_save_phone_attribute">
                    <input type="hidden" name="return_page" value="<?php echo esc_attr($return_page); ?>">
                    <input type="hidden" name="original_key" value="<?php echo esc_attr($editing['attribute_key'] ?? ''); ?>">

                    <div class="sp-core-attribute-form-grid">
                        <p class="sp-core-field-name">
                            <label for="sp-core-attribute-label">Name</label>
                            <input id="sp-core-attribute-label" type="text" name="attribute_label" value="<?php echo esc_attr($editing['label'] ?? ''); ?>" placeholder="Bluetooth" required>
                        </p>

                        <p class="sp-core-field-group">
                            <label for="sp-core-attribute-group">Group</label>
                            <select id="sp-core-attribute-group" name="attribute_group">
                                <?php foreach ($group_options as $group_key => $group_label) : ?>
                                    <option value="<?php echo esc_attr($group_key); ?>" <?php selected($current_group, $group_key); ?>><?php echo esc_html($group_label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </p>

                        <div class="sp-core-field-terms">
                            <label for="sp-core-attribute-terms-input">Terms / Values</label>
                            <textarea id="sp-core-attribute-terms" class="sp-core-terms-source" name="attribute_terms" rows="6" placeholder="One value per line&#10;No&#10;Yes&#10;24-bit/192kHz Hi-Res audio"><?php echo esc_textarea($this->registry_terms_to_text($editing['terms'] ?? [])); ?></textarea>
                            <div class="sp-core-terms-builder" data-sp-core-terms-builder data-target="sp-core-attribute-terms">
                                <div class="sp-core-terms-input-row">
                                    <input id="sp-core-attribute-terms-input" class="sp-core-terms-input" type="text" placeholder="Add value, then press Enter" autocomplete="off">
                                    <button type="button" class="sp-core-terms-add">Add</button>
                                </div>
                                <div class="sp-core-terms-chip-list" aria-live="polite"></div>
                            </div>
                            <small>One complete value per chip. Commas stay inside the value. Use × to remove quickly.</small>
                            <?php if ($is_editing && !empty($editing['terms'])) : ?>
                                <div class="sp-core-term-image-manager">
                                    <div class="sp-core-term-image-head">
                                        <strong>Term Images</strong>
                                        <small>Optional tiny logos for values such as Android 16, Snapdragon, UFS, or charging standards.</small>
                                    </div>
                                    <div class="sp-core-term-image-grid">
                                        <?php foreach ((array) $editing['terms'] as $term) :
                                            $term_name = is_array($term) ? sp_core_clean_string($term['name'] ?? '') : sp_core_clean_string($term);
                                            if ($term_name === '') { continue; }
                                            $term_slug = sanitize_title(is_array($term) && !empty($term['slug']) ? $term['slug'] : $term_name);
                                            $image_id = is_array($term) && !empty($term['image_id']) ? absint($term['image_id']) : 0;
                                            $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : '';
                                            ?>
                                            <div class="sp-core-term-image-row" data-sp-term-image-row>
                                                <div class="sp-core-term-image-preview <?php echo $image_url ? 'has-image' : ''; ?>" data-sp-term-image-preview>
                                                    <?php if ($image_url) : ?><img src="<?php echo esc_url($image_url); ?>" alt=""><?php else : ?><?php echo $this->svg_icon('image'); ?><?php endif; ?>
                                                </div>
                                                <div class="sp-core-term-image-name">
                                                    <strong><?php echo esc_html($term_name); ?></strong>
                                                    <code><?php echo esc_html($term_slug); ?></code>
                                                </div>
                                                <input type="hidden" name="term_images[<?php echo esc_attr($term_slug); ?>]" value="<?php echo esc_attr($image_id); ?>" data-sp-term-image-input>
                                                <div class="sp-core-term-image-actions">
                                                    <button type="button" class="button sp-core-mini-button" data-sp-term-image-upload>Select Image</button>
                                                    <button type="button" class="button sp-core-mini-button is-danger" data-sp-term-image-remove>Remove</button>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <details class="sp-core-advanced-field" <?php echo $is_editing && !empty($editing['slug']) ? 'open' : ''; ?>>
                        <summary><span>Advanced</span><span class="sp-core-advanced-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M7 10l5 5 5-5"/></svg></span></summary>
                        <p>
                            <label for="sp-core-attribute-slug">Slug</label>
                            <input id="sp-core-attribute-slug" type="text" name="attribute_slug" value="<?php echo esc_attr($editing['slug'] ?? ''); ?>" placeholder="Auto from name">
                            <small>Leave empty to generate automatically from name.</small>
                        </p>
                    </details>

                    <div class="sp-core-form-actions">
                        <button type="submit" class="button button-primary sp-core-button-main"><?php echo $is_editing ? esc_html__('Save Attribute', 'spesification-core') : esc_html__('Save Attribute', 'spesification-core'); ?></button>
                        <?php if ($is_editing) : ?>
                            <a class="button sp-core-button-light" href="<?php echo esc_url(admin_url('edit.php?post_type=phone&page=spesification-core-phone-attributes')); ?>">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>

            <section class="sp-core-panel sp-core-attribute-list-panel">
                <div class="sp-core-panel-head">
                    <div>
                        <span>Registry</span>
                        <h2>Attribute List</h2>
                    </div>
                    <strong class="sp-core-count-pill"><?php echo esc_html(number_format_i18n(count($registry))); ?></strong>
                </div>

                <?php if (!$registry) : ?>
                    <div class="sp-core-empty-state">No attributes yet. Click <strong>Rebuild</strong> or add a new attribute.</div>
                <?php else : ?>
                    <div class="sp-core-attribute-cards">
                        <?php foreach ($registry as $attribute) :
                            if (!is_array($attribute)) {
                                continue;
                            }
                            $attribute_key = !empty($attribute['attribute_key']) ? sanitize_key($attribute['attribute_key']) : sanitize_key($attribute['label'] ?? '');
                            $edit_url = add_query_arg([
                                'post_type' => 'phone',
                                'page' => 'spesification-core-phone-attributes',
                                'edit_attribute' => $attribute_key,
                            ], admin_url('edit.php'));
                            if ($return_page === 'core') {
                                $edit_url = add_query_arg(['page' => 'spesification-core-attributes', 'edit_attribute' => $attribute_key], admin_url('admin.php'));
                            }
                            $term_names = $this->registry_terms_to_names($attribute['terms'] ?? []);
                            $group_key = sanitize_key($attribute['group_key'] ?? '');
                            $preview_terms = array_slice($term_names, 0, 4);
                            ?>
                            <article class="sp-core-attribute-card" data-name="<?php echo esc_attr(strtolower(($attribute['label'] ?? '') . ' ' . ($attribute['slug'] ?? '') . ' ' . implode(' ', $term_names))); ?>" data-group="<?php echo esc_attr($group_key); ?>">
                                <div class="sp-core-attribute-card-main">
                                    <div>
                                        <h3><?php echo esc_html($attribute['label'] ?? ''); ?></h3>
                                        <div class="sp-core-attribute-meta">
                                            <span><?php echo esc_html($attribute['group_label'] ?? 'Other Attributes'); ?></span>
                                            <?php if (!empty($attribute['source'])) : ?><span><?php echo esc_html($this->format_attribute_source_label($attribute['source'])); ?></span><?php endif; ?>
                                            <?php if (!empty($attribute['slug'])) : ?><code><?php echo esc_html($attribute['slug']); ?></code><?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="sp-core-attribute-card-actions">
                                        <a class="button sp-core-mini-button" href="<?php echo esc_url($edit_url); ?>">Edit</a>
                                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sp-core-inline-delete" onsubmit="return confirm('Delete this attribute? Existing Phone values will stay safe.');">
                                            <?php wp_nonce_field('sp_core_delete_phone_attribute_' . $attribute_key); ?>
                                            <input type="hidden" name="action" value="sp_core_delete_phone_attribute">
                                            <input type="hidden" name="attribute_key" value="<?php echo esc_attr($attribute_key); ?>">
                                            <input type="hidden" name="return_page" value="<?php echo esc_attr($return_page); ?>">
                                            <button type="submit" class="button sp-core-mini-button is-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                                <div class="sp-core-value-preview">
                                    <?php if ($preview_terms) : ?>
                                        <?php foreach ($preview_terms as $term) : ?><span><?php echo esc_html($term); ?></span><?php endforeach; ?>
                                        <?php if (count($term_names) > count($preview_terms)) : ?><span>+<?php echo esc_html(count($term_names) - count($preview_terms)); ?></span><?php endif; ?>
                                    <?php else : ?>
                                        <em>No values</em>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </div>
        <script>
        (function(){
            const root = document.querySelector('.sp-core-attribute-manager');
            if (!root) return;
            const input = root.querySelector('.sp-core-attribute-search');
            const filter = root.querySelector('.sp-core-attribute-filter');
            const cards = Array.from(root.querySelectorAll('.sp-core-attribute-card'));
            function apply(){
                const q = (input && input.value || '').trim().toLowerCase();
                const group = filter ? filter.value : '';
                cards.forEach(card => {
                    const matchText = !q || (card.dataset.name || '').includes(q);
                    const matchGroup = !group || card.dataset.group === group;
                    card.style.display = matchText && matchGroup ? '' : 'none';
                });
            }
            if (input) input.addEventListener('input', apply);
            if (filter) filter.addEventListener('change', apply);

            function normalizeValue(value){
                return String(value || '').replace(/\s+/g, ' ').trim();
            }

            function parseLines(value){
                return String(value || '')
                    .replace(/
/g, '
')
                    .replace(/
/g, '
')
                    .split('
')
                    .map(normalizeValue)
                    .filter(Boolean);
            }

            function unique(values){
                const seen = new Set();
                const output = [];
                values.forEach(value => {
                    const normalized = value.toLowerCase();
                    if (seen.has(normalized)) return;
                    seen.add(normalized);
                    output.push(value);
                });
                return output;
            }

            root.querySelectorAll('[data-sp-core-terms-builder]').forEach(builder => {
                const textarea = document.getElementById(builder.dataset.target || '');
                const field = builder.querySelector('.sp-core-terms-input');
                const addButton = builder.querySelector('.sp-core-terms-add');
                const list = builder.querySelector('.sp-core-terms-chip-list');
                const form = builder.closest('form');
                if (!textarea || !field || !addButton || !list) return;

                let values = unique(parseLines(textarea.value));
                textarea.classList.add('is-enhanced');
                builder.classList.add('is-ready');

                function sync(){
                    textarea.value = values.join('
');
                    textarea.dispatchEvent(new Event('input', { bubbles: true }));
                    textarea.dispatchEvent(new Event('change', { bubbles: true }));
                }

                function render(){
                    list.innerHTML = '';
                    if (!values.length) {
                        const empty = document.createElement('div');
                        empty.className = 'sp-core-terms-empty';
                        empty.textContent = 'No values yet.';
                        list.appendChild(empty);
                        sync();
                        return;
                    }

                    values.forEach((value, index) => {
                        const chip = document.createElement('div');
                        chip.className = 'sp-core-term-chip';

                        const text = document.createElement('span');
                        text.className = 'sp-core-term-chip-text';
                        text.textContent = value;
                        chip.appendChild(text);

                        const remove = document.createElement('button');
                        remove.type = 'button';
                        remove.className = 'sp-core-term-remove';
                        remove.setAttribute('aria-label', 'Remove value');
                        remove.textContent = '×';
                        remove.addEventListener('click', () => {
                            values.splice(index, 1);
                            render();
                            field.focus();
                        });
                        chip.appendChild(remove);
                        list.appendChild(chip);
                    });
                    sync();
                }

                function addValue(raw){
                    const incoming = unique(parseLines(raw));
                    if (!incoming.length) return;
                    values = unique(values.concat(incoming));
                    field.value = '';
                    render();
                }

                addButton.addEventListener('click', () => addValue(field.value));
                field.addEventListener('keydown', event => {
                    if (event.key === 'Enter') {
                        event.preventDefault();
                        addValue(field.value);
                    }
                });
                field.addEventListener('paste', event => {
                    const pasted = (event.clipboardData || window.clipboardData).getData('text');
                    if (pasted && /[\r\n]/.test(pasted)) {
                        event.preventDefault();
                        addValue(pasted);
                    }
                });
                if (form) {
                    form.addEventListener('submit', () => addValue(field.value));
                }
                render();
            });
        })();
        </script>
        <?php
    }


    private function format_attribute_source_label($source) {
        $source = sp_core_clean_string($source);
        if ($source === '') {
            return '';
        }

        $map = [
            'woocommerce_global_attribute' => 'WooCommerce',
            'woocommerce' => 'WooCommerce',
            'migrated_phone_attribute' => 'Migrated',
            'manual_phone_attribute' => 'Manual',
            'global_attribute' => 'WooCommerce',
        ];

        $key = sanitize_key($source);
        if (isset($map[$key])) {
            return $map[$key];
        }

        return ucwords(str_replace(['_', '-'], ' ', $source));
    }

    public function render_attribute_group_registry_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $groups = $this->get_phone_attribute_groups_assoc();
        $registry = $this->get_attribute_registry_assoc();
        $attribute_options = [];
        foreach ($registry as $attribute) {
            if (!is_array($attribute)) {
                continue;
            }
            $label = sp_core_clean_string($attribute['label'] ?? '');
            if ($label === '') {
                continue;
            }
            $attribute_options[] = [
                'label' => $label,
                'slug' => sp_core_clean_string($attribute['slug'] ?? ''),
                'group' => sp_core_clean_string($attribute['group_label'] ?? ''),
                'key' => sanitize_key($attribute['attribute_key'] ?? sanitize_title($label)),
            ];
        }
        usort($attribute_options, static function ($a, $b) {
            return strcasecmp($a['label'] ?? '', $b['label'] ?? '');
        });
        $edit_key = isset($_GET['edit_group']) ? sanitize_key(wp_unslash($_GET['edit_group'])) : '';
        $editing = $edit_key && isset($groups[$edit_key]) ? $groups[$edit_key] : [];
        $return_page = (isset($_GET['page']) && $_GET['page'] === 'spesification-core-attribute-groups') ? 'core' : 'phone';
        $notice = isset($_GET['sp_core_notice']) ? sanitize_key(wp_unslash($_GET['sp_core_notice'])) : '';
        ?>
        <div class="wrap sp-core-admin sp-core-groups-manager">
            <div class="sp-core-attribute-topbar">
                <div>
                    <div class="sp-core-kicker">Specification Core <span>v<?php echo esc_html(SP_CORE_VERSION); ?></span></div>
                    <h1>Attribute Groups</h1>
                    <p>Atur struktur group untuk Phone Specifications. Group menjadi accordion, attributes menjadi field editor.</p>
                </div>
                <div class="sp-core-attribute-actions">
                    <a class="button sp-core-button-light" href="<?php echo esc_url(admin_url('admin.php?page=spesification-core-tools#sp-core-data-transfer')); ?>">Import / Export</a>
                    <a class="button button-primary sp-core-button-main" href="#sp-core-group-form"><?php echo $editing ? esc_html__('Edit Group', 'spesification-core') : esc_html__('Add Group', 'spesification-core'); ?></a>
                </div>
            </div>

            <?php if ($notice) : ?>
                <div class="notice notice-success is-dismissible sp-core-notice"><p><?php echo esc_html($this->notice_message($notice, isset($_GET['migrated']) ? absint($_GET['migrated']) : 0, isset($_GET['updated']) ? absint($_GET['updated']) : 0, isset($_GET['skipped']) ? absint($_GET['skipped']) : 0)); ?></p></div>
            <?php endif; ?>

            <section id="sp-core-group-form" class="sp-core-panel sp-core-group-quickform">
                <div class="sp-core-panel-head">
                    <div>
                        <span><?php echo $editing ? esc_html__('Edit Group', 'spesification-core') : esc_html__('Add Group', 'spesification-core'); ?></span>
                        <h2><?php echo $editing ? esc_html($editing['group_label'] ?? '') : esc_html__('Group Structure', 'spesification-core'); ?></h2>
                    </div>
                    <?php if ($editing) : ?>
                        <a class="button sp-core-button-light" href="<?php echo esc_url($this->attribute_group_admin_url($return_page)); ?>">Cancel</a>
                    <?php endif; ?>
                </div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sp-core-group-form">
                    <?php wp_nonce_field('sp_core_save_phone_attribute_group'); ?>
                    <input type="hidden" name="action" value="sp_core_save_phone_attribute_group">
                    <input type="hidden" name="return_page" value="<?php echo esc_attr($return_page); ?>">
                    <input type="hidden" name="original_key" value="<?php echo esc_attr($edit_key); ?>">
                    <div class="sp-core-group-form-grid">
                        <p>
                            <label for="sp-core-group-label">Group Name</label>
                            <input id="sp-core-group-label" type="text" name="group_label" value="<?php echo esc_attr($editing['group_label'] ?? ''); ?>" placeholder="Platform" required>
                        </p>
                        <p>
                            <label for="sp-core-group-position">Position</label>
                            <input id="sp-core-group-position" type="number" name="position" value="<?php echo esc_attr($editing['position'] ?? '90'); ?>" min="0" step="1">
                        </p>
                    </div>
                    <details class="sp-core-advanced-field" <?php echo $editing ? 'open' : ''; ?>>
                        <summary>Advanced</summary>
                        <p>
                            <label for="sp-core-group-key">Slug / Key</label>
                            <input id="sp-core-group-key" type="text" name="group_key" value="<?php echo esc_attr($editing['group_key'] ?? ''); ?>" placeholder="Auto from name">
                        </p>
                    </details>
                    <div class="sp-core-group-attribute-field">
                        <label for="sp-core-group-attribute-search">Attributes</label>
                        <textarea id="sp-core-group-attributes" class="sp-core-group-attributes-source" name="attributes" rows="8" placeholder="One attribute per line&#10;Processor&#10;Processor Type&#10;Cores&#10;GPU"><?php echo esc_textarea($this->group_attributes_to_text($editing['attributes'] ?? [])); ?></textarea>
                        <div class="sp-core-group-attribute-builder" data-sp-core-group-builder data-target="sp-core-group-attributes">
                            <div class="sp-core-group-picker-row">
                                <input id="sp-core-group-attribute-search" class="sp-core-group-attribute-search" type="search" placeholder="Search attribute name..." autocomplete="off">
                                <button type="button" class="sp-core-group-add-custom">Add</button>
                            </div>
                            <div class="sp-core-group-selected" aria-live="polite"></div>
                            <div class="sp-core-group-suggestions" aria-label="Attribute suggestions">
                                <?php foreach ($attribute_options as $option) : ?>
                                    <button type="button" class="sp-core-group-suggestion" data-label="<?php echo esc_attr($option['label']); ?>" data-search="<?php echo esc_attr(strtolower(($option['label'] ?? '') . ' ' . ($option['slug'] ?? '') . ' ' . ($option['group'] ?? '') . ' ' . ($option['key'] ?? ''))); ?>">
                                        <span><?php echo esc_html($option['label']); ?></span>
                                        <?php if (!empty($option['group'])) : ?><small><?php echo esc_html($option['group']); ?></small><?php endif; ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                            <?php if (!$attribute_options) : ?><div class="sp-core-empty-state">No attribute registry available. Add attributes first, then return here.</div><?php endif; ?>
                        </div>
                        <small>Search existing attributes, tap to add, or type a new name and press Add.</small>
                    </div>
                    <div class="sp-core-form-actions">
                        <button type="submit" class="button button-primary sp-core-button-main"><?php echo $editing ? esc_html__('Save Group', 'spesification-core') : esc_html__('Save Group', 'spesification-core'); ?></button>
                        <?php if ($editing) : ?>
                            <a class="button sp-core-button-light" href="<?php echo esc_url($this->attribute_group_admin_url($return_page)); ?>">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </section>

            <section class="sp-core-panel sp-core-group-list-panel">
                <div class="sp-core-panel-head">
                    <div>
                        <span>Structure</span>
                        <h2>Groups</h2>
                    </div>
                    <strong class="sp-core-count-pill"><?php echo esc_html(number_format_i18n(count($groups))); ?></strong>
                </div>
                <div class="sp-core-group-cards">
                    <?php foreach ($groups as $group_key => $group) :
                        $edit_url = add_query_arg(['post_type' => 'phone', 'page' => 'spesification-core-phone-attribute-groups', 'edit_group' => $group_key], admin_url('edit.php'));
                        if ($return_page === 'core') {
                            $edit_url = add_query_arg(['page' => 'spesification-core-attribute-groups', 'edit_group' => $group_key], admin_url('admin.php'));
                        }
                        $attr_names = array_values(array_filter(array_map(static function ($item) { return is_array($item) ? ($item['label'] ?? '') : (string) $item; }, (array) ($group['attributes'] ?? []))));
                        $preview = array_slice($attr_names, 0, 8);
                        ?>
                        <article class="sp-core-group-card">
                            <div class="sp-core-group-card-head">
                                <div>
                                    <h3><?php echo esc_html($group['group_label'] ?? $group_key); ?></h3>
                                    <div class="sp-core-attribute-meta"><code><?php echo esc_html($group_key); ?></code><span>Position <?php echo esc_html((string) ($group['position'] ?? 90)); ?></span></div>
                                </div>
                                <div class="sp-core-attribute-card-actions">
                                    <a class="button sp-core-mini-button" href="<?php echo esc_url($edit_url); ?>">Edit</a>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="sp-core-inline-delete" onsubmit="return confirm('Delete this group? Existing Phone values will stay safe.');">
                                        <?php wp_nonce_field('sp_core_delete_phone_attribute_group_' . $group_key); ?>
                                        <input type="hidden" name="action" value="sp_core_delete_phone_attribute_group">
                                        <input type="hidden" name="group_key" value="<?php echo esc_attr($group_key); ?>">
                                        <input type="hidden" name="return_page" value="<?php echo esc_attr($return_page); ?>">
                                        <button type="submit" class="button sp-core-mini-button is-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                            <div class="sp-core-value-preview">
                                <?php foreach ($preview as $label) : ?><span><?php echo esc_html($label); ?></span><?php endforeach; ?>
                                <?php if (count($attr_names) > count($preview)) : ?><span>+<?php echo esc_html(count($attr_names) - count($preview)); ?></span><?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        </div>
        <script>
        (function(){
            const root = document.querySelector('.sp-core-groups-manager');
            if (!root) return;

            function clean(value){
                return String(value || '').replace(/\s+/g, ' ').trim();
            }
            function parseLines(value){
                return String(value || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').map(clean).filter(Boolean);
            }
            function unique(values){
                const seen = new Set();
                const output = [];
                values.forEach(value => {
                    const label = clean(value);
                    const key = label.toLowerCase();
                    if (!key || seen.has(key)) return;
                    seen.add(key);
                    output.push(label);
                });
                return output;
            }

            root.querySelectorAll('[data-sp-core-group-builder]').forEach(builder => {
                const textarea = document.getElementById(builder.dataset.target || '');
                const search = builder.querySelector('.sp-core-group-attribute-search');
                const add = builder.querySelector('.sp-core-group-add-custom');
                const selected = builder.querySelector('.sp-core-group-selected');
                const suggestions = Array.from(builder.querySelectorAll('.sp-core-group-suggestion'));
                const form = builder.closest('form');
                if (!textarea || !search || !add || !selected) return;

                let values = unique(parseLines(textarea.value));
                textarea.classList.add('is-enhanced');

                function sync(){
                    textarea.value = values.join('\n');
                    textarea.dispatchEvent(new Event('input', { bubbles: true }));
                    textarea.dispatchEvent(new Event('change', { bubbles: true }));
                }
                function hasValue(label){
                    const key = clean(label).toLowerCase();
                    return values.some(value => value.toLowerCase() === key);
                }
                function render(){
                    selected.innerHTML = '';
                    if (!values.length) {
                        const empty = document.createElement('span');
                        empty.className = 'sp-core-group-empty';
                        empty.textContent = 'No attributes selected yet.';
                        selected.appendChild(empty);
                    } else {
                        values.forEach((value, index) => {
                            const chip = document.createElement('span');
                            chip.className = 'sp-core-group-selected-chip';
                            const text = document.createElement('span');
                            text.textContent = value;
                            chip.appendChild(text);
                            const remove = document.createElement('button');
                            remove.type = 'button';
                            remove.textContent = '×';
                            remove.setAttribute('aria-label', 'Remove ' + value);
                            remove.addEventListener('click', () => {
                                values.splice(index, 1);
                                render();
                                applyFilter();
                                search.focus();
                            });
                            chip.appendChild(remove);
                            selected.appendChild(chip);
                        });
                    }
                    sync();
                }
                function addValue(label){
                    const value = clean(label);
                    if (!value || hasValue(value)) return;
                    values = unique(values.concat([value]));
                    search.value = '';
                    render();
                    applyFilter();
                }
                function applyFilter(){
                    const q = clean(search.value).toLowerCase();
                    let shown = 0;
                    suggestions.forEach(button => {
                        const label = button.dataset.label || '';
                        const match = !q || (button.dataset.search || '').includes(q);
                        const already = hasValue(label);
                        const visible = match && !already && shown < 18;
                        button.hidden = !visible;
                        if (visible) shown++;
                    });
                }

                suggestions.forEach(button => {
                    button.addEventListener('click', () => addValue(button.dataset.label || button.textContent));
                });
                search.addEventListener('input', applyFilter);
                search.addEventListener('keydown', event => {
                    if (event.key === 'Enter') {
                        event.preventDefault();
                        const firstVisible = suggestions.find(button => !button.hidden);
                        if (firstVisible && clean(search.value)) {
                            addValue(firstVisible.dataset.label || firstVisible.textContent);
                        } else {
                            addValue(search.value);
                        }
                    }
                });
                add.addEventListener('click', () => addValue(search.value));
                if (form) {
                    form.addEventListener('submit', () => addValue(search.value));
                }
                render();
                applyFilter();
            });
        })();
        </script>
        <?php
    }



    private function require_post_request() {
        if (!isset($_SERVER['REQUEST_METHOD']) || strtoupper((string) $_SERVER['REQUEST_METHOD']) !== 'POST') {
            wp_die(esc_html__('Invalid request method.', 'spesification-core'));
        }
    }

    private function limit_text($value, $max_length) {
        $value = sp_core_clean_string($value);
        $max_length = absint($max_length);
        if ($max_length > 0 && function_exists('mb_substr')) {
            return mb_substr($value, 0, $max_length);
        }
        if ($max_length > 0) {
            return substr($value, 0, $max_length);
        }
        return $value;
    }

    private function is_list_array($value) {
        if (!is_array($value)) {
            return false;
        }
        $expected = 0;
        foreach ($value as $key => $_item) {
            if ($key !== $expected) {
                return false;
            }
            $expected++;
        }
        return true;
    }

    public function handle_save_phone_attribute_group() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_save_phone_attribute_group')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }

        $label = isset($_POST['group_label']) ? $this->limit_text(wp_unslash($_POST['group_label']), 80) : '';
        if ($label === '') {
            wp_die(esc_html__('Group name is required.', 'spesification-core'));
        }

        $original_key = isset($_POST['original_key']) ? sanitize_key(wp_unslash($_POST['original_key'])) : '';
        $key_input = isset($_POST['group_key']) ? $this->limit_text(wp_unslash($_POST['group_key']), 100) : '';
        $group_key = $key_input !== '' ? sanitize_key(str_replace('-', '_', sanitize_title($key_input))) : sanitize_key(str_replace('-', '_', sanitize_title($label)));
        if ($group_key === '') {
            $group_key = sanitize_key($label);
        }

        $attributes_raw = isset($_POST['attributes']) ? wp_unslash($_POST['attributes']) : '';
        $attributes = $this->parse_group_attributes_text($attributes_raw);
        $position = isset($_POST['position']) ? absint($_POST['position']) : 90;

        $groups = $this->get_phone_attribute_groups_assoc();
        if ($original_key && $original_key !== $group_key && isset($groups[$original_key])) {
            unset($groups[$original_key]);
        }

        $groups[$group_key] = [
            'group_key' => $group_key,
            'group_label' => $label,
            'position' => $position,
            'attributes' => $attributes,
            'updated_at' => current_time('mysql'),
        ];

        $this->save_phone_attribute_groups_assoc($groups);
        $this->refresh_attribute_registry_group_assignments();

        $url = add_query_arg([
            'sp_core_notice' => 'attribute_group_saved',
            'migrated' => 1,
            'updated' => count($attributes),
            'skipped' => 0,
        ], $this->attribute_group_admin_url(isset($_POST['return_page']) ? sanitize_key(wp_unslash($_POST['return_page'])) : 'phone'));
        wp_safe_redirect($url);
        exit;
    }

    public function handle_delete_phone_attribute_group() {
        $this->require_post_request();
        $group_key = isset($_POST['group_key']) ? sanitize_key(wp_unslash($_POST['group_key'])) : '';
        if (!$group_key || !current_user_can('manage_options') || !check_admin_referer('sp_core_delete_phone_attribute_group_' . $group_key)) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }

        $groups = $this->get_phone_attribute_groups_assoc();
        $deleted = 0;
        if (isset($groups[$group_key])) {
            unset($groups[$group_key]);
            $deleted = 1;
            $this->save_phone_attribute_groups_assoc($groups);
            $this->refresh_attribute_registry_group_assignments();
        }

        $url = add_query_arg([
            'sp_core_notice' => 'attribute_group_deleted',
            'migrated' => 0,
            'updated' => 0,
            'skipped' => $deleted,
        ], $this->attribute_group_admin_url(isset($_POST['return_page']) ? sanitize_key(wp_unslash($_POST['return_page'])) : 'phone'));
        wp_safe_redirect($url);
        exit;
    }

    public function handle_reset_phone_attribute_groups() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_reset_phone_attribute_groups')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        $groups = $this->default_phone_attribute_groups();
        update_option('sp_core_phone_attribute_groups', array_values($groups), false);
        update_option('sp_core_phone_attribute_groups_json', wp_json_encode(array_values($groups), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), false);
        update_option('sp_core_phone_attribute_groups_synced_at', current_time('mysql'), false);
        $this->refresh_attribute_registry_group_assignments();
        $url = add_query_arg([
            'sp_core_notice' => 'attribute_groups_reset',
            'migrated' => count($groups),
            'updated' => 0,
            'skipped' => 0,
        ], $this->attribute_group_admin_url(isset($_POST['return_page']) ? sanitize_key(wp_unslash($_POST['return_page'])) : 'phone'));
        wp_safe_redirect($url);
        exit;
    }

    public function handle_save_phone_attribute() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_save_phone_attribute')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }

        $label = isset($_POST['attribute_label']) ? $this->limit_text(wp_unslash($_POST['attribute_label']), 80) : '';
        if ($label === '') {
            wp_die(esc_html__('Attribute name is required.', 'spesification-core'));
        }

        $original_key = isset($_POST['original_key']) ? sanitize_key(wp_unslash($_POST['original_key'])) : '';
        $slug_input = isset($_POST['attribute_slug']) ? $this->limit_text(wp_unslash($_POST['attribute_slug']), 100) : '';
        $slug = $slug_input !== '' ? sanitize_title($slug_input) : sanitize_title($label);
        if ($slug === '') {
            $slug = sanitize_title($label);
        }
        $attribute_key = sanitize_key(str_replace('-', '_', $slug));
        if ($attribute_key === '') {
            $attribute_key = sanitize_key($label);
        }

        $group_options = $this->phone_attribute_group_options();
        $group_key = isset($_POST['attribute_group']) ? sanitize_key(wp_unslash($_POST['attribute_group'])) : 'other';
        if (!isset($group_options[$group_key])) {
            $group_key = $this->attribute_group_key($label);
        }
        if (!isset($group_options[$group_key])) {
            $group_key = 'other';
        }

        $terms_raw = isset($_POST['attribute_terms']) ? wp_unslash($_POST['attribute_terms']) : '';
        $terms = $this->parse_attribute_terms_text($terms_raw);

        $posted_term_images = [];
        if (isset($_POST['term_images']) && is_array($_POST['term_images'])) {
            foreach (wp_unslash($_POST['term_images']) as $term_slug => $image_id) {
                $posted_term_images[sanitize_title($term_slug)] = absint($image_id);
            }
        }

        $registry = $this->get_attribute_registry_assoc();
        if ($original_key && $original_key !== $attribute_key && isset($registry[$original_key])) {
            $this->delete_phone_attribute_definition_term($registry[$original_key]);
            unset($registry[$original_key]);
        }

        $existing = $registry[$attribute_key] ?? [];
        $existing_term_images = [];
        foreach ((array) ($existing['terms'] ?? []) as $term) {
            if (!is_array($term) || empty($term['name'])) {
                continue;
            }
            $slug_for_image = sanitize_title(!empty($term['slug']) ? $term['slug'] : $term['name']);
            if (!empty($term['image_id'])) {
                $existing_term_images[$slug_for_image] = absint($term['image_id']);
            }
        }
        foreach ($terms as &$term_for_image) {
            $slug_for_image = sanitize_title($term_for_image['slug'] ?? $term_for_image['name'] ?? '');
            if ($slug_for_image === '') {
                continue;
            }
            if (array_key_exists($slug_for_image, $posted_term_images)) {
                $term_for_image['image_id'] = absint($posted_term_images[$slug_for_image]);
            } elseif (!empty($existing_term_images[$slug_for_image])) {
                $term_for_image['image_id'] = absint($existing_term_images[$slug_for_image]);
            }
        }
        unset($term_for_image);

        $existing = $registry[$attribute_key] ?? [];
        $registry[$attribute_key] = [
            'attribute_key' => $attribute_key,
            'label' => $label,
            'slug' => $slug,
            'taxonomy' => !empty($existing['taxonomy']) ? $existing['taxonomy'] : '',
            'group_key' => $group_key,
            'group_label' => $group_options[$group_key],
            'source' => !empty($existing['source']) ? $existing['source'] : 'manual_phone_attribute',
            'terms' => $terms,
            'updated_at' => current_time('mysql'),
        ];

        $this->save_attribute_registry_assoc($registry);
        $this->ensure_phone_attribute_definition_term($registry[$attribute_key]);

        $url = add_query_arg([
            'sp_core_notice' => 'attribute_saved',
            'migrated' => 1,
            'updated' => count($terms),
            'skipped' => 0,
        ], $this->attribute_admin_url(isset($_POST['return_page']) ? sanitize_key(wp_unslash($_POST['return_page'])) : 'phone'));
        wp_safe_redirect($url);
        exit;
    }

    public function handle_delete_phone_attribute() {
        $this->require_post_request();
        $attribute_key = isset($_POST['attribute_key']) ? sanitize_key(wp_unslash($_POST['attribute_key'])) : '';
        if (!$attribute_key || !current_user_can('manage_options') || !check_admin_referer('sp_core_delete_phone_attribute_' . $attribute_key)) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }

        $registry = $this->get_attribute_registry_assoc();
        $deleted = 0;
        if (isset($registry[$attribute_key])) {
            $this->delete_phone_attribute_definition_term($registry[$attribute_key]);
            unset($registry[$attribute_key]);
            $deleted = 1;
            $this->save_attribute_registry_assoc($registry);
        }

        $url = add_query_arg([
            'sp_core_notice' => 'attribute_deleted',
            'migrated' => 0,
            'updated' => 0,
            'skipped' => $deleted,
        ], $this->attribute_admin_url(isset($_POST['return_page']) ? sanitize_key(wp_unslash($_POST['return_page'])) : 'phone'));
        wp_safe_redirect($url);
        exit;
    }

    private function attribute_admin_url($return_page = 'phone') {
        if ($return_page === 'core_tools') {
            return admin_url('admin.php?page=spesification-core-tools');
        }
        if ($return_page === 'core') {
            return admin_url('admin.php?page=spesification-core-attributes');
        }
        return admin_url('edit.php?post_type=phone&page=spesification-core-phone-attributes');
    }

    private function get_attribute_registry_assoc() {
        $registry = get_option('sp_core_phone_attribute_registry', []);
        if (!is_array($registry)) {
            return [];
        }
        $assoc = [];
        foreach ($registry as $entry) {
            if (!is_array($entry) || empty($entry['label'])) {
                continue;
            }
            $key = !empty($entry['attribute_key']) ? sanitize_key($entry['attribute_key']) : sanitize_key($entry['label']);
            if ($key === '') {
                continue;
            }
            $assoc[$key] = $entry;
        }
        return $assoc;
    }

    private function save_attribute_registry_assoc($registry) {
        if (!is_array($registry)) {
            $registry = [];
        }
        uasort($registry, static function ($a, $b) {
            return strcmp((string) ($a['label'] ?? ''), (string) ($b['label'] ?? ''));
        });
        $values = array_values($registry);
        update_option('sp_core_phone_attribute_registry', $values, false);
        update_option('sp_core_phone_attribute_registry_json', wp_json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), false);
        update_option('sp_core_phone_attribute_registry_synced_at', current_time('mysql'), false);
    }

    private function find_attribute_registry_entry($attribute_key) {
        $attribute_key = sanitize_key($attribute_key);
        if (!$attribute_key) {
            return [];
        }
        $registry = $this->get_attribute_registry_assoc();
        return $registry[$attribute_key] ?? [];
    }

    private function parse_attribute_terms_text($raw) {
        $raw = str_replace(["\r\n", "\r"], "\n", (string) $raw);
        $parts = explode("\n", $raw);
        if (count($parts) === 1 && strpos($raw, '|') !== false) {
            $parts = explode('|', $raw);
        }
        $terms = [];
        $seen = [];
        foreach ($parts as $part) {
            if (count($terms) >= 500) {
                break;
            }
            $name = $this->limit_text($part, 300);
            if ($name === '') {
                continue;
            }
            $slug = sanitize_title($name);
            if (isset($seen[$slug])) {
                continue;
            }
            $seen[$slug] = true;
            $terms[] = [
                'term_id' => 0,
                'name' => $name,
                'slug' => $slug,
                'taxonomy' => '',
            ];
        }
        return $terms;
    }

    private function registry_terms_to_text($terms) {
        return implode("\n", $this->registry_terms_to_names($terms));
    }

    private function registry_terms_to_names($terms) {
        $names = [];
        foreach ((array) $terms as $term) {
            if (is_array($term) && !empty($term['name'])) {
                $names[] = sp_core_clean_string($term['name']);
            } elseif (is_scalar($term)) {
                $names[] = sp_core_clean_string($term);
            }
        }
        return array_values(array_unique(array_filter($names)));
    }

    private function delete_phone_attribute_definition_term($attribute) {
        if (!taxonomy_exists('phone_attribute') || !is_array($attribute)) {
            return;
        }
        $slug = !empty($attribute['slug']) ? sanitize_title($attribute['slug']) : sanitize_title($attribute['label'] ?? '');
        if ($slug === '') {
            return;
        }
        $existing = term_exists($slug, 'phone_attribute');
        if (!$existing) {
            return;
        }
        $term_id = is_array($existing) ? absint($existing['term_id']) : absint($existing);
        if ($term_id) {
            wp_delete_term($term_id, 'phone_attribute');
        }
    }

    public function handle_rebuild_phone_attribute_registry() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_rebuild_phone_attribute_registry')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        $result = $this->build_phone_attribute_registry(true);
        $url = add_query_arg([
            'sp_core_notice' => 'attribute_registry_rebuilt',
            'migrated' => $result['attributes'],
            'updated' => $result['terms'],
            'skipped' => 0,
        ], $this->attribute_admin_url(isset($_POST['return_page']) ? sanitize_key(wp_unslash($_POST['return_page'])) : 'phone'));
        wp_safe_redirect($url);
        exit;
    }

    public function handle_clean_wrong_attribute_terms() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_clean_wrong_attribute_terms')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        $deleted = $this->clean_wrong_attribute_terms();
        $result = $this->build_phone_attribute_registry(true);
        $url = add_query_arg([
            'sp_core_notice' => 'wrong_attribute_terms_cleaned',
            'migrated' => $result['attributes'],
            'updated' => $result['terms'],
            'skipped' => $deleted,
        ], $this->attribute_admin_url(isset($_POST['return_page']) ? sanitize_key(wp_unslash($_POST['return_page'])) : 'phone'));
        wp_safe_redirect($url);
        exit;
    }

    private function build_phone_attribute_registry($repair_terms = false) {
        $registry = [];

        $phone_ids = get_posts([
            'post_type' => 'phone',
            'post_status' => ['publish', 'draft', 'pending', 'private'],
            'fields' => 'ids',
            'posts_per_page' => -1,
            'no_found_rows' => true,
        ]);

        foreach ($phone_ids as $phone_id) {
            $raw_attributes = get_post_meta($phone_id, '_sp_legacy_attributes_raw', true);
            if (!is_array($raw_attributes)) {
                continue;
            }
            foreach ($raw_attributes as $attribute) {
                if (!is_array($attribute)) {
                    continue;
                }
                $label = !empty($attribute['label']) ? sp_core_clean_string($attribute['label']) : '';
                if ($label === '') {
                    continue;
                }
                $key = !empty($attribute['attribute_key']) ? sanitize_key($attribute['attribute_key']) : sanitize_key($label);
                if (!isset($registry[$key])) {
                    $registry[$key] = [
                        'attribute_key' => $key,
                        'label' => $label,
                        'slug' => sanitize_title($key),
                        'taxonomy' => !empty($attribute['source_taxonomy']) ? $attribute['source_taxonomy'] : '',
                        'group_key' => !empty($attribute['group_key']) ? $attribute['group_key'] : $this->attribute_group_key($label),
                        'group_label' => !empty($attribute['group_label']) ? $attribute['group_label'] : $this->attribute_group_label($label),
                        'source' => !empty($attribute['source']) ? $attribute['source'] : 'migrated_phone_attribute',
                        'terms' => [],
                    ];
                }
                foreach ((array) ($attribute['values'] ?? []) as $value) {
                    $value = sp_core_clean_string($value);
                    if ($value === '') {
                        continue;
                    }
                    $registry[$key]['terms'][] = [
                        'term_id' => 0,
                        'name' => $value,
                        'slug' => sanitize_title($value),
                        'taxonomy' => $registry[$key]['taxonomy'],
                    ];
                }
            }
        }

        $registry = $this->canonicalize_attribute_registry_array($registry);
        $registry = $this->ensure_sd_card_slot_registry_entry($registry);

        foreach ($registry as $key => $entry) {
            $seen = [];
            $terms = [];
            foreach ((array) ($entry['terms'] ?? []) as $term) {
                $name = is_array($term) && !empty($term['name']) ? sp_core_clean_string($term['name']) : '';
                if ($name === '') {
                    continue;
                }
                $slug = sanitize_title($name);
                if (isset($seen[$slug])) {
                    continue;
                }
                $seen[$slug] = true;
                $terms[] = is_array($term) ? $term : ['term_id' => 0, 'name' => $name, 'slug' => $slug, 'taxonomy' => ''];
            }
            $registry[$key]['terms'] = $terms;
            if ($repair_terms) {
                $this->ensure_phone_attribute_definition_term($registry[$key]);
            }
        }

        uasort($registry, static function ($a, $b) {
            return strcmp((string) ($a['label'] ?? ''), (string) ($b['label'] ?? ''));
        });

        update_option('sp_core_phone_attribute_registry', array_values($registry), false);
        update_option('sp_core_phone_attribute_registry_json', wp_json_encode(array_values($registry), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), false);
        update_option('sp_core_phone_attribute_registry_synced_at', current_time('mysql'), false);

        $term_total = 0;
        foreach ($registry as $entry) {
            $term_total += !empty($entry['terms']) && is_array($entry['terms']) ? count($entry['terms']) : 0;
        }

        return ['attributes' => count($registry), 'terms' => $term_total];
    }

    private function clean_wrong_attribute_terms() {
        if (!taxonomy_exists('phone_attribute')) {
            return 0;
        }
        $terms = get_terms(['taxonomy' => 'phone_attribute', 'hide_empty' => false]);
        if (is_wp_error($terms) || empty($terms)) {
            return 0;
        }
        $deleted = 0;
        foreach ($terms as $term) {
            $has_value_meta = get_term_meta($term->term_id, 'sp_attribute_value', true);
            if (strpos((string) $term->name, ':') !== false || $has_value_meta !== '') {
                $result = wp_delete_term($term->term_id, 'phone_attribute');
                if (!is_wp_error($result)) {
                    $deleted++;
                }
            }
        }
        return $deleted;
    }

    private function ensure_phone_attribute_definition_term($attribute) {
        if (!taxonomy_exists('phone_attribute') || !is_array($attribute)) {
            return 0;
        }
        $label = !empty($attribute['label']) ? sp_core_clean_string($attribute['label']) : '';
        if ($label === '') {
            return 0;
        }
        $key = !empty($attribute['attribute_key']) ? sanitize_key($attribute['attribute_key']) : sanitize_key($label);
        $slug = !empty($attribute['slug']) ? sanitize_title($attribute['slug']) : sanitize_title($key);
        $existing = term_exists($slug, 'phone_attribute');
        if (!$existing) {
            $existing = wp_insert_term($label, 'phone_attribute', ['slug' => $slug]);
        }
        if (is_wp_error($existing)) {
            return 0;
        }
        $term_id = is_array($existing) ? absint($existing['term_id']) : absint($existing);
        update_term_meta($term_id, 'sp_attribute_label', $label);
        update_term_meta($term_id, 'sp_attribute_key', $key);
        update_term_meta($term_id, 'sp_attribute_group_key', $attribute['group_key'] ?? $this->attribute_group_key($label));
        update_term_meta($term_id, 'sp_attribute_group_label', $attribute['group_label'] ?? $this->attribute_group_label($label));
        update_term_meta($term_id, 'sp_source_taxonomy', $attribute['taxonomy'] ?? '');
        if (!empty($attribute['terms']) && is_array($attribute['terms'])) {
            update_term_meta($term_id, 'sp_attribute_terms', $attribute['terms']);
            update_term_meta($term_id, 'sp_attribute_terms_json', wp_json_encode($attribute['terms'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
        delete_term_meta($term_id, 'sp_attribute_value');
        return $term_id;
    }

    private function merge_attributes_into_registry($attributes) {
        if (!is_array($attributes) || empty($attributes)) {
            return;
        }
        $registry = get_option('sp_core_phone_attribute_registry', []);
        if (!is_array($registry)) {
            $registry = [];
        }
        $by_key = [];
        foreach ($registry as $entry) {
            if (is_array($entry) && !empty($entry['attribute_key'])) {
                $by_key[sanitize_key($entry['attribute_key'])] = $entry;
            }
        }
        foreach ($attributes as $attribute) {
            if (!is_array($attribute) || empty($attribute['label'])) {
                continue;
            }
            $label = sp_core_clean_string($attribute['label']);
            $key = !empty($attribute['attribute_key']) ? sanitize_key($attribute['attribute_key']) : sanitize_key($label);
            if (!isset($by_key[$key])) {
                $by_key[$key] = [
                    'attribute_key' => $key,
                    'label' => $label,
                    'slug' => sanitize_title($key),
                    'taxonomy' => !empty($attribute['source_taxonomy']) ? $attribute['source_taxonomy'] : '',
                    'group_key' => !empty($attribute['group_key']) ? $attribute['group_key'] : $this->attribute_group_key($label),
                    'group_label' => !empty($attribute['group_label']) ? $attribute['group_label'] : $this->attribute_group_label($label),
                    'source' => !empty($attribute['source']) ? $attribute['source'] : 'migrated_phone_attribute',
                    'terms' => [],
                ];
            }
            foreach ((array) ($attribute['values'] ?? []) as $value) {
                $value = sp_core_clean_string($value);
                if ($value === '') {
                    continue;
                }
                $by_key[$key]['terms'][] = ['term_id' => 0, 'name' => $value, 'slug' => sanitize_title($value), 'taxonomy' => $by_key[$key]['taxonomy']];
            }
            $this->ensure_phone_attribute_definition_term($by_key[$key]);
        }
        $by_key = $this->canonicalize_attribute_registry_array($by_key);

        foreach ($by_key as $key => $entry) {
            $seen = [];
            $terms = [];
            foreach ((array) ($entry['terms'] ?? []) as $term) {
                $name = is_array($term) && !empty($term['name']) ? sp_core_clean_string($term['name']) : '';
                if ($name === '') {
                    continue;
                }
                $slug = sanitize_title($name);
                if (isset($seen[$slug])) {
                    continue;
                }
                $seen[$slug] = true;
                $terms[] = ['term_id' => is_array($term) && !empty($term['term_id']) ? absint($term['term_id']) : 0, 'name' => $name, 'slug' => $slug, 'taxonomy' => is_array($term) && !empty($term['taxonomy']) ? $term['taxonomy'] : ''];
            }
            $by_key[$key]['terms'] = $terms;
        }
        uasort($by_key, static function ($a, $b) {
            return strcmp((string) ($a['label'] ?? ''), (string) ($b['label'] ?? ''));
        });
        update_option('sp_core_phone_attribute_registry', array_values($by_key), false);
        update_option('sp_core_phone_attribute_registry_json', wp_json_encode(array_values($by_key), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), false);
        update_option('sp_core_phone_attribute_registry_synced_at', current_time('mysql'), false);
    }


    public function handle_export_phone_attributes() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_export_phone_attributes')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        $attributes = array_values($this->get_attribute_registry_assoc());
        $payload = [
            'type' => 'phone_attributes',
            'plugin' => 'Specification Core',
            'version' => SP_CORE_VERSION,
            'exported_at' => current_time('mysql'),
            'fields' => ['attribute_key', 'label', 'slug', 'taxonomy', 'group_key', 'group_label', 'source', 'terms', 'updated_at'],
            'attributes' => $attributes,
        ];
        $this->send_json_download('specification-core-phone-attributes-' . gmdate('Ymd-His') . '.json', $payload);
    }

    public function handle_export_phone_attribute_groups() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_export_phone_attribute_groups')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        $groups = array_values($this->get_phone_attribute_groups_assoc());
        $payload = [
            'type' => 'phone_attribute_groups',
            'plugin' => 'Specification Core',
            'version' => SP_CORE_VERSION,
            'exported_at' => current_time('mysql'),
            'fields' => ['group_key', 'group_label', 'position', 'attributes', 'updated_at'],
            'attribute_groups' => $groups,
        ];
        $this->send_json_download('specification-core-phone-attribute-groups-' . gmdate('Ymd-His') . '.json', $payload);
    }

    public function handle_import_phone_attributes() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_import_phone_attributes')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        $payload = $this->read_import_json_payload();
        $items = [];
        if (is_array($payload)) {
            if (isset($payload['attributes']) && is_array($payload['attributes'])) {
                $items = $payload['attributes'];
            } elseif (isset($payload['attribute_registry']) && is_array($payload['attribute_registry'])) {
                $items = $payload['attribute_registry'];
            } elseif ($this->is_list_array($payload)) {
                $items = $payload;
            }
        }
        $registry = $this->normalize_imported_attribute_registry($items);
        if (!$registry) {
            wp_safe_redirect(add_query_arg('sp_core_notice', 'import_empty', admin_url('admin.php?page=spesification-core-tools#sp-core-data-transfer')));
            exit;
        }
        $this->save_attribute_registry_assoc($registry);
        foreach ($registry as $attribute) {
            $this->ensure_phone_attribute_definition_term($attribute);
        }
        wp_safe_redirect(add_query_arg([
            'sp_core_notice' => 'attributes_imported',
            'migrated' => count($registry),
            'updated' => $this->count_registry_terms($registry),
            'skipped' => 0,
        ], admin_url('admin.php?page=spesification-core-tools#sp-core-data-transfer')));
        exit;
    }

    public function handle_import_phone_attribute_groups() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_import_phone_attribute_groups')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        $payload = $this->read_import_json_payload();
        $items = [];
        if (is_array($payload)) {
            if (isset($payload['attribute_groups']) && is_array($payload['attribute_groups'])) {
                $items = $payload['attribute_groups'];
            } elseif (isset($payload['groups']) && is_array($payload['groups'])) {
                $items = $payload['groups'];
            } elseif ($this->is_list_array($payload)) {
                $items = $payload;
            }
        }
        $groups = $this->normalize_imported_attribute_groups($items);
        if (!$groups) {
            wp_safe_redirect(add_query_arg('sp_core_notice', 'import_empty', admin_url('admin.php?page=spesification-core-tools#sp-core-data-transfer')));
            exit;
        }
        $this->save_phone_attribute_groups_assoc($groups);
        wp_safe_redirect(add_query_arg([
            'sp_core_notice' => 'attribute_groups_imported',
            'migrated' => count($groups),
            'updated' => 0,
            'skipped' => 0,
        ], admin_url('admin.php?page=spesification-core-tools#sp-core-data-transfer')));
        exit;
    }

    private function send_json_download($filename, $payload) {
        if (headers_sent()) {
            wp_die(esc_html__('Cannot start JSON download because headers were already sent.', 'spesification-core'));
        }
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_option('blog_charset'));
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($filename) . '"');
        header('X-Content-Type-Options: nosniff');
        echo wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }

    private function read_import_json_payload() {
        $json = '';
        $max_bytes = 512 * 1024;
        if (!empty($_FILES['sp_core_import_file']['tmp_name']) && is_uploaded_file($_FILES['sp_core_import_file']['tmp_name'])) {
            $file = $_FILES['sp_core_import_file'];
            $error = isset($file['error']) ? absint($file['error']) : UPLOAD_ERR_OK;
            $size = isset($file['size']) ? absint($file['size']) : 0;
            $name = isset($file['name']) ? sanitize_file_name(wp_unslash($file['name'])) : '';
            $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));

            if ($error !== UPLOAD_ERR_OK || $extension !== 'json' || $size < 1 || $size > $max_bytes) {
                wp_die(esc_html__('Invalid import file. Use a valid JSON file up to 512 KB.', 'spesification-core'));
            }

            // Defense-in-depth: verify the real content type, not just the
            // file extension, to reject disguised/malicious uploads.
            $allowed_mimes = ['application/json', 'text/plain', 'text/json', 'application/octet-stream'];
            $detected_mime = '';
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if ($finfo) {
                    $detected_mime = (string) finfo_file($finfo, $file['tmp_name']);
                    finfo_close($finfo);
                }
            }
            if ($detected_mime !== '' && !in_array(strtolower($detected_mime), $allowed_mimes, true)) {
                wp_die(esc_html__('Invalid import file type. Only JSON files are allowed.', 'spesification-core'));
            }

            $raw = file_get_contents($file['tmp_name'], false, null, 0, $max_bytes + 1);
            $json = is_string($raw) ? $raw : '';
            if (strlen($json) > $max_bytes) {
                wp_die(esc_html__('Import JSON is too large. Maximum allowed size is 512 KB.', 'spesification-core'));
            }
        }
        if ($json === '' && isset($_POST['sp_core_import_json'])) {
            $json = (string) wp_unslash($_POST['sp_core_import_json']);
            if (strlen($json) > $max_bytes) {
                wp_die(esc_html__('Import JSON is too large. Maximum allowed size is 512 KB.', 'spesification-core'));
            }
        }
        $json = trim($json);
        if ($json === '') {
            return [];
        }
        // Limit nesting depth (anti JSON-bomb / stack exhaustion). A legitimate
        // attribute/group export never approaches this depth.
        $payload = json_decode($json, true, 64, JSON_BIGINT_AS_STRING);
        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_die(esc_html__('Import JSON is invalid or too deeply nested.', 'spesification-core'));
        }
        return is_array($payload) ? $payload : [];
    }

    private function normalize_imported_attribute_registry($items) {
        $registry = [];
        $group_options = $this->phone_attribute_group_options();
        foreach ((array) $items as $item) {
            if (!is_array($item)) {
                continue;
            }
            $label = sp_core_clean_string($item['label'] ?? $item['name'] ?? '');
            if ($label === '') {
                continue;
            }
            $slug = sanitize_title($item['slug'] ?? $label);
            $key = sanitize_key($item['attribute_key'] ?? $item['key'] ?? str_replace('-', '_', $slug));
            if ($key === '') {
                $key = sanitize_key($label);
            }
            $group_key = sanitize_key($item['group_key'] ?? 'other');
            if (!isset($group_options[$group_key])) {
                $group_key = $this->attribute_group_key($label);
            }
            if (!isset($group_options[$group_key])) {
                $group_key = 'other';
            }
            $terms = [];
            $seen_terms = [];
            foreach ((array) ($item['terms'] ?? $item['values'] ?? []) as $term) {
                $name = is_array($term) ? sp_core_clean_string($term['name'] ?? $term['label'] ?? $term['value'] ?? '') : sp_core_clean_string($term);
                if ($name === '') {
                    continue;
                }
                $term_slug = sanitize_title(is_array($term) && !empty($term['slug']) ? $term['slug'] : $name);
                if (isset($seen_terms[$term_slug])) {
                    continue;
                }
                $seen_terms[$term_slug] = true;
                $terms[] = [
                    'term_id' => is_array($term) && !empty($term['term_id']) ? absint($term['term_id']) : 0,
                    'name' => $name,
                    'slug' => $term_slug,
                    'taxonomy' => is_array($term) && !empty($term['taxonomy']) ? sanitize_key($term['taxonomy']) : '',
                    'image_id' => is_array($term) && !empty($term['image_id']) ? absint($term['image_id']) : 0,
                ];
            }
            $registry[$key] = [
                'attribute_key' => $key,
                'label' => $label,
                'slug' => $slug,
                'taxonomy' => !empty($item['taxonomy']) ? sanitize_key($item['taxonomy']) : '',
                'group_key' => $group_key,
                'group_label' => $group_options[$group_key] ?? ($item['group_label'] ?? 'Other Attributes'),
                'source' => !empty($item['source']) ? sanitize_key($item['source']) : 'imported_phone_attribute',
                'terms' => $terms,
                'updated_at' => current_time('mysql'),
            ];
        }
        return $registry;
    }

    private function normalize_imported_attribute_groups($items) {
        $groups = [];
        foreach ((array) $items as $item) {
            if (!is_array($item)) {
                continue;
            }
            $label = sp_core_clean_string($item['group_label'] ?? $item['label'] ?? $item['name'] ?? '');
            if ($label === '') {
                continue;
            }
            $key = sanitize_key($item['group_key'] ?? $item['key'] ?? $label);
            if ($key === '') {
                $key = sanitize_key($label);
            }
            $groups[$key] = [
                'group_key' => $key,
                'group_label' => $label,
                'position' => isset($item['position']) ? absint($item['position']) : 90,
                'attributes' => $this->normalize_group_attributes_array($item['attributes'] ?? []),
                'updated_at' => current_time('mysql'),
            ];
        }
        return $groups;
    }

    private function count_registry_terms($registry) {
        $count = 0;
        foreach ((array) $registry as $attribute) {
            $count += is_array($attribute) ? count((array) ($attribute['terms'] ?? [])) : 0;
        }
        return $count;
    }

    private function notice_message($notice, $migrated, $updated, $skipped) {
        if ($notice === 'flushed') {
            return 'Rewrite rules flushed.';
        }
        if ($notice === 'attribute_registry_rebuilt') {
            return sprintf('Phone attribute registry rebuilt. Attributes: %d. Terms/values: %d.', $migrated, $updated);
        }
        if ($notice === 'wrong_attribute_terms_cleaned') {
            return sprintf('Wrong attribute value terms cleaned: %d. Registry rebuilt. Attributes: %d. Terms/values: %d.', $skipped, $migrated, $updated);
        }
        if ($notice === 'attribute_saved') {
            return sprintf('Attribute saved. Attributes updated: %d. Terms/values saved: %d.', $migrated, $updated);
        }
        if ($notice === 'attribute_deleted') {
            return sprintf('Attribute deleted from phone registry: %d.', $skipped);
        }
        if ($notice === 'attributes_imported') {
            return sprintf('Attributes imported: %d. Terms/values: %d.', $migrated, $updated);
        }
        if ($notice === 'attribute_groups_imported') {
            return sprintf('Attribute groups imported: %d.', $migrated);
        }
        if ($notice === 'import_empty') {
            return 'Import failed: no valid JSON records found.';
        }
        return 'Done.';
    }

    public function handle_save_modules() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to manage Specification Core modules.', 'spesification-core'));
        }
        check_admin_referer('sp_core_save_modules');

        $definitions = $this->module_definitions();
        $posted = isset($_POST['modules']) && is_array($_POST['modules']) ? array_map('sanitize_key', wp_unslash($_POST['modules'])) : [];
        $enabled = [];

        foreach ($definitions as $key => $module) {
            if (!empty($module['core']) || in_array($key, $posted, true)) {
                $enabled[] = $key;
            }
        }

        foreach ($definitions as $key => $module) {
            if (!in_array($key, $enabled, true)) {
                continue;
            }
            foreach ((array) ($module['requires'] ?? []) as $required) {
                if (isset($definitions[$required]) && !in_array($required, $enabled, true)) {
                    $enabled[] = $required;
                }
            }
        }

        update_option('sp_core_enabled_modules', array_values(array_unique($enabled)), false);
        $this->enabled_modules_cache = null;
        delete_transient('sp_core_dashboard_snapshot_v080');
        delete_transient('sp_core_dashboard_snapshot_v098');

        wp_safe_redirect(add_query_arg('sp_core_notice', 'modules_saved', admin_url('admin.php?page=spesification-core-modules')));
        exit;
    }

    public function handle_flush_rewrite() {
        $this->require_post_request();
        if (!current_user_can('manage_options') || !check_admin_referer('sp_core_flush_rewrite')) {
            wp_die(esc_html__('Not allowed.', 'spesification-core'));
        }
        flush_rewrite_rules(false);
        wp_safe_redirect(add_query_arg('sp_core_notice', 'flushed', admin_url('admin.php?page=spesification-core')));
        exit;
    }

    private function default_phone_attribute_groups() {
        $defaults = [
            'network' => ['Network', 10, ['Technology' => 'technology', 'Speed' => 'speed', 'SIM' => 'sim']],
            'design' => ['Design', 20, ['Dimensions' => 'dimensions', 'Weight' => 'weight', 'Material' => 'material', 'Colors' => 'colors', 'IP Rating' => 'ip_rating', 'Other' => 'other']],
            'display' => ['Display', 30, ['Panel Type' => 'panel_type', 'Size' => 'display_size', 'Resolution' => 'resolution', 'Cover Type' => 'cover_type', 'Cover Size' => 'cover_size', 'Cover Resolution' => 'cover_resolution', 'Cover Display' => 'cover_display', 'Brightness' => 'brightness', 'Protection' => 'protection', 'Features' => 'display_features']],
            'platform' => ['Platform', 40, ['Processor' => 'processor', 'Processor Type' => 'processor_type', 'Cores' => 'cores', 'Clockspeed' => 'clock_speed', 'GPU' => 'gpu', 'Operating System' => 'os']],
            'storage' => ['Storage', 50, ['Internal Storage' => 'internal_storage', 'RAM' => 'ram', 'RAM Type' => 'ram_type', 'SD Card Slot' => 'sd_slot', 'UFS' => 'ufs']],
            // Canonical camera slots. Old Woo/single-product.php camera labels are
            // lookup aliases only; do not display every alias as a field.
            'front_camera' => ['Front Camera', 60, ['Main' => 'front_main', 'Second' => 'front_second', 'Features' => 'front_features', 'Video' => 'front_video']],
            'rear_camera' => ['Rear Camera', 70, ['Main' => 'rear_main', 'Second' => 'rear_second', 'Third' => 'rear_third', 'Quad' => 'rear_quad', 'Features' => 'rear_features', 'Video' => 'rear_video']],
            'connectivity' => ['Connectivity', 80, ['WLAN' => 'wlan', 'Bluetooth' => 'bluetooth', 'Codec' => 'codec', 'GPS' => 'gps', 'NFC' => 'nfc', 'Infrared' => 'infrared', 'Radio' => 'radio', 'USB' => 'usb']],
            'audio' => ['Audio', 90, ['Loudspeaker' => 'loudspeaker', '3.5mm' => 'audio_jack_3_5mm', 'Audio Jack' => 'audio_jack']],
            'battery' => ['Battery', 100, ['Capacity' => 'capacity', 'Battery Type' => 'battery_type', 'Charging' => 'charging', 'Quick Charge' => 'quick_charge', 'Power Delivery' => 'power_delivery', 'Wireless Charging' => 'wireless_charging', 'Reverse Charging' => 'reverse_charging']],
            'sensor' => ['Sensor', 110, ['Fingerprint' => 'fingerprint', 'Face ID' => 'face_id', 'Accelerometer' => 'accelerometer', 'Gyroscope' => 'gyroscope', 'Proximity' => 'proximity', 'Compass' => 'compass', 'Barometer' => 'barometer', 'Color Spectrum' => 'color_spectrum']],
        ];

        $groups = [];
        foreach ($defaults as $key => $data) {
            [$label, $position, $attribute_names] = $data;
            $attributes = [];
            foreach ($attribute_names as $attr_label => $field_name) {
                $attributes[] = [
                    'label' => sp_core_clean_string($attr_label),
                    'field_name' => sanitize_key($field_name),
                ];
            }
            $groups[$key] = [
                'group_key' => $key,
                'group_label' => $label,
                'position' => $position,
                'attributes' => $attributes,
                'updated_at' => '',
            ];
        }
        return $groups;
    }

    private function get_phone_attribute_groups_assoc() {
        $stored = get_option('sp_core_phone_attribute_groups', []);
        if (!is_array($stored) || !$stored) {
            return $this->default_phone_attribute_groups();
        }

        $groups = [];
        foreach ($stored as $entry) {
            if (!is_array($entry) || empty($entry['group_label'])) {
                continue;
            }
            $key = !empty($entry['group_key']) ? sanitize_key($entry['group_key']) : sanitize_key($entry['group_label']);
            if ($key === '') {
                continue;
            }
            $groups[$key] = [
                'group_key' => $key,
                'group_label' => sp_core_clean_string($entry['group_label']),
                'position' => isset($entry['position']) ? absint($entry['position']) : 90,
                'attributes' => $this->normalize_group_attributes_array($entry['attributes'] ?? []),
                'updated_at' => $entry['updated_at'] ?? '',
            ];
        }

        if (!$groups) {
            return $this->default_phone_attribute_groups();
        }
        uasort($groups, static function ($a, $b) {
            return ((int) ($a['position'] ?? 90) <=> (int) ($b['position'] ?? 90)) ?: strcmp((string) ($a['group_label'] ?? ''), (string) ($b['group_label'] ?? ''));
        });
        return $groups;
    }

    private function save_phone_attribute_groups_assoc($groups) {
        if (!is_array($groups)) {
            $groups = [];
        }
        foreach ($groups as $key => $group) {
            $groups[$key]['attributes'] = $this->normalize_group_attributes_array($group['attributes'] ?? []);
        }
        uasort($groups, static function ($a, $b) {
            return ((int) ($a['position'] ?? 90) <=> (int) ($b['position'] ?? 90)) ?: strcmp((string) ($a['group_label'] ?? ''), (string) ($b['group_label'] ?? ''));
        });
        update_option('sp_core_phone_attribute_groups', array_values($groups), false);
        update_option('sp_core_phone_attribute_groups_json', wp_json_encode(array_values($groups), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), false);
        update_option('sp_core_phone_attribute_groups_synced_at', current_time('mysql'), false);
    }

    private function map_group_attribute_label_to_field_name($label) {
        $label = sp_core_clean_string($label);
        if ($label === '') {
            return '';
        }

        $field_name = $this->map_attribute_label_to_acf_without_group_guard($label);
        if ($field_name !== '') {
            return $field_name;
        }

        if (strpos($label, '/') !== false) {
            foreach (preg_split('~/+~', $label) as $candidate) {
                $candidate = sp_core_clean_string($candidate);
                if ($candidate === '') {
                    continue;
                }
                $field_name = $this->map_attribute_label_to_acf_without_group_guard($candidate);
                if ($field_name !== '') {
                    return $field_name;
                }
            }
        }

        return '';
    }

    private function canonical_attribute_label_by_field($field_name, $fallback = '') {
        $field_name = sanitize_key($field_name);
        $labels = [
            'technology' => 'Technology',
            'speed' => 'Speed',
            'sim' => 'SIM',
            'dimensions' => 'Dimensions',
            'weight' => 'Weight',
            'material' => 'Material',
            'colors' => 'Colors',
            'ip_rating' => 'IP Rating',
            'panel_type' => 'Panel Type',
            'display_size' => 'Size',
            'resolution' => 'Resolution',
            'cover_type' => 'Cover Type',
            'cover_size' => 'Cover Size',
            'cover_resolution' => 'Cover Resolution',
            'cover_display' => 'Cover Display',
            'brightness' => 'Brightness',
            'protection' => 'Protection',
            'display_features' => 'Features',
            'refresh_rate' => 'Refresh Rate',
            'os' => 'Operating System',
            'processor' => 'Processor',
            'processor_type' => 'Processor Type',
            'cores' => 'Cores',
            'clock_speed' => 'Clockspeed',
            'gpu' => 'GPU',
            'internal_storage' => 'Internal Storage',
            'ram' => 'RAM',
            'ram_type' => 'RAM Type',
            'sd_slot' => 'SD Card Slot',
            'ufs' => 'UFS',
            'storage' => 'Storage',
            'front_camera' => 'Front Camera',
            'front_main' => 'Main',
            'front_second' => 'Second',
            'front_features' => 'Features',
            'front_video' => 'Video',
            'main_front' => 'Main Front',
            'second_front' => 'Second Front',
            'secondary_front' => 'Secondary Front',
            'featured_front' => 'Featured Front',
            'main_camera' => 'Main Camera',
            'second_rear' => 'Second Rear',
            'secondary_rear' => 'Secondary Rear',
            'third_rear' => 'Third Rear',
            'quad_rear' => 'Quad Rear',
            'quad' => 'Quad',
            'second_rear_cam' => 'Second Rear Cam',
            'video_rear_cam' => 'Video Rear Cam',
            'features_rear_cam' => 'Features Rear Cam',
            'front_features' => 'Front Features',
            'features_front' => 'Features Front',
            'front_video' => 'Front Video',
            'video_front' => 'Video Front',
            'rear_camera' => 'Rear Camera',
            'rear_main' => 'Main',
            'rear_second' => 'Second',
            'rear_third' => 'Third',
            'rear_quad' => 'Quad',
            'rear_features' => 'Features',
            'rear_video' => 'Video',
            'main_rear' => 'Main Rear',
            'rear_features' => 'Rear Features',
            'features_rear' => 'Features Rear',
            'rear_video' => 'Rear Video',
            'video_rear' => 'Video Rear',
            'wlan' => 'WLAN',
            'bluetooth' => 'Bluetooth',
            'codec' => 'Codec',
            'gps' => 'GPS',
            'nfc' => 'NFC',
            'infrared' => 'Infrared',
            'radio' => 'Radio',
            'usb' => 'USB',
            'loudspeaker' => 'Loudspeaker',
            'audio_jack_3_5mm' => '3.5mm',
            'audio_jack' => 'Audio Jack',
            'capacity' => 'Capacity',
            'battery_type' => 'Battery Type',
            'charging' => 'Charging',
            'quick_charge' => 'Quick Charge',
            'power_delivery' => 'Power Delivery',
            'wireless_charging' => 'Wireless Charging',
            'reverse_charging' => 'Reverse Charging',
            'sensors' => 'Sensors',
            'fingerprint' => 'Fingerprint',
            'face_id' => 'Face ID',
            'accelerometer' => 'Accelerometer',
            'gyroscope' => 'Gyroscope',
            'proximity' => 'Proximity',
            'compass' => 'Compass',
            'barometer' => 'Barometer',
            'color_spectrum' => 'Color Spectrum',
            'antutu_benchmark_total' => 'AnTuTu Benchmark Score',
            'specification_score_average' => 'Specification Score',
            'display_score' => 'Display Score',
            'camera_score' => 'Camera Score',
            'performance_score' => 'Performance Score',
            'gaming_score' => 'Gaming Score',
            'battery_score' => 'Battery Score',
            'connectivity_score' => 'Connectivity Score',
        ];
        return $labels[$field_name] ?? sp_core_clean_string($fallback);
    }

    private function duplicate_attribute_meta_aliases() {
        return [
            'build' => 'material',
            'microsd_slot' => 'sd_slot',
            'chipset' => 'processor',
            'speaker' => 'loudspeaker',
            'reverse' => 'reverse_charging',
            // Camera labels are intentionally preserved as individual attributes.
            // Do not collapse Main Front/Main Rear/Second Rear/etc. into one field;
            // the old single-product.php rendered them as separate spec rows.
        ];
    }

    private function parse_group_attributes_text($raw) {
        $lines = preg_split('/\r\n|\r|\n/', (string) $raw);
        $attributes = [];
        $seen = [];
        foreach ((array) $lines as $line) {
            if (count($attributes) >= 120) {
                break;
            }
            $label = $this->limit_text($line, 80);
            if ($label === '') {
                continue;
            }
            $field_name = $this->map_group_attribute_label_to_field_name($label);
            if ($field_name === '') {
                $field_name = sanitize_key(str_replace('-', '_', sanitize_title($label)));
            }
            if ($field_name === '') {
                continue;
            }
            $label = $this->canonical_attribute_label_by_field($field_name, $label);
            $dedupe = strtolower($field_name);
            if (isset($seen[$dedupe])) {
                continue;
            }
            $seen[$dedupe] = true;
            $attributes[] = ['label' => $label, 'field_name' => $field_name];
        }
        return $attributes;
    }

    private function normalize_group_attributes_array($items) {
        if (is_string($items)) {
            return $this->parse_group_attributes_text($items);
        }
        $lines = [];
        foreach ((array) $items as $item) {
            if (is_array($item)) {
                $lines[] = $item['label'] ?? ($item['name'] ?? '');
            } else {
                $lines[] = (string) $item;
            }
        }
        return $this->parse_group_attributes_text(implode("\n", $lines));
    }

    private function group_attributes_to_text($items) {
        $attributes = $this->normalize_group_attributes_array($items);
        return implode("\n", array_map(static function ($item) {
            return $item['label'] ?? '';
        }, $attributes));
    }

    private function get_phone_spec_sections() {
        $sections = [];
        $groups = $this->get_phone_attribute_groups_assoc();
        $defaults = $this->default_phone_attribute_groups();
        foreach (['front_camera', 'rear_camera'] as $camera_group_key) {
            if (!empty($defaults[$camera_group_key])) {
                $groups[$camera_group_key] = $defaults[$camera_group_key];
            }
        }
        foreach ($groups as $group_key => $group) {
            if (in_array($group_key, ['overview', 'scores'], true)) {
                continue;
            }
            $fields = [];
            foreach ((array) ($group['attributes'] ?? []) as $attribute) {
                if (!is_array($attribute)) {
                    continue;
                }
                $label = sp_core_clean_string($attribute['label'] ?? '');
                $field_name = sanitize_key($attribute['field_name'] ?? '');
                if ($group_key === 'sensor' && in_array($field_name, ['sensor', 'sensors'], true)) {
                    continue;
                }
                if ($group_key === 'storage' && $field_name === 'memory') {
                    continue;
                }
                if ($label === '' || $field_name === '' || $this->is_attribute_group_title($label)) {
                    continue;
                }
                $fields[$field_name] = $label;
            }
            if (!$fields) {
                continue;
            }
            $sections[$group_key] = [
                'label' => $group['group_label'] ?? ucwords(str_replace('_', ' ', $group_key)),
                'fields' => $fields,
            ];
        }
        return $sections;
    }

    private function is_attribute_group_title($label) {
        $normalized = $this->normalize_label($label);
        if ($normalized === '') {
            return false;
        }
        foreach ($this->get_phone_attribute_groups_assoc() as $group_key => $group) {
            $candidates = [
                $group_key,
                str_replace('_', ' ', $group_key),
                $group['group_label'] ?? '',
            ];
            foreach ($candidates as $candidate) {
                if ($normalized === $this->normalize_label($candidate)) {
                    return true;
                }
            }
        }
        return false;
    }

    private function group_title_field_names() {
        $names = [];
        foreach ($this->get_phone_attribute_groups_assoc() as $group_key => $group) {
            $names[] = sanitize_key($group_key);
            $names[] = sanitize_key(str_replace('-', '_', sanitize_title($group['group_label'] ?? $group_key)));
        }
        return array_values(array_unique(array_filter($names)));
    }

    public function maybe_upgrade_attribute_group_schema() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $stored = get_option('sp_core_phone_attribute_groups', []);
        if (is_array($stored) && $stored) {
            $groups = [];
            foreach ($stored as $entry) {
                if (!is_array($entry) || empty($entry['group_label'])) {
                    continue;
                }
                $key = !empty($entry['group_key']) ? sanitize_key($entry['group_key']) : sanitize_key($entry['group_label']);
                if ($key === '') {
                    continue;
                }
                $groups[$key] = [
                    'group_key' => $key,
                    'group_label' => sp_core_clean_string($entry['group_label']),
                    'position' => isset($entry['position']) ? absint($entry['position']) : 90,
                    'attributes' => $this->normalize_group_attributes_array($entry['attributes'] ?? []),
                    'updated_at' => $entry['updated_at'] ?? '',
                ];
            }
            if ($groups) {
                $json_before = wp_json_encode($stored);
                $json_after = wp_json_encode(array_values($groups));
                if ($json_before !== $json_after) {
                    $this->save_phone_attribute_groups_assoc($groups);
                }
            }
        }

        if (get_option('sp_core_schema_040_dedupe_complete') !== 'yes') {
            $this->dedupe_attribute_registry_aliases();
            update_option('sp_core_schema_040_dedupe_complete', 'yes', false);
        }

        if (get_option('sp_core_schema_062_editor_camera_fields') !== 'yes') {
            $groups = $this->get_phone_attribute_groups_assoc();
            $defaults = $this->default_phone_attribute_groups();
            foreach (['front_camera', 'rear_camera'] as $camera_group_key) {
                if (!empty($defaults[$camera_group_key])) {
                    $groups[$camera_group_key] = $defaults[$camera_group_key];
                }
            }
            $this->save_phone_attribute_groups_assoc($groups);
            update_option('sp_core_schema_062_editor_camera_fields', 'yes', false);
        }

        if (get_option('sp_core_schema_063_editor_structure') !== 'yes') {
            $groups = $this->get_phone_attribute_groups_assoc();
            $defaults = $this->default_phone_attribute_groups();
            unset($groups['scores']);
            foreach (['front_camera', 'rear_camera', 'sensor'] as $group_key) {
                if (!empty($defaults[$group_key])) {
                    $groups[$group_key] = $defaults[$group_key];
                }
            }
            $this->save_phone_attribute_groups_assoc($groups);
            update_option('sp_core_schema_063_editor_structure', 'yes', false);
        }

        if (get_option('sp_core_schema_064_sd_card_slot_attribute') !== 'yes') {
            $this->ensure_sd_card_slot_attribute_definition();
            update_option('sp_core_schema_064_sd_card_slot_attribute', 'yes', false);
        }

        if (get_option('sp_core_schema_065_remove_storage_memory_attribute') !== 'yes') {
            $this->remove_storage_memory_attribute_definition();
            update_option('sp_core_schema_065_remove_storage_memory_attribute', 'yes', false);
        }
    }

    private function remove_storage_memory_attribute_definition() {
        $groups = $this->get_phone_attribute_groups_assoc();
        if (!empty($groups['storage']['attributes']) && is_array($groups['storage']['attributes'])) {
            $groups['storage']['attributes'] = array_values(array_filter($groups['storage']['attributes'], static function ($attribute) {
                if (!is_array($attribute)) {
                    return false;
                }
                $field = sanitize_key($attribute['field_name'] ?? '');
                $label = sp_core_clean_string($attribute['label'] ?? '');
                return $field !== 'memory' && strcasecmp($label, 'Memory') !== 0;
            }));
            $groups['storage']['updated_at'] = current_time('mysql');
            $this->save_phone_attribute_groups_assoc($groups);
        }

        $registry = $this->get_attribute_registry_assoc();
        if (!empty($registry['memory'])) {
            $this->delete_phone_attribute_definition_term($registry['memory']);
            unset($registry['memory']);
            $this->save_attribute_registry_assoc($registry);
        }
    }

    private function ensure_sd_card_slot_attribute_definition() {
        $groups = $this->get_phone_attribute_groups_assoc();
        $defaults = $this->default_phone_attribute_groups();

        if (empty($groups['storage'])) {
            $groups['storage'] = $defaults['storage'];
        }

        $storage = $groups['storage'];
        $attributes = [];
        $has_sd_card_slot = false;
        foreach ((array) ($storage['attributes'] ?? []) as $attribute) {
            if (!is_array($attribute)) {
                continue;
            }
            $field = sanitize_key($attribute['field_name'] ?? '');
            $label = sp_core_clean_string($attribute['label'] ?? '');
            if ($field === 'sd_slot') {
                $attribute['label'] = 'SD Card Slot';
                $attribute['field_name'] = 'sd_slot';
                $has_sd_card_slot = true;
            }
            if ($field !== '') {
                $attributes[$field] = $attribute;
            } elseif ($label !== '') {
                $attributes[sanitize_key($label)] = $attribute;
            }
        }

        if (!$has_sd_card_slot) {
            $ordered = [];
            foreach ((array) ($attributes ?: []) as $field => $attribute) {
                $ordered[$field] = $attribute;
                if ($field === 'ram_type') {
                    $ordered['sd_slot'] = ['label' => 'SD Card Slot', 'field_name' => 'sd_slot'];
                }
            }
            if (!isset($ordered['sd_slot'])) {
                $ordered['sd_slot'] = ['label' => 'SD Card Slot', 'field_name' => 'sd_slot'];
            }
            $attributes = $ordered;
        }

        $groups['storage']['attributes'] = array_values($attributes);
        $groups['storage']['updated_at'] = current_time('mysql');
        $this->save_phone_attribute_groups_assoc($groups);

        $registry = $this->ensure_sd_card_slot_registry_entry($this->get_attribute_registry_assoc());
        $this->save_attribute_registry_assoc($registry);
        if (!empty($registry['sd_slot'])) {
            $this->ensure_phone_attribute_definition_term($registry['sd_slot']);
        }
    }

    private function ensure_sd_card_slot_registry_entry($registry) {
        if (!is_array($registry)) {
            $registry = [];
        }

        $group_options = $this->phone_attribute_group_options();
        $group_label = $group_options['storage'] ?? 'Storage';
        $existing = [];
        foreach (['sd_slot', 'microsd_slot'] as $key) {
            if (!empty($registry[$key]) && is_array($registry[$key])) {
                $existing = $registry[$key];
                break;
            }
        }

        $terms = [];
        foreach (['sd_slot', 'microsd_slot'] as $key) {
            if (!empty($registry[$key]['terms']) && is_array($registry[$key]['terms'])) {
                $terms = array_merge($terms, $registry[$key]['terms']);
            }
        }

        unset($registry['microsd_slot']);
        $registry['sd_slot'] = array_merge($existing, [
            'attribute_key' => 'sd_slot',
            'label' => 'SD Card Slot',
            'slug' => 'sd-slot',
            'taxonomy' => $existing['taxonomy'] ?? '',
            'group_key' => 'storage',
            'group_label' => $group_label,
            'source' => !empty($existing['source']) ? sanitize_key($existing['source']) : 'core_phone_attribute',
            'terms' => $terms,
            'updated_at' => current_time('mysql'),
        ]);

        return $registry;
    }

    private function attribute_group_admin_url($return_page = 'phone') {
        if ($return_page === 'core_tools') {
            return admin_url('admin.php?page=spesification-core-tools');
        }
        if ($return_page === 'core') {
            return admin_url('admin.php?page=spesification-core-attribute-groups');
        }
        return admin_url('edit.php?post_type=phone&page=spesification-core-phone-attribute-groups');
    }

    private function canonicalize_attribute_registry_array($registry) {
        if (!is_array($registry)) {
            return [];
        }
        $deduped = [];
        foreach ($registry as $entry) {
            if (!is_array($entry) || empty($entry['label'])) {
                continue;
            }
            $label = sp_core_clean_string($entry['label']);
            $field = $this->map_attribute_label_to_acf_without_group_guard($label);
            if ($field === '') {
                $field = !empty($entry['attribute_key']) ? sanitize_key($entry['attribute_key']) : sanitize_key($label);
            }
            $canonical_label = $this->canonical_attribute_label_by_field($field, $label);
            $canonical_key = sanitize_key($field ?: $canonical_label);
            if ($canonical_key === 'memory' || strcasecmp($canonical_label, 'Memory') === 0) {
                continue;
            }
            if ($canonical_key === '') {
                continue;
            }
            if (!isset($deduped[$canonical_key])) {
                $deduped[$canonical_key] = $entry;
                $deduped[$canonical_key]['attribute_key'] = $canonical_key;
                $deduped[$canonical_key]['label'] = $canonical_label;
                $deduped[$canonical_key]['slug'] = sanitize_title($canonical_key);
                $deduped[$canonical_key]['taxonomy'] = $entry['taxonomy'] ?? '';
                $deduped[$canonical_key]['group_key'] = $this->attribute_group_key($canonical_label);
                $deduped[$canonical_key]['group_label'] = $this->attribute_group_label($canonical_label);
                $deduped[$canonical_key]['terms'] = [];
            }
            $deduped[$canonical_key]['terms'] = array_merge((array) ($deduped[$canonical_key]['terms'] ?? []), (array) ($entry['terms'] ?? []));
        }
        return $deduped;
    }

    private function dedupe_attribute_registry_aliases() {
        $registry = $this->get_attribute_registry_assoc();
        if (!$registry) {
            return;
        }
        $this->save_attribute_registry_assoc($this->canonicalize_attribute_registry_array($registry));
    }

    private function refresh_attribute_registry_group_assignments() {
        $registry = $this->get_attribute_registry_assoc();
        if (!$registry) {
            return;
        }
        foreach ($registry as $key => $entry) {
            $label = $entry['label'] ?? $key;
            $group_key = $this->attribute_group_key($label);
            $group_options = $this->phone_attribute_group_options();
            $registry[$key]['group_key'] = isset($group_options[$group_key]) ? $group_key : 'other';
            $registry[$key]['group_label'] = $group_options[$registry[$key]['group_key']] ?? 'Other Specs';
        }
        $this->save_attribute_registry_assoc($registry);
    }

    private function attribute_to_acf_map() {
        return [
            'Release Date' => 'release_date',
            'Market Status' => 'market_status',
            'Models' => 'models',
            'Price' => 'price',
            'Brand' => 'brand',
            'Manufacturer' => 'brand',
            'Series' => 'series',

            // Network.
            'Technology' => 'technology',
            'Network' => 'network',
            'Speed' => 'speed',
            'SIM' => 'sim',
            'SIM Card' => 'sim',

            // Design.
            'Dimension' => 'dimensions',
            'Dimensions' => 'dimensions',
            'Dimension / Dimensions' => 'dimensions',
            'Weight' => 'weight',
            'Build' => 'material',
            'Material' => 'material',
            'Color' => 'colors',
            'Colors' => 'colors',
            'Color / Colors' => 'colors',
            'IP Rating' => 'ip_rating',

            // Display.
            'Display' => 'display',
            'Panel Type' => 'panel_type',
            'Size' => 'display_size',
            'Resolution' => 'resolution',
            'Cover Type' => 'cover_type',
            'Cover Size' => 'cover_size',
            'Cover Resolution' => 'cover_resolution',
            'Cover Display' => 'cover_display',
            'Brightness' => 'brightness',
            'Protection' => 'protection',
            'Features' => 'display_features',
            'Display Features' => 'display_features',
            'Refresh Rate' => 'refresh_rate',

            // Platform.
            'Operating System' => 'os',
            'OS' => 'os',
            'Processor' => 'processor',
            'Processor Type' => 'processor_type',
            'Chipset' => 'processor',
            'CPU' => 'cores',
            'Cores' => 'cores',
            'Clock Speed' => 'clock_speed',
            'Clockspeed' => 'clock_speed',
            'GPU' => 'gpu',

            // Storage.
            'Internal Storage' => 'internal_storage',
            'RAM' => 'ram',
            'RAM Type' => 'ram_type',
            'SD Card Slot' => 'sd_slot',
            'MicroSD Slot' => 'sd_slot',
            'SD Slot' => 'sd_slot',
            'UFS' => 'ufs',
            'Storage' => 'storage',
            'Memory Card' => 'sd_slot',
            'SD Card' => 'sd_slot',
            'SDCard' => 'sd_slot',
            'Card slot' => 'sd_slot',
            'Card Slot' => 'sd_slot',
            'Internal' => 'internal_storage',

            // Front camera canonical slots.
            'Front Camera' => 'front_main',
            'Selfie Camera' => 'front_main',
            'Main Front' => 'front_main',
            'Second Front' => 'front_second',
            'Secondary Front' => 'front_second',
            'Features Front' => 'front_features',
            'Featured Front' => 'front_features',
            'Front Camera Features' => 'front_features',
            'Front Features' => 'front_features',
            'Video Front' => 'front_video',
            'Front Video' => 'front_video',

            // Rear camera canonical slots.
            'Rear Camera' => 'rear_main',
            'Main Camera' => 'rear_main',
            'Main Rear' => 'rear_main',
            'Second Rear' => 'rear_second',
            'Secondary Rear' => 'rear_second',
            'Third Rear' => 'rear_third',
            'Quad Rear' => 'rear_quad',
            'Quad' => 'rear_quad',
            'Features Rear' => 'rear_features',
            'Rear Camera Features' => 'rear_features',
            'Rear Features' => 'rear_features',
            'Video Rear' => 'rear_video',
            'Rear Video' => 'rear_video',
            'Second Rear Cam' => 'rear_second',
            'Third Rear Cam' => 'rear_third',
            'Quad Rear Cam' => 'rear_quad',
            'Video Rear Cam' => 'rear_video',
            'Features Rear Cam' => 'rear_features',

            // Connectivity.
            'Connectivity' => 'connectivity',
            'WLAN' => 'wlan',
            'Bluetooth' => 'bluetooth',
            'Codec' => 'codec',
            'GPS' => 'gps',
            'Positioning' => 'gps',
            'NFC' => 'nfc',
            'Infrared' => 'infrared',
            'Radio' => 'radio',
            'USB' => 'usb',

            // Audio.
            'Audio' => 'audio',
            'Loudspeaker' => 'loudspeaker',
            'Speaker' => 'loudspeaker',
            '3.5mm' => 'audio_jack_3_5mm',
            '3.5mm jack' => 'audio_jack_3_5mm',
            '3 5mm' => 'audio_jack_3_5mm',
            '35mm' => 'audio_jack_3_5mm',
            'Audio Jack' => 'audio_jack',

            // Battery.
            'Battery' => 'battery',
            'Capacity' => 'capacity',
            'Battery Type' => 'battery_type',
            'Charging' => 'charging',
            'Quick Charge' => 'quick_charge',
            'Power Delivery' => 'power_delivery',
            'Wireless Charging' => 'wireless_charging',
            'Reverse' => 'reverse_charging',
            'Reverse Charging' => 'reverse_charging',

            // Sensor.
            'Sensor' => 'sensor',
            'Sensors' => 'sensors',
            'Fingerprint' => 'fingerprint',
            'Face ID' => 'face_id',
            'Accelerometer' => 'accelerometer',
            'Gyroscope' => 'gyroscope',
            'Gyro' => 'gyroscope',
            'Proximity' => 'proximity',
            'Compass' => 'compass',
            'Barometer' => 'barometer',
            'Color Spectrum' => 'color_spectrum',

            // Scores.
            'AnTuTu Benchmark Score' => 'antutu_benchmark_total',
            'AnTuTu Benchmark Total' => 'antutu_benchmark_total',
            'Specification Score' => 'specification_score_average',
        ];
    }

    private function map_attribute_label_to_acf($label) {
        if ($this->is_attribute_group_title($label)) {
            return '';
        }
        return $this->map_attribute_label_to_acf_without_group_guard($label);
    }

    private function map_attribute_label_to_acf_without_group_guard($label) {
        $normalized = $this->normalize_label($label);
        $map = [];
        foreach ($this->attribute_to_acf_map() as $source => $target) {
            $map[$this->normalize_label($source)] = $target;
        }
        return $map[$normalized] ?? '';
    }

    private function attribute_group_key($label) {
        $normalized = $this->normalize_label($label);
        $compact = preg_replace('/[^a-z0-9]/', '', $normalized);

        foreach ($this->get_phone_attribute_groups_assoc() as $group_key => $group) {
            foreach ((array) ($group['attributes'] ?? []) as $attribute) {
                $attribute_label = is_array($attribute) ? ($attribute['label'] ?? '') : (string) $attribute;
                $attribute_normalized = $this->normalize_label($attribute_label);
                $attribute_compact = preg_replace('/[^a-z0-9]/', '', $attribute_normalized);
                if ($attribute_normalized !== '' && ($normalized === $attribute_normalized || $compact === $attribute_compact)) {
                    return $group_key;
                }
            }
        }

        $groups = [
            'overview' => ['release date', 'market status', 'models', 'price', 'brand', 'manufacturer', 'series'],
            'network' => ['technology', 'network', 'speed', 'sim', 'sim card'],
            'design' => ['dimension', 'dimensions', 'weight', 'build', 'material', 'color', 'colors', 'ip rating', 'other'],
            'display' => ['display', 'panel type', 'size', 'resolution', 'cover type', 'cover size', 'cover resolution', 'cover display', 'brightness', 'protection', 'features', 'display features', 'refresh rate'],
            'platform' => ['operating system', 'os', 'processor', 'processor type', 'chipset', 'cpu', 'cores', 'clock speed', 'clockspeed', 'gpu'],
            'storage' => ['internal storage', 'ram', 'ram type', 'sd card slot', 'sdcard slot', 'sd card', 'microsd slot', 'sd slot', 'ufs', 'storage', 'memory card', 'card slot'],
            'front_camera' => ['front camera', 'main front', 'second front', 'secondary front', 'features front', 'featured front', 'front features', 'video front', 'front video'],
            'rear_camera' => ['rear camera', 'main camera', 'main rear', 'second rear', 'secondary rear', 'third rear', 'third rear cam', 'quad rear', 'quad rear cam', 'quad', 'features rear', 'rear features', 'video rear', 'rear video', 'second rear cam', 'video rear cam', 'features rear cam'],
            'connectivity' => ['connectivity', 'wlan', 'bluetooth', 'codec', 'gps', 'nfc', 'infrared', 'radio', 'usb'],
            'audio' => ['audio', 'loudspeaker', 'speaker', '3 5mm', '3.5mm', '35mm', 'audio jack', 'jack', 'stereo speakers'],
            'battery' => ['battery', 'capacity', 'battery type', 'charging', 'quick charge', 'power delivery', 'wireless charging', 'reverse', 'reverse charging'],
            'sensor' => ['sensor', 'sensors', 'fingerprint', 'face id', 'accelerometer', 'gyro', 'gyroscope', 'proximity', 'compass', 'barometer', 'color spectrum'],
            'scores' => ['antutu benchmark score', 'antutu benchmark total', 'specification score', 'performance score', 'display score', 'camera score', 'battery score', 'gaming score', 'connectivity score'],
        ];
        foreach ($groups as $group => $labels) {
            if (in_array($normalized, $labels, true) || in_array($compact, array_map(static function($item) { return preg_replace('/[^a-z0-9]/', '', $item); }, $labels), true)) {
                return $group;
            }
        }
        return 'other';
    }

    private function attribute_group_label($label) {
        $key = $this->attribute_group_key($label);
        $labels = $this->phone_attribute_group_options();
        return $labels[$key] ?? 'Other Attributes';
    }

    private function phone_attribute_group_options() {
        $options = [];
        foreach ($this->get_phone_attribute_groups_assoc() as $group_key => $group) {
            $options[$group_key] = $group['group_label'] ?? ucwords(str_replace('_', ' ', $group_key));
        }
        $options['other'] = $options['other'] ?? 'Other Specs';
        return $options;
    }

    private function normalize_label($label) {
        $label = strtolower(wp_strip_all_tags((string) $label));
        $label = str_replace(['_', '-', '/', '.', ':'], ' ', $label);
        $label = preg_replace('/\s+/', ' ', $label);
        return trim((string) $label);
    }

    private function cleanup_duplicate_alias_meta_fields($phone_id) {
        foreach ($this->duplicate_attribute_meta_aliases() as $from => $to) {
            $from = sanitize_key($from);
            $to = sanitize_key($to);
            if ($from === '' || $to === '') {
                continue;
            }
            $from_value = get_post_meta($phone_id, $from, true);
            $to_value = get_post_meta($phone_id, $to, true);
            if ($from_value !== '' && $from_value !== null && ($to_value === '' || $to_value === null)) {
                $this->update_acf_or_meta($phone_id, $to, $from_value);
            }
            if (function_exists('update_field')) {
                update_field($from, '', $phone_id);
            }
            delete_post_meta($phone_id, $from);
            delete_post_meta($phone_id, '_' . $from);
        }

        $cpu_value = get_post_meta($phone_id, 'cpu', true);
        if (is_string($cpu_value) && trim($cpu_value) !== '') {
            $cpu_value = sp_core_clean_string($cpu_value);
            $cores = $cpu_value;
            $clock_speed = '';
            if (preg_match('/^([^\(]+)\((.+)\)$/', $cpu_value, $m)) {
                $cores = sp_core_clean_string($m[1]);
                $clock_speed = sp_core_clean_string($m[2]);
            }
            if ($cores !== '' && get_post_meta($phone_id, 'cores', true) === '') {
                $this->update_acf_or_meta($phone_id, 'cores', $cores);
            }
            if ($clock_speed !== '' && get_post_meta($phone_id, 'clock_speed', true) === '') {
                $this->update_acf_or_meta($phone_id, 'clock_speed', $clock_speed);
            }
            if (function_exists('update_field')) {
                update_field('cpu', '', $phone_id);
            }
            delete_post_meta($phone_id, 'cpu');
            delete_post_meta($phone_id, '_cpu');
        }
    }

    private function update_acf_or_meta($post_id, $key, $value) {
        if (!$key) {
            return;
        }
        if (function_exists('update_field')) {
            update_field($key, $value, $post_id);
        }
        update_post_meta($post_id, $key, $value);
    }

    public function maybe_use_theme_phone_template($template) {
        if (!is_singular('phone')) {
            return $template;
        }
        $theme_template = locate_template('single-phone.php');
        if ($theme_template) {
            return $theme_template;
        }
        return $template;
    }

    public function maybe_root_phone_permalink($permalink, $post) {
        if (!defined('SP_CORE_PHONE_ROOT_PERMALINKS') || !SP_CORE_PHONE_ROOT_PERMALINKS) {
            return $permalink;
        }
        if ($post instanceof WP_Post && $post->post_type === 'phone' && $post->post_status === 'publish') {
            return home_url(user_trailingslashit($post->post_name));
        }
        return $permalink;
    }

    public function maybe_resolve_root_phone_request($query_vars) {
        if (!defined('SP_CORE_PHONE_ROOT_PERMALINKS') || !SP_CORE_PHONE_ROOT_PERMALINKS) {
            return $query_vars;
        }
        if (is_admin() || wp_doing_ajax()) {
            return $query_vars;
        }
        $path = $query_vars['pagename'] ?? $query_vars['name'] ?? '';
        if (!$path || strpos($path, '/') !== false) {
            return $query_vars;
        }
        $phone = get_posts([
            'name' => sanitize_title($path),
            'post_type' => 'phone',
            'post_status' => 'publish',
            'numberposts' => 1,
            'fields' => 'ids',
        ]);
        if ($phone) {
            $query_vars['post_type'] = 'phone';
            $query_vars['name'] = sanitize_title($path);
            unset($query_vars['pagename']);
        }
        return $query_vars;
    }

    public function filter_seopress_product_schema($schema) {
        if (!is_singular('phone')) {
            return $schema;
        }

        $post_id = absint(get_queried_object_id());
        if (!$post_id || get_post_type($post_id) !== 'phone') {
            return $schema;
        }

        $this->seopress_product_schema_was_filtered = true;
        return $this->build_phone_product_schema($post_id, is_array($schema) ? $schema : []);
    }

    public function output_phone_product_schema_jsonld() {
        if ($this->seopress_product_schema_was_filtered || !is_singular('phone')) {
            return;
        }

        $post_id = absint(get_queried_object_id());
        if (!$post_id || get_post_type($post_id) !== 'phone') {
            return;
        }

        $schema = $this->build_phone_product_schema($post_id, []);
        if (empty($schema) || empty($schema['@type'])) {
            return;
        }

        $json = wp_json_encode(
            $schema,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );

        if (!$json) {
            return;
        }

        $this->seopress_product_schema_was_filtered = true;
        echo "
" . '<script type="application/ld+json" class="sp-core-phone-product-schema">' . "
";
        echo $json . "
";
        echo '</script>' . "
";
    }

    private function build_phone_product_schema($post_id, $schema = []) {
        $permalink = get_permalink($post_id);
        $description = $this->schema_clean_phone_text(sp_core_get_phone_description($post_id));
        if ($description === '') {
            $description = $this->schema_clean_phone_text(wp_trim_words(wp_strip_all_tags(get_post_field('post_content', $post_id)), 38));
        }

        $schema = is_array($schema) ? $schema : [];
        $schema['@context'] = 'https://schema.org';
        $schema['@type'] = 'Product';
        $schema['@id'] = trailingslashit($permalink) . '#product';
        $schema['name'] = $this->schema_clean_phone_text(get_the_title($post_id));
        $schema['url'] = esc_url_raw($permalink);
        $schema['mainEntityOfPage'] = esc_url_raw($permalink);

        if ($description !== '') {
            $schema['description'] = $description;
        }

        $images = $this->schema_get_phone_images($post_id);
        if ($images) {
            $schema['image'] = $images;
        }

        $brand = $this->schema_get_first_phone_term_name($post_id, 'phone_brand');
        if ($brand !== '') {
            $schema['brand'] = [
                '@type' => 'Brand',
                'name'  => $brand,
            ];
        } else {
            unset($schema['brand']);
        }

        $category = $this->schema_get_phone_product_category($post_id);
        if ($category !== '') {
            $schema['category'] = $category;
        }

        $model = $this->schema_clean_phone_text(sp_core_get_field('models', $post_id, ''));
        if ($model !== '') {
            $schema['model'] = $model;
        }

        $schema['additionalProperty'] = $this->schema_get_phone_additional_properties($post_id, $schema['additionalProperty'] ?? []);

        unset($schema['aggregateRating']);
        unset($schema['review']);

        $aggregate_rating = $this->schema_get_phone_aggregate_rating($post_id);
        if ($aggregate_rating) {
            $schema['aggregateRating'] = $aggregate_rating;
        }

        $review = $this->schema_get_phone_editorial_review($post_id);
        if ($review) {
            $schema['review'] = $review;
        }

        // Database mode: Spesification.com is an informational phone database,
        // not a merchant/seller page. Do not output Offer by default because
        // Google then classifies the result as a Merchant listing and requests
        // seller-only fields such as shippingDetails and return policies.
        unset($schema['offers']);

        /**
         * Advanced escape hatch for future ecommerce/merchant mode.
         * Return true from this filter only if the page is intentionally used
         * as a seller/merchant listing with valid price, shipping, and return data.
         */
        if (apply_filters('sp_core_schema_include_offer_for_phone', false, $post_id)) {
            $offer = $this->schema_get_phone_offer($post_id);
            if ($offer) {
                $schema['offers'] = apply_filters('sp_core_phone_schema_offer', $offer, $post_id);
            }
        }

        return array_filter($schema, static function ($value) {
            return $value !== null && $value !== '' && $value !== [];
        });
    }

    private function schema_clean_phone_text($value) {
        $value = sp_core_clean_string($value);
        $value = preg_replace('/\s+/', ' ', $value);
        return trim((string) $value);
    }

    private function schema_get_first_phone_term_name($post_id, $taxonomy) {
        if (!taxonomy_exists($taxonomy)) {
            return '';
        }
        $terms = wp_get_object_terms($post_id, $taxonomy, ['fields' => 'all']);
        if (is_wp_error($terms) || empty($terms)) {
            return '';
        }
        return $this->schema_clean_phone_text($terms[0]->name ?? '');
    }

    private function schema_get_phone_product_category($post_id) {
        // Spesification.com is a phone specification database. In Product
        // schema, category must represent the product type, not the brand.
        // Keep this stable as "Mobile Phone" even when legacy migration put
        // brand-like terms into phone_category.
        $category = apply_filters('sp_core_schema_phone_product_category', 'Mobile Phone', $post_id);
        $category = $this->schema_clean_phone_text($category);
        return $category !== '' ? $category : 'Mobile Phone';
    }

    private function schema_get_phone_images($post_id) {
        $ids = [];
        if (has_post_thumbnail($post_id)) {
            $ids[] = get_post_thumbnail_id($post_id);
        }

        $gallery = sp_core_get_field('phone_gallery', $post_id, []);
        if (is_array($gallery)) {
            foreach ($gallery as $item) {
                if (is_numeric($item)) {
                    $ids[] = absint($item);
                } elseif (is_array($item) && !empty($item['ID'])) {
                    $ids[] = absint($item['ID']);
                } elseif (is_array($item) && !empty($item['id'])) {
                    $ids[] = absint($item['id']);
                }
            }
        }

        $urls = [];
        foreach (array_unique(array_filter(array_map('absint', $ids))) as $id) {
            $url = wp_get_attachment_image_url($id, 'full');
            if ($url) {
                $urls[] = esc_url_raw($url);
            }
        }
        return array_values(array_unique($urls));
    }

    private function schema_get_phone_additional_properties($post_id, $existing = []) {
        $properties = [];
        $seen = [];
        $push = function ($name, $value) use (&$properties, &$seen) {
            $name = $this->schema_clean_phone_text($name);
            $value = $this->schema_clean_phone_text($value);
            if ($name === '' || $value === '' || preg_match('/^(no|n\/a|na|-|none)$/i', $value)) {
                return;
            }

            // Product already has the canonical model property. Keep it out of
            // additionalProperty to avoid duplicate Model/Models entries in
            // Rich Results output.
            if (preg_match('/^(model|models)$/i', $name)) {
                return;
            }
            $key = strtolower($name);
            if (isset($seen[$key])) {
                return;
            }
            $seen[$key] = true;
            $properties[] = [
                '@type' => 'PropertyValue',
                'name'  => $name,
                'value' => $value,
            ];
        };

        if (function_exists('sp_core_get_grouped_phone_specs')) {
            $groups = sp_core_get_grouped_phone_specs($post_id, ['include_other' => false, 'hide_empty' => true, 'hide_no_single' => true]);
            foreach ((array) $groups as $group_label => $rows) {
                foreach ((array) $rows as $label => $value) {
                    $push($label, $value);
                }
            }
        } else {
            foreach (sp_core_get_phone_specs_raw($post_id) as $label => $value) {
                $push($label, $value);
            }
        }

        $market = sp_core_get_phone_market_info($post_id);
        $push('Release Date', $market['release_date'] ?? '');
        $push('Market Status', $market['market_status'] ?? '');
        $push('Models', $market['models'] ?? '');

        $score = $this->schema_get_phone_specification_score($post_id);
        if ($score > 0) {
            $push('Specification Score', $score . '/100');
        }

        $antutu = $this->schema_get_phone_antutu_total($post_id);
        if ($antutu > 0) {
            $push('AnTuTu Benchmark Score', number_format_i18n($antutu));
        }

        foreach ((array) $existing as $property) {
            if (is_array($property)) {
                $push($property['name'] ?? '', $property['value'] ?? '');
            }
        }

        return $properties;
    }

    private function schema_get_phone_specification_score($post_id) {
        $scores = sp_core_get_phone_performance_scores($post_id);
        $values = [];
        foreach ((array) $scores as $score) {
            $score = str_replace(',', '.', (string) $score);
            $number = (float) preg_replace('/[^0-9.]/', '', $score);
            if ($number <= 0) {
                continue;
            }
            if ($number <= 10) {
                $number *= 10;
            }
            $values[] = min(100, max(0, $number));
        }
        if (!$values) {
            return 0;
        }
        return round(array_sum($values) / count($values));
    }

    private function schema_get_phone_antutu_total($post_id) {
        $scores = sp_core_get_phone_antutu_benchmark($post_id);
        $total = 0;
        foreach (['cpu_score', 'gpu_score', 'memory_score', 'ux_score'] as $key) {
            $value = $scores[$key] ?? 0;
            $total += absint(preg_replace('/[^0-9]/', '', (string) $value));
        }
        return $total;
    }

    private function schema_get_phone_aggregate_rating($post_id) {
        $score = $this->schema_get_phone_specification_score($post_id);
        if ($score <= 0) {
            return [];
        }

        return [
            '@type'       => 'AggregateRating',
            'ratingValue' => round($score / 20, 1),
            'bestRating'  => 5,
            'worstRating' => 1,
            'ratingCount' => 1,
        ];
    }

    private function schema_get_phone_editorial_review($post_id) {
        $score = $this->schema_get_phone_specification_score($post_id);

        $pros = function_exists('sp_core_get_phone_review_list') ? sp_core_get_phone_review_list('pros', $post_id) : [];
        $cons = function_exists('sp_core_get_phone_review_list') ? sp_core_get_phone_review_list('cons', $post_id) : [];
        $parts = [];
        if ($pros) {
            $parts[] = 'Pros: ' . implode('; ', array_slice($pros, 0, 8));
        }
        if ($cons) {
            $parts[] = 'Cons: ' . implode('; ', array_slice($cons, 0, 8));
        }
        $body = $this->schema_clean_phone_text(implode(' ', $parts));
        if ($body === '') {
            $body = $this->schema_clean_phone_text(get_the_excerpt($post_id));
        }
        if ($body === '') {
            $body = wp_trim_words(wp_strip_all_tags(get_post_field('post_content', $post_id)), 45);
            $body = $this->schema_clean_phone_text($body);
        }
        if ($body === '') {
            return [];
        }

        $review = [
            '@type' => 'Review',
            'author' => [
                '@type' => 'Organization',
                'name'  => 'Spesification Editorial Team',
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name'  => 'Spesification',
            ],
            'reviewBody' => $body,
            'datePublished' => get_the_date('c', $post_id),
            'dateModified'  => get_the_modified_date('c', $post_id),
        ];

        if ($score > 0) {
            $review['reviewRating'] = [
                '@type'       => 'Rating',
                'ratingValue' => round($score / 20, 1),
                'bestRating'  => 5,
                'worstRating' => 1,
            ];
        }

        return $review;
    }

    private function schema_get_phone_offer($post_id) {
        $price_data = apply_filters('sp_core_phone_price_data', [], $post_id);
        if (is_array($price_data) && !empty($price_data['amount'])) {
            $amount = (float) $price_data['amount'];
            $currency = !empty($price_data['currency']) && preg_match('/^[A-Z]{3}$/', (string) $price_data['currency'])
                ? (string) $price_data['currency']
                : $this->schema_get_default_price_currency($post_id);

            if ($amount > 0) {
                return $this->schema_build_offer_node($post_id, $amount, $currency);
            }
        }

        foreach (['price', 'price_reference', 'price_reference_amount', 'sale_price', 'regular_price'] as $field) {
            $price = $this->schema_parse_phone_price(sp_core_get_field($field, $post_id, ''));
            if ($price) {
                return $this->schema_build_offer_node($post_id, (float) $price['amount'], $price['currency']);
            }
        }

        return [];
    }

    private function schema_build_offer_node($post_id, $amount, $currency) {
        $amount = (float) $amount;
        if ($amount <= 0) {
            return [];
        }

        $market = strtolower(sp_core_clean_string(sp_core_get_field('market_status', $post_id, '')));
        $availability = 'https://schema.org/InStock';
        if (strpos($market, 'coming') !== false || strpos($market, 'rumor') !== false) {
            $availability = 'https://schema.org/PreOrder';
        } elseif (strpos($market, 'not available') !== false || strpos($market, 'discontinued') !== false) {
            $availability = 'https://schema.org/OutOfStock';
        }

        return [
            '@type' => 'Offer',
            'url' => esc_url_raw(get_permalink($post_id)),
            'priceCurrency' => preg_match('/^[A-Z]{3}$/', (string) $currency) ? (string) $currency : 'USD',
            'price' => rtrim(rtrim(number_format($amount, 2, '.', ''), '0'), '.'),
            'availability' => $availability,
            'itemCondition' => 'https://schema.org/NewCondition',
        ];
    }

    private function schema_get_default_price_currency($post_id) {
        foreach (['price_currency', 'currency', 'price_reference_currency'] as $field) {
            $currency = strtoupper($this->schema_clean_phone_text(sp_core_get_field($field, $post_id, '')));
            if (preg_match('/^[A-Z]{3}$/', $currency)) {
                return $currency;
            }
        }

        $opts = get_option('srcs_options', []);
        if (is_array($opts) && !empty($opts['base_currency']) && preg_match('/^[A-Z]{3}$/', (string) $opts['base_currency'])) {
            return (string) $opts['base_currency'];
        }

        return 'USD';
    }

    private function schema_parse_phone_price($raw) {
        $raw = $this->schema_clean_phone_text($raw);
        if ($raw === '' || preg_match('/check price|not available|coming soon/i', $raw)) {
            return [];
        }

        $currency = 'USD';
        if (preg_match('/\bIDR\b|Rp\s*/i', $raw)) {
            $currency = 'IDR';
        } elseif (strpos($raw, '€') !== false || preg_match('/\bEUR\b/i', $raw)) {
            $currency = 'EUR';
        } elseif (strpos($raw, '£') !== false || preg_match('/\bGBP\b/i', $raw)) {
            $currency = 'GBP';
        } elseif (strpos($raw, '¥') !== false || preg_match('/\bJPY\b/i', $raw)) {
            $currency = 'JPY';
        } elseif (preg_match('/\bUSD\b|\$/i', $raw)) {
            $currency = 'USD';
        } else {
            $opts = get_option('srcs_options', []);
            if (is_array($opts) && !empty($opts['base_currency']) && preg_match('/^[A-Z]{3}$/', $opts['base_currency'])) {
                $currency = $opts['base_currency'];
            }
        }

        $number = preg_replace('/[^0-9,.]/', '', $raw);
        if ($number === '') {
            return [];
        }

        if (strpos($number, ',') !== false && strpos($number, '.') !== false) {
            $number = str_replace(',', '', $number);
        } elseif (strpos($number, ',') !== false) {
            $parts = explode(',', $number);
            $last = end($parts);
            if (strlen($last) === 3) {
                $number = str_replace(',', '', $number);
            } else {
                $number = str_replace(',', '.', $number);
            }
        }

        $amount = (float) $number;
        if ($amount <= 0) {
            return [];
        }

        $formatted = rtrim(rtrim(number_format($amount, 2, '.', ''), '0'), '.');
        return [
            'amount' => $formatted,
            'currency' => $currency,
        ];
    }

}
